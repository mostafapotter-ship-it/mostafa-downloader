# PROGRESS

## الجولة 1 — تنضيف + workflow
- [x] 1. مسح `platformFolders` و`nameTemplate` من `Settings.kt`
- [x] 2. مسح `setPlatformFolders` و`setNameTemplate` من `DownloaderViewModel.kt`
- [x] 3. مسح `object NameTemplate` من `Organize.kt`
- [x] 4. مراجعة الأخطاء المحتملة
- [x] 5. تحديث `build.yml` (setup-java / Node 20) — محتاج نص الملف من الريبو
- [x] 6. تجميع zip

## الجولة 2 — تحميل قائمة / حساب كامل
- [x] 1. `download()` تقبل حد أقصى (limit) بدل 20 ثابتة
- [x] 2. `PlaylistDl.kt`: موديل القائمة (`ListUi`) + قراءة `--flat-playlist` + `isListLink`
- [x] 3. `DownloaderViewModel`: `loadList` و`downloadList`
- [x] 4. واجهة `ListSection` (آخر 10 / 25 / 50 / الكل) في `Screens.kt`
- [x] 5. إخفاء المعاينة وتعطيل زرار التحميل العادي لو الرابط قائمة
- [x] 6. مراجعة (imports، أقواس، تعارض أسماء)

## الجولة 3 — ودجت الشاشة الرئيسية (لصق رابط + تحميل بضغطة)
- [x] 1. `res/xml/paste_widget_info.xml` + `res/layout/widget_paste.xml` + خلفية
- [x] 2. `PasteWidgetProvider.kt` (بيقرا الحافظة عن طريق Activity شفافة)
- [x] 3. `QuickPasteActivity.kt` شفافة: تقرا الحافظة وتبدأ التحميل وتقفل
- [x] 4. تسجيل الـ receiver والـ activity في `AndroidManifest.xml` + نصوص
- [x] 5. مراجعة + zip جديد
