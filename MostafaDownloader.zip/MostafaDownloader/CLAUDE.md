# CLAUDE.md
Read `AGENTS.md` first (project rules, layout, release flow, things you must not break), then `PROGRESS.md`.
