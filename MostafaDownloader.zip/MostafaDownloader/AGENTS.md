# AGENTS.md — Mostafa Downloader (read this first, then PROGRESS.md)

You are continuing an existing, **released** Android app. Real users receive updates from it, so a mistake can break their app.
Work carefully, change as little as needed, and never "clean up" things you were not asked to touch.

## 0. How to work (mandatory)
1. Read this file, then `PROGRESS.md`. If the user says "continue" (كمّل), resume from the first unchecked `[ ]` item in "المهمة الجارية".
2. After **every finished point**, tick it in `PROGRESS.md` immediately (`[x]` + one line: what changed + files). Do not wait until the end.
3. Say honestly what you could not test. The user tests on a real phone; you usually cannot build or run the app.
4. Deliver the result as a zip named exactly **`MostafaDownloader.zip`** with the same layout as the one you received (see section 3). Also update `PROGRESS.md` inside it.
5. Talk to the user in **Egyptian Arabic**, short, simple, mobile-friendly steps. The user works only from a phone browser (GitHub web) and cannot run commands.
6. The user wants a professional, simple product: hide technical details from end users, rarely used settings go under "Advanced" with sensible defaults. Do not add visible clutter.

## 1. What the app is
Kotlin + Jetpack Compose (Material 3) Android app, package `com.mostafa.downloader`, minSdk 24, targetSdk 34, Kotlin 1.9.24, AGP 8.5.2, Compose compiler 1.5.14, Gradle 8.7, Java 17.
- Downloads video/audio/images from many platforms using **yt-dlp** (youtubedl-android library) + ffmpeg; also WhatsApp statuses, Instagram/Facebook/Snapchat stories (login through an in-app WebView, cookies stored locally).
- AI features through the user's own free **Groq** key (Settings): burn-in translation, transcript + summary.
- Self-updating: the app updates itself from GitHub Releases (delta patches when possible).
- UI language: Arabic (RTL) and English, via `l.t("عربي", "English")` (`Lang` in `Ui.kt`; property is `l.ar`, NOT `isAr`). All new user-visible text must have both.

## 2. Code map (`app/src/main/java/com/mostafa/downloader/`)
- `MainActivity.kt` — activity, `AppRoot`, tab routing: 0 Download, 1 History, 2 Statuses (WhatsApp + Stories), 3 Translate (tools), 4 Settings. Splash and onboarding gating.
- `Screens.kt` — HomeScreen, HistoryScreen (+ saved transcripts), StatusesScreen, WhatsAppScreen, StoriesScreen, SettingsScreen (+ Advanced section), AboutCard, LoginScreen, BottomBar, QueueSection.
- `HomeExtras.kt` — Trim / Compress / AI-translation option sections. `TranslateScreen.kt` — Translate tab: burn-in translation and "Transcript & summary" panel.
- `DownloaderViewModel.kt` — the brain: queue, downloads, preview, engine, statuses, translation, transcripts, app updates, test-build update.
- `EngineUpdater.kt` — yt-dlp auto-update (on launch if >12h, WorkManager every 12h, and update+retry once when a download fails with a site-change error).
- `Updater.kt`, `BsPatch.kt`, `UpdateCheckWorker.kt` — app self-update (see section 5).
- `AiTrans.kt` (Groq Whisper, translation, summary), `SubBurn.kt` (burn subtitles), `Compress.kt` (ffmpeg shrink), `TransRuntime.kt` (app-wide translation/transcript state, survives leaving the screen).
- `Settings.kt`, `HistoryStore.kt`, `QueueStore.kt`, `TranscriptStore.kt`, `Stats.kt`, `Organize.kt` (storage location/saving), `Cookies.kt`, `DevMode.kt` (hidden dev toggle: long-press the version text or tap it 5 times).
- `Notifier.kt`, `DownloadService.kt` (foreground service so work continues in background), `Background.kt` (battery/auto-start help), `Platforms.kt`, `FbStory.kt`, `IgStory.kt`, `SnapStory.kt`, `SnapSpotlight.kt`, `WhatsAppStatus.kt`, `PlaylistDl.kt`, `Preview.kt`, `PasteWidgetProvider.kt`, `QuickPasteActivity.kt`, `Splash.kt`, `Onboarding.kt`, `Ui.kt` (theme, `Lang`, shared components such as `AppCard`, `GradientButton`, `OutlineButton`, `Segmented`).

## 3. Repository / zip layout and how releases are built (CRITICAL)
- The GitHub repo contains only `.github/workflows/build.yml` and **one file: `MostafaDownloader.zip`**. There are no loose source files in the repo.
- The zip must contain exactly one top-level folder **`MostafaDownloader/`** (with `app/`, `gradle/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `PROGRESS.md`, `AGENTS.md`, ...). **Never rename or move that folder or the zip.** The workflow runs `unzip -q MostafaDownloader.zip` and then `gradle assembleRelease` inside `MostafaDownloader/`.
- Branches:
  - **`test`** = experiments. A push builds a **pre-release** `TEST v1.0.N` (tag `test-N`). Users do NOT receive it.
  - **`main`** = what real users get. A push builds a normal release `v1.0.N` (tag `vN`) and every installed app updates to it.
  - The user uploads the zip to `test`, tests, then merges `test` into `main` with a Pull request. Never tell the user to upload straight to `main` unless they already tested.
  - Each branch has its own copy of `build.yml`. Edit it on the branch that builds, commit with `[skip ci]` in the message (otherwise the edit itself triggers a build/release).
- Version: `versionCode` = GitHub `run_number` (env `VERSION_CODE`), `versionName = "1.0.$code"`. Always increases. Do not hardcode versions.
- Signing: release is signed from env `KEYSTORE_PATH`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` (pkcs12). The keystore is the GitHub secret `KEYSTORE_BASE64`. **Never change the signing config, alias or keystore** — a different signature makes every user's update fail. Never print or invent secrets. The real passwords are in the repo's `build.yml`; `docs/build.yml.reference` is a copy with placeholders.
- ABI splits: `arm64-v8a`, `armeabi-v7a`, no universal APK. Release asset names are fixed: `MostafaDownloader-<abi>.apk`, `MostafaDownloader-<abi>.apk.sha256`, `patch-from-<oldVersionCode>-<abi>.bin`. Do not rename them (the updater depends on them).

## 4. Hard rules — do NOT
- Do not change `applicationId`/`namespace`, signing, ABI split names, `Updater.OWNER/REPO`, asset names, or the zip layout.
- Do not hardcode secrets, API keys, or **Groq model names** (they change and were removed before: a hardcoded model caused a 404). Use `AiTrans.pickChatModels`.
- Do not call the GitHub REST API for update checks on the hot path (rate limits on mobile networks). Use the `releases/latest` redirect or `releases.atom` like `Updater` does.
- Do not add top-level functions/classes whose names already exist in the package (all files share one package: a duplicate `fmtSize` once broke the build with "Conflicting overloads"). Run `grep -rn "fun <name>" app/src` first.
- Do not use `browser storage`-like hacks, do not collect user credentials, do not bypass DRM/paid content or account protections. Login is only via the official page in the in-app WebView; the app never sees or stores passwords.
- Do not remove permissions (`WAKE_LOCK`, `FOREGROUND_SERVICE*`, `REQUEST_INSTALL_PACKAGES`, ...) or the foreground service; long jobs must run in `AppScope.io` (not `viewModelScope`) so they survive leaving the screen.
- Do not delete user-facing features or settings the user did not ask to remove; move rare settings to "Advanced" instead.

## 5. Update system (do not break)
- Normal users: app checks `releases/latest` (stable only; pre-releases are ignored by GitHub for "latest").
- Delta update: if `patch-from-<installedVersionCode>-<abi>.bin` exists in the new release, the app downloads only the patch (~3 MB), applies `bspatch` to the installed APK, verifies the sha256, then installs. Otherwise it downloads the full APK (~43 MB). The workflow creates patches from the last 2 stable and last 2 test releases only.
- Dev flow: hidden toggle (`DevMode`) shows "Update to latest test build" (Settings → About). It finds the newest `test-N` pre-release (feed first, API fallback) and uses the same delta path.
- Android requires the same signature; the user taps "Install" in the system dialog each time (cannot be avoided).

## 6. Known pitfalls (learned the hard way)
- Compose: use `androidx.compose.ui.platform.LocalLifecycleOwner` (matches existing code); delegated state needs `import androidx.compose.runtime.getValue`; smart-cast on `by` state needs `!!`; `return@Column` is used for early exit inside screens.
- `Lang` has `t(ar, en)` and `ar` — not `isAr`.
- ffmpeg args are passed as a list (no shell). A comma inside `-vf` must be escaped as `\\,`.
- Groq: free tier has rate limits (429) and models are renamed/removed. Transcript must survive a failed summary (see `AiTrans.transcript`).
- Statuses (WhatsApp): the app only reads the `.Statuses` folder; WhatsApp itself decides when files appear. Do not promise more.
- Keep user-visible text short and non-technical; put diagnostics behind "Copy error details".

## 7. Before you hand over
1. No duplicate declarations, balanced braces/parentheses, all imports present, both languages for every new string.
2. If you can build (`gradle assembleRelease` needs Android SDK 34), do it; otherwise state clearly "not built / not tested".
3. Update `PROGRESS.md` and re-zip as `MostafaDownloader.zip` (same layout, no `build/` folders).
4. Tell the user (Egyptian Arabic): what changed, what is untested, and the 3 steps: upload zip to the `test` branch → install the `TEST` build (or use the in-app test update) → merge to `main` only after testing.
