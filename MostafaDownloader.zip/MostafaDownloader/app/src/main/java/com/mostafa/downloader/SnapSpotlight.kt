package com.mostafa.downloader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * محاولة احتياطية لروابط Snapchat Spotlight لما المحرك الأساسي يفشل (مثلاً 404).
 * بتفتح الصفحة بشكل متصفح عادي وتطلع رابط الفيديو من og:video أو JSON-LD وتنزله مباشرة.
 */
object SnapSpotlight {
    private val UAS = listOf(
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
    )

    private class Page(val code: Int, val html: String)

    private fun get(url: String, ua: String): Page {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects = true
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Page(code, body)
        } finally {
            c.disconnect()
        }
    }

    private fun unescape(s: String): String {
        val u = Regex("\\\\u([0-9a-fA-F]{4})").replace(s) { it.groupValues[1].toInt(16).toChar().toString() }
        return u.replace("\\/", "/").replace("&amp;", "&")
    }

    private fun metaContent(html: String, prop: String): List<String> =
        Regex("<meta\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(html)
            .map { it.value }
            .filter { it.contains("\"$prop\"", true) || it.contains("'$prop'", true) }
            .mapNotNull { Regex("content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }
            .map { unescape(it) }
            .toList()

    private fun findVideo(html: String): String? {
        val cands = ArrayList<String>()
        cands += metaContent(html, "og:video:secure_url")
        cands += metaContent(html, "og:video:url")
        cands += metaContent(html, "og:video")
        cands += metaContent(html, "twitter:player:stream")
        Regex("\"contentUrl\"\\s*:\\s*\"(https:[^\"]+)\"").findAll(html).forEach { cands += unescape(it.groupValues[1]) }
        Regex("\"(?:mediaUrl|videoUrl|snapMediaUrl)\"\\s*:\\s*\"(https:[^\"]+)\"").findAll(html)
            .forEach { cands += unescape(it.groupValues[1]) }
        return cands.firstOrNull { it.startsWith("http") && !it.contains("player", true) }
            ?: cands.firstOrNull { it.startsWith("http") }
    }

    private fun findImage(html: String): String? =
        (metaContent(html, "og:image") + metaContent(html, "twitter:image"))
            .firstOrNull { it.startsWith("http") }

    private fun save(url: String, out: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects = true
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", UAS[0])
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode} on media file")
            c.inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        } finally {
            c.disconnect()
        }
    }

    /** mode: 0 = فيديو، 2 = صورة (الغلاف). الصوت مش مدعوم هنا. */
    suspend fun download(url: String, dir: File, mode: Int) = withContext(Dispatchers.IO) {
        val id = Regex("/spotlight/([^/?#]+)").find(url)?.groupValues?.get(1)
            ?: throw IllegalStateException("ERROR: Snapchat link not recognized")
        val pages = listOf(
            url,
            "https://www.snapchat.com/spotlight/$id",
            "https://www.snapchat.com/spotlight/$id?locale=en-US"
        ).distinct()

        val notes = ArrayList<String>()
        var mediaUrl: String? = null
        loop@ for (u in pages) {
            for (ua in UAS) {
                try {
                    val p = get(u, ua)
                    notes += "${p.code}"
                    if (p.code in 200..299) {
                        mediaUrl = if (mode == 2) findImage(p.html) else findVideo(p.html)
                        if (mediaUrl != null) break@loop
                    }
                } catch (e: Exception) {
                    notes += (e.message ?: "err").take(30)
                }
            }
        }
        if (mediaUrl == null) {
            throw IllegalStateException(
                "ERROR: Snapchat Spotlight: no media found (${notes.joinToString(",")}). " +
                    "The video may be removed or private, or the link expired."
            )
        }
        val ext = if (mode == 2) "jpg" else "mp4"
        dir.mkdirs()
        save(mediaUrl, File(dir, "snapchat_spotlight_${id.take(10)}.$ext"))
    }
}
