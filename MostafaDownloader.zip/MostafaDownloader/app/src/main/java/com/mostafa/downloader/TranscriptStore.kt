package com.mostafa.downloader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** نص وملخص محفوظ في تبويب السجل */
data class SavedTranscript(
    val id: Long,
    val title: String,
    val source: String,   // "file" أو "link"
    val url: String,
    val date: String,
    val lang: String,
    val summary: String,
    val text: String
)

/** تخزين بسيط في ملف JSON (آخر 100 عنصر) */
class TranscriptStore(ctx: Context) {
    private val file = File(ctx.filesDir, "transcripts.json")

    fun load(): List<SavedTranscript> = try {
        if (!file.exists()) emptyList()
        else {
            val arr = JSONArray(file.readText(Charsets.UTF_8))
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                SavedTranscript(
                    o.getLong("id"), o.optString("title"), o.optString("source"), o.optString("url"),
                    o.optString("date"), o.optString("lang"), o.optString("summary"), o.optString("text")
                )
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(items: List<SavedTranscript>) {
        try {
            val arr = JSONArray()
            items.take(MAX).forEach {
                arr.put(
                    JSONObject().put("id", it.id).put("title", it.title).put("source", it.source).put("url", it.url)
                        .put("date", it.date).put("lang", it.lang).put("summary", it.summary).put("text", it.text)
                )
            }
            val tmp = File(file.parentFile, "transcripts.json.tmp")
            tmp.writeText(arr.toString(), Charsets.UTF_8)
            tmp.renameTo(file)
        } catch (e: Exception) {
        }
    }

    companion object {
        const val MAX = 100
    }
}
