package com.mostafa.downloader

import android.content.Context
import android.media.MediaMetadataRetriever
import java.io.File

/** ضغط الفيديو لحجم صغير يناسب المشاركة (واتساب مثلاً): أقصى ارتفاع 480p وجودة معتدلة */
object VideoCompress {
    private fun durationSec(f: File): Double = try {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.absolutePath)
            (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
        } finally {
            r.release()
        }
    } catch (e: Exception) {
        0.0
    }

    /**
     * بيضغط [input] ويستبدله بالنسخة الصغيرة لو طلعت أصغر فعلاً.
     * بيرجع (الملف النهائي، نسبة التوفير %)، أو null لو الضغط فشل أو ما وفّرش حجم (والملف الأصلي زي ما هو).
     */
    fun run(ctx: Context, input: File, keepSubs: Boolean, onPct: (Int) -> Unit): Pair<File, Int>? {
        val dur = durationSec(input)
        val out = File(input.parentFile, input.nameWithoutExtension + "_small.mp4")
        out.delete()

        fun args(vcodec: List<String>, subs: Boolean): List<String> {
            val l = ArrayList<String>()
            l += listOf("-y", "-hide_banner", "-nostdin", "-nostats", "-progress", "pipe:1", "-i", input.absolutePath)
            l += listOf("-map", "0:v:0", "-map", "0:a?")
            if (subs) l += listOf("-map", "0:s?")
            l += listOf("-vf", "scale=-2:min(480\\,ih),format=yuv420p")
            l += vcodec
            l += listOf("-c:a", "aac", "-b:a", "96k", "-ac", "2")
            if (subs) l += listOf("-c:s", "mov_text")
            l += listOf("-movflags", "+faststart", out.absolutePath)
            return l
        }

        var last = -1
        val onLine: (String) -> Unit = { line ->
            if (dur > 0 && line.startsWith("out_time_ms=")) {
                val us = line.substringAfter('=').toLongOrNull() ?: 0L
                val p = (us / 1_000_000.0 / dur * 100).toInt().coerceIn(0, 99)
                if (p != last) { last = p; onPct(p) }
            }
        }
        val x264 = listOf("-c:v", "libx264", "-preset", "veryfast", "-crf", "28")
        val attempts = listOf(
            x264 to keepSubs,
            x264 to false,
            listOf("-c:v", "mpeg4", "-q:v", "6") to false
        ).distinct()
        var ok = false
        for ((codec, subs) in attempts) {
            out.delete()
            val (code, _) = FfRun.run(ctx, args(codec, subs), onLine)
            if (code == 0 && out.exists() && out.length() > 0) { ok = true; break }
        }
        if (!ok || out.length() >= input.length() * 0.95) {
            out.delete()
            return null
        }
        val saved = (100 - out.length() * 100 / input.length()).toInt()
        val finalFile = File(input.parentFile, input.nameWithoutExtension + ".mp4")
        input.delete()
        finalFile.delete()
        if (!out.renameTo(finalFile)) return out to saved
        return finalFile to saved
    }
}
