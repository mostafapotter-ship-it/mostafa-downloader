package com.mostafa.downloader

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private fun labelText(l: Lang, label: String): String =
    if (label == "BEST" || label == "أفضل جودة") l.t("أفضل جودة", "Best quality") else label

// ============================== الرئيسية ==============================
@Composable
fun HomeScreen(vm: DownloaderViewModel, initialText: String, onOpenSettings: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val state by vm.state.collectAsState()
    val history by vm.history.collectAsState()
    val upd by vm.update.collectAsState()
    var input by rememberSaveable { mutableStateOf(vm.extractUrl(initialText) ?: "") }
    var audioOnly by rememberSaveable { mutableStateOf(false) }
    var quality by rememberSaveable { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    val qualityValues = listOf(0, 1080, 720, 480)
    val qualityLabels = listOf(l.t("الأفضل", "Best"), "1080p", "720p", "480p")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        upd.available?.let { r ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(BrandBrush)
                    .clickable { onOpenSettings() }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    l.t("يوجد تحديث جديد للتطبيق", "A new app update is available"),
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
                Text(l.t("تحديث ←", "Update →"), color = Color.White, fontSize = 13.sp)
            }
            Spacer(Modifier.height(16.dp))
        }

        Image(
            painter = painterResource(R.drawable.ic_logo),
            contentDescription = "MostafaDownloader logo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(116.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(2.dp, BrandBrush, RoundedCornerShape(28.dp))
        )
        Spacer(Modifier.height(14.dp))
        Text("MostafaDownloader", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = c.text)
        Spacer(Modifier.height(4.dp))
        Text(
            l.t(
                "تيك توك  •  يوتيوب  •  إنستجرام  •  فيسبوك  •  X",
                "TikTok  •  YouTube  •  Instagram  •  Facebook  •  X"
            ),
            fontSize = 13.sp, color = c.muted, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(22.dp))

        AppCard {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(l.t("رابط الفيديو", "Video link")) },
                textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 14.sp),
                singleLine = true,
                enabled = !state.busy,
                shape = RoundedCornerShape(14.dp),
                trailingIcon = {
                    if (input.isBlank()) {
                        TextButton(
                            onClick = { input = clipboard.getText()?.text.orEmpty() },
                            enabled = !state.busy
                        ) { Text(l.t("لصق", "Paste"), color = Cyan, fontWeight = FontWeight.Bold) }
                    } else {
                        TextButton(onClick = { input = "" }, enabled = !state.busy) {
                            Text(l.t("مسح", "Clear"), color = c.muted)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = c.stroke,
                    focusedTextColor = c.text,
                    unfocusedTextColor = c.text,
                    disabledTextColor = c.muted,
                    focusedLabelColor = Purple,
                    unfocusedLabelColor = c.muted,
                    cursorColor = Purple
                )
            )

            SectionLabel(l.t("النوع", "Type"))
            Segmented(
                options = listOf(l.t("🎬  فيديو", "🎬  Video"), "🎵  MP3 320kbps HQ"),
                selected = if (audioOnly) 1 else 0,
                enabled = !state.busy
            ) { audioOnly = it == 1 }

            if (!audioOnly) {
                SectionLabel(l.t("الجودة", "Quality"))
                Segmented(
                    options = qualityLabels,
                    selected = qualityValues.indexOf(quality).coerceAtLeast(0),
                    enabled = !state.busy
                ) { quality = qualityValues[it] }
            }

            GradientButton(
                text = l.t("تحميل", "Download"),
                enabled = state.ready && !state.busy && input.isNotBlank()
            ) { vm.download(input, audioOnly, quality) }

            if (state.busy) {
                if (state.progress > 0f) {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                    Text(
                        "${(state.progress * 100).toInt()}%",
                        color = Cyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                }
            }

            Text(
                text = state.message.get(l.ar),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 13.sp,
                color = when {
                    state.isError -> ErrorC
                    !state.busy && state.progress >= 1f -> SuccessC
                    else -> c.muted
                }
            )
        }

        Spacer(Modifier.height(20.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                l.t("سجل التحميلات", "Download history") + " (${history.size})",
                fontWeight = FontWeight.Bold, fontSize = 16.sp, color = c.text
            )
            if (history.isNotEmpty()) {
                TextButton(onClick = { vm.clearHistory() }) {
                    Text(l.t("مسح السجل", "Clear"), color = c.muted)
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        if (history.isEmpty()) {
            Text(
                l.t("لا توجد تحميلات بعد", "No downloads yet"),
                color = c.muted, fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }

        history.forEach { item ->
            val itemShape = RoundedCornerShape(16.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clip(itemShape)
                    .background(c.card)
                    .border(1.dp, c.stroke, itemShape)
                    .clickable {
                        try {
                            val i = Intent(Intent.ACTION_VIEW)
                                .setDataAndType(Uri.parse(item.uri), item.mime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            context.startActivity(i)
                        } catch (e: Exception) {
                            Toast.makeText(
                                context, l.t("تعذر فتح الملف", "Couldn't open the file"), Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (item.mime.startsWith("audio")) "🎵" else "🎬", fontSize = 18.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        color = c.text, fontWeight = FontWeight.Medium, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "${labelText(l, item.label)}  •  ${item.date}",
                        fontSize = 11.sp, color = c.muted
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ============================== الإعدادات ==============================
@Composable
fun SettingsScreen(vm: DownloaderViewModel) {
    val c = LocalColors.current
    val l = LocalLang.current
    val s by vm.settings.collectAsState()
    val upd by vm.update.collectAsState()
    val state by vm.state.collectAsState()
    val engineMsg by vm.engineMsg.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text(l.t("الإعدادات", "Settings"), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = c.text)

        AppCard {
            SectionLabel(l.t("اللغة", "Language"))
            Segmented(
                options = listOf("العربية", "English"),
                selected = if (s.lang == "ar") 0 else 1
            ) { vm.setLang(if (it == 0) "ar" else "en") }
        }

        AppCard {
            SectionLabel(l.t("المظهر", "Appearance"))
            Segmented(
                options = listOf(l.t("تلقائي", "System"), l.t("فاتح", "Light"), l.t("داكن", "Dark")),
                selected = when (s.theme) { "system" -> 0; "light" -> 1; else -> 2 }
            ) { vm.setTheme(when (it) { 0 -> "system"; 1 -> "light"; else -> "dark" }) }
        }

        AppCard {
            SectionLabel(l.t("تحديث التطبيق", "App update"))
            Text(
                l.t("الإصدار الحالي", "Current version") + ": v${BuildConfig.VERSION_NAME}",
                color = c.text, fontSize = 14.sp
            )
            val r = upd.available
            if (r != null) {
                Text(
                    l.t("إصدار جديد متاح", "New version available") + ": ${r.name}",
                    color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
                if (r.notes.isNotBlank()) {
                    Text(r.notes.take(300), color = c.muted, fontSize = 12.sp)
                }
                GradientButton(
                    text = l.t("تحديث الآن", "Update now"),
                    enabled = !upd.downloading
                ) { vm.installUpdate() }
                if (upd.downloading) {
                    LinearProgressIndicator(
                        progress = { upd.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                }
            } else {
                GradientButton(
                    text = if (upd.checking) l.t("جاري التحقق...", "Checking...")
                    else l.t("التحقق من التحديثات", "Check for updates"),
                    enabled = !upd.checking
                ) { vm.checkUpdate(true) }
            }
            upd.message?.let {
                Text(it.get(l.ar), color = c.muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth())
            }
        }

        AppCard {
            SectionLabel(l.t("محرك التحميل", "Download engine"))
            Text(
                l.t(
                    "لو منصة وقفت عن التحميل، حدّث المحرك وجرّب تاني.",
                    "If a platform stops working, update the engine and try again."
                ),
                color = c.muted, fontSize = 13.sp
            )
            OutlineButton(
                text = l.t("تحديث محرك التحميل", "Update download engine"),
                modifier = Modifier.fillMaxWidth(),
                enabled = state.ready && !state.busy
            ) { vm.updateEngine() }
            engineMsg?.let { Text(it.get(l.ar), color = c.muted, fontSize = 13.sp) }
        }

        Text(
            "MostafaDownloader v${BuildConfig.VERSION_NAME}",
            color = c.muted, fontSize = 12.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(24.dp))
    }
}

// ============================== حالات واتساب ==============================
@Composable
fun WhatsAppScreen(vm: DownloaderViewModel) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val s by vm.settings.collectAsState()
    val list by vm.statuses.collectAsState()
    val loading by vm.waLoading.collectAsState()
    val err by vm.waError.collectAsState()
    var variant by rememberSaveable { mutableStateOf(0) }
    val savedSet = remember { mutableStateListOf<String>() }
    val currentUri = if (variant == 0) s.waUri else s.wabUri

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            vm.setWaUri(variant, uri.toString())
        }
    }

    LaunchedEffect(variant, currentUri) { vm.loadStatuses(variant) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    l.t("حالات واتساب", "WhatsApp Status"),
                    fontSize = 24.sp, fontWeight = FontWeight.Bold, color = c.text
                )
                Segmented(
                    options = listOf("WhatsApp", "WhatsApp Business"),
                    selected = variant
                ) { variant = it }
                Text(
                    l.t(
                        "افتح الحالة في واتساب الأول وشوفها، وبعدين ارجع هنا واضغط تحديث. " +
                            "أول مرة اختار مجلد الحالات (.Statuses) واضغط \"استخدام هذا المجلد\".",
                        "Open and view the status in WhatsApp first, then come back and tap Refresh. " +
                            "The first time, pick the statuses folder (.Statuses) and tap \"Use this folder\"."
                    ),
                    color = c.muted, fontSize = 12.sp
                )
                if (currentUri.isBlank()) {
                    GradientButton(l.t("اختيار مجلد الحالات", "Choose statuses folder")) {
                        picker.launch(waHintUri(variant))
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton(
                            l.t("تحديث", "Refresh"),
                            modifier = Modifier.weight(1f)
                        ) { vm.loadStatuses(variant) }
                        OutlineButton(
                            l.t("تغيير المجلد", "Change folder"),
                            modifier = Modifier.weight(1f)
                        ) { picker.launch(waHintUri(variant)) }
                    }
                }
                if (loading) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                }
                err?.let { Text(it.get(l.ar), color = c.muted, fontSize = 13.sp) }
            }
        }

        items(list, key = { it.uri }) { st ->
            StatusCard(
                item = st,
                saved = st.uri in savedSet,
                onSave = {
                    vm.saveStatus(st) { ok ->
                        if (ok) savedSet.add(st.uri)
                        Toast.makeText(
                            context,
                            if (ok) l.t("تم الحفظ في المعرض", "Saved to gallery")
                            else l.t("فشل الحفظ", "Save failed"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            )
        }
    }
}

@Composable
fun StatusCard(item: StatusItem, saved: Boolean, onSave: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val shape = RoundedCornerShape(16.dp)
    val bmp by produceState<ImageBitmap?>(initialValue = null, key1 = item.uri) {
        value = withContext(Dispatchers.IO) {
            loadThumb(context, Uri.parse(item.uri), item.mime)?.asImageBitmap()
        }
    }

    Column(
        Modifier
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .background(c.bg)
                .clickable {
                    try {
                        val i = Intent(Intent.ACTION_VIEW)
                            .setDataAndType(Uri.parse(item.uri), item.mime)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        context.startActivity(i)
                    } catch (e: Exception) {
                        Toast.makeText(context, l.t("تعذر فتح الملف", "Couldn't open the file"), Toast.LENGTH_SHORT).show()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                Image(
                    bitmap = b,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Text(if (item.isVideo) "🎬" else "🖼", fontSize = 30.sp, modifier = Modifier.alpha(0.6f))
            }
            if (item.isVideo) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x99000000))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) { Text("▶", color = Color.White, fontSize = 11.sp) }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(40.dp)
                .background(BrandBrush, alpha = if (saved) 0.45f else 1f)
                .clickable(onClick = onSave),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (saved) l.t("تم الحفظ ✓", "Saved ✓") else l.t("حفظ", "Save"),
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

// ============================== الشريط السفلي ==============================
@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val tabs = listOf(
        "⬇️" to l.t("تحميل", "Download"),
        "💬" to l.t("حالات واتساب", "WA Status"),
        "⚙️" to l.t("الإعدادات", "Settings")
    )
    Column(Modifier.fillMaxWidth().background(c.card)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.stroke))
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            tabs.forEachIndexed { i, (icon, label) ->
                val sel = i == selected
                Column(
                    Modifier
                        .weight(1f)
                        .clickable { onSelect(i) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icon, fontSize = 20.sp, modifier = Modifier.alpha(if (sel) 1f else 0.5f))
                    Text(
                        label, fontSize = 11.sp,
                        color = if (sel) Purple else c.muted,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
