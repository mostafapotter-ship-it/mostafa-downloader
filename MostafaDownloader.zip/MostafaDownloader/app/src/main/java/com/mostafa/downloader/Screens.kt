package com.mostafa.downloader

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.SslErrorHandler
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun labelText(l: Lang, label: String): String =
    if (label == "BEST" || label == "أفضل جودة") l.t("أفضل جودة", "Best quality") else label

// ============================== الرئيسية ==============================
@Composable
fun HomeScreen(
    vm: DownloaderViewModel,
    initialText: String,
    focusTick: Int,
    onSharedConsumed: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenWhatsApp: () -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    val state by vm.state.collectAsState()
    val history by vm.history.collectAsState()
    val queue by vm.queue.collectAsState()
    val upd by vm.update.collectAsState()
    var input by rememberSaveable { mutableStateOf(vm.extractUrl(initialText) ?: "") }
    var mode by rememberSaveable { mutableStateOf(0) }
    var audioFmt by rememberSaveable { mutableStateOf(0) }
    var imageFmt by rememberSaveable { mutableStateOf(0) }
    var quality by rememberSaveable { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    val qualityValues = listOf(0, 1080, 720, 480, 360)
    val qualityLabels = listOf(l.t("الأفضل", "Best"), "1080p", "720p", "480p", "360p")
    val audioLabels = listOf("MP3 320", "MP3 128", "M4A", "WAV")
    val audioIds = listOf("mp3-320", "mp3-128", "m4a", "wav")
    val imageLabels = listOf("JPG", "PNG", "WEBP")
    val imageIds = listOf("jpg", "png", "webp")
    val linkCount = vm.extractUrls(input).size
    val appSettings by vm.settings.collectAsState()

    // --- معاينة / ترجمة / قص ---
    val preview by vm.preview.collectAsState()
    var fmtId by rememberSaveable { mutableStateOf("") }
    var fmtHeight by rememberSaveable { mutableStateOf(0) }
    var fmtMuxed by rememberSaveable { mutableStateOf(false) }
    var subMode by rememberSaveable { mutableStateOf(0) }
    var subLang by rememberSaveable { mutableStateOf(if (l.ar) "ar" else "en") }
    var aiTrans by rememberSaveable { mutableStateOf(0) }
    var trimOn by rememberSaveable { mutableStateOf(false) }
    var trimStart by rememberSaveable { mutableStateOf("") }
    var trimEnd by rememberSaveable { mutableStateOf("") }
    var trimPrecise by rememberSaveable { mutableStateOf(false) }
    val singleLink = if (linkCount == 1) vm.extractUrl(input) else null
    val previewData = preview.data?.takeIf { it.url == singleLink }
    // اختيار الجودة من المعاينة يتلغي لما المعاينة تتغير
    LaunchedEffect(preview.data?.url) { fmtId = ""; fmtHeight = 0; fmtMuxed = false }
    // معاينة تلقائية أول ما يتلصق رابط واحد (من غير ضغط زر)
    LaunchedEffect(singleLink, state.ready) {
        val u = singleLink
        if (u != null && state.ready && preview.url != u) {
            kotlinx.coroutines.delay(500)
            vm.loadPreview(u)
        }
    }

    /** quick = تحميل سريع (مشاركة/حافظة): من غير جودة محددة ولا قص */
    fun buildOpts(quick: Boolean = false): DlOptions {
        val usePreviewFmt = !quick && mode == 0 && fmtId.isNotEmpty() && previewData != null
        val clipActive = !quick && trimOn && mode != 2
        return DlOptions(
            mode = mode,
            quality = if (usePreviewFmt) fmtHeight else quality,
            audioFmt = audioIds[audioFmt],
            imageFmt = imageIds[imageFmt],
            formatId = if (usePreviewFmt) fmtId else "",
            muxed = usePreviewFmt && fmtMuxed,
            subMode = if (mode == 0 && !quick && aiTrans == 0) subMode else 0,
            subLang = subLang,
            clipStart = if (clipActive) trimStart else "",
            clipEnd = if (clipActive) trimEnd else "",
            clipPrecise = trimPrecise,
            aiTrans = if (mode == 0 && !quick) aiTrans else 0
        )
    }

    // --- مشاركة رابط للتطبيق: يملأ الخانة ويبدأ التحميل تلقائياً (لو الإعداد شغال) ---
    LaunchedEffect(initialText, state.ready) {
        if (initialText.isNotEmpty() && state.ready) {
            val urls = vm.extractUrls(initialText)
            if (urls.isNotEmpty()) {
                input = urls.joinToString("\n")
                if (appSettings.autoShare) {
                    vm.download(
                        input,
                        buildOpts(quick = true)
                    )
                }
            }
            onSharedConsumed()
        }
    }

    // --- اقتراح لصق رابط من الحافظة (منصات معروفة بس) ---
    var offeredClip by rememberSaveable { mutableStateOf("") }
    var clipUrl by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(focusTick) {
        if (!appSettings.clipSuggest) {
            clipUrl = null
            return@LaunchedEffect
        }
        val txt = try { clipboard.getText()?.text.orEmpty() } catch (e: Exception) { "" }
        val u = vm.extractUrl(txt)
        clipUrl = if (u != null && u != offeredClip && platformOf(u) != null) u else null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        upd.available?.let { r ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(BrandBrush)
                    .clickable { onOpenSettings() }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    l.t("يوجد تحديث جديد للتطبيق", "A new app update is available"),
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
                Text(l.t("تحديث ←", "Update →"), color = Color.White, fontSize = 13.sp)
            }
            Spacer(Modifier.height(16.dp))
        }

        Image(
            painter = painterResource(R.drawable.ic_logo),
            contentDescription = "MostafaDownloader logo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(116.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(2.dp, BrandBrush, RoundedCornerShape(28.dp))
        )
        Spacer(Modifier.height(14.dp))
        Text("MostafaDownloader", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = c.text)
        Spacer(Modifier.height(20.dp))
        PlatformGrid(detected = platformOf(input), onWhatsApp = onOpenWhatsApp)
        Spacer(Modifier.height(24.dp))

        val clip = clipUrl
        if (clip != null && input.isBlank() && !state.busy) {
            AppCard {
                Text(
                    l.t("لقيت رابط في الحافظة", "Link found in clipboard"),
                    color = c.text, fontWeight = FontWeight.Bold, fontSize = 14.sp
                )
                Text(
                    clip, color = c.muted, fontSize = 12.sp, maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(textDirection = TextDirection.Ltr)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        offeredClip = clip
                        clipUrl = null
                        input = clip
                        if (state.ready) {
                            vm.download(
                                clip,
                                buildOpts(quick = true)
                            )
                        }
                    }) { Text(l.t("تحميل", "Download"), color = Cyan, fontWeight = FontWeight.Bold) }
                    TextButton(onClick = {
                        offeredClip = clip
                        clipUrl = null
                        input = clip
                    }) { Text(l.t("لصق بس", "Paste only"), color = Cyan) }
                    TextButton(onClick = {
                        offeredClip = clip
                        clipUrl = null
                    }) { Text(l.t("تجاهل", "Dismiss"), color = c.muted) }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        AppCard {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(l.t("رابط الفيديو", "Video link")) },
                textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 14.sp),
                minLines = 1,
                maxLines = 4,
                shape = RoundedCornerShape(14.dp),
                trailingIcon = {
                    if (input.isBlank()) {
                        TextButton(
                            onClick = { input = clipboard.getText()?.text.orEmpty() }
                        ) { Text(l.t("لصق", "Paste"), color = Cyan, fontWeight = FontWeight.Bold) }
                    } else {
                        TextButton(onClick = { input = "" }) {
                            Text(l.t("مسح", "Clear"), color = c.muted)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = c.stroke,
                    focusedTextColor = c.text,
                    unfocusedTextColor = c.text,
                    disabledTextColor = c.muted,
                    focusedLabelColor = Purple,
                    unfocusedLabelColor = c.muted,
                    cursorColor = Purple
                )
            )

            if (input.isNotBlank()) {
                TextButton(
                    onClick = { input = (input.trimEnd() + "\n" + clipboard.getText()?.text.orEmpty()).trim() }
                ) {
                    Text(
                        l.t("＋ إضافة رابط تاني من الحافظة", "+ Add another link from clipboard"),
                        color = Cyan, fontSize = 12.sp
                    )
                }
            }
            val linkSite = CookieStore.siteOfUrl(input)
            if ("/stories/" in input && linkSite != null && !CookieStore.isLoggedIn(context, linkSite)) {
                Text(
                    l.t(
                        "الاستوري محتاجة تسجيل دخول: افتح تبويب الاستوريهات",
                        "Stories need sign-in: open the Stories tab"
                    ),
                    color = ErrorC, fontSize = 12.sp
                )
            }

            PreviewSection(
                vm = vm,
                ps = preview,
                link = singleLink,
                ready = state.ready,
                mode = mode,
                selectedId = fmtId
            ) { f ->
                fmtId = f?.id ?: ""
                fmtHeight = f?.height ?: 0
                fmtMuxed = f?.muxed ?: false
            }

            SectionLabel(l.t("النوع", "Type"))
            Segmented(
                options = listOf(l.t("🎬  فيديو", "🎬  Video"), l.t("🎵  صوت", "🎵  Audio"), l.t("🖼  صورة", "🖼  Image")),
                selected = mode
            ) { mode = it }

            when (mode) {
                0 -> {
                    SectionLabel(l.t("الجودة", "Quality"))
                    Segmented(
                        options = qualityLabels,
                        selected = if (fmtId.isNotEmpty() && previewData != null) -1
                        else qualityValues.indexOf(quality).coerceAtLeast(0)
                    ) { fmtId = ""; quality = qualityValues[it] }
                }
                1 -> {
                    SectionLabel(l.t("صيغة الصوت", "Audio format"))
                    Segmented(options = audioLabels, selected = audioFmt) { audioFmt = it }
                }
                else -> {
                    SectionLabel(l.t("صيغة الصورة (غلاف الفيديو)", "Image format (video cover)"))
                    Segmented(options = imageLabels, selected = imageFmt) { imageFmt = it }
                }
            }

            if (mode == 0) {
                SubtitleSection(
                    subMode = subMode,
                    onMode = { subMode = it; if (it != 0) aiTrans = 0 },
                    subLang = subLang,
                    onLang = { subLang = it },
                    info = previewData
                )
                AiTransSection(
                    mode = aiTrans,
                    onMode = { aiTrans = it; if (it != 0) subMode = 0 },
                    hasKey = appSettings.groqKey.isNotBlank()
                )
            }
            if (mode != 2 && !(mode == 0 && subMode == 1)) {
                TrimSection(
                    on = trimOn,
                    onOn = { trimOn = it },
                    start = trimStart,
                    onStart = { trimStart = it },
                    end = trimEnd,
                    onEnd = { trimEnd = it },
                    precise = trimPrecise,
                    onPrecise = { trimPrecise = it },
                    durationSec = previewData?.duration ?: 0L
                )
            }

            GradientButton(
                text = when {
                    state.busy -> l.t("＋ إضافة للطابور", "＋ Add to queue")
                    linkCount > 1 -> l.t("تحميل الكل ($linkCount)", "Download all ($linkCount)")
                    else -> l.t("تحميل", "Download")
                },
                enabled = state.ready && input.isNotBlank()
            ) {
                vm.download(
                    input,
                    buildOpts()
                )
            }

            if (state.busy) {
                if (state.progress > 0f) {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                    Text(
                        "${(state.progress * 100).toInt()}%",
                        color = Cyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    if (state.detail.isNotEmpty()) {
                        Text(
                            state.detail,
                            color = c.muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                }
            }

            if (state.busy && queue.any { it.status == ST_RUN }) {
                OutlineButton(
                    l.t("⏹ إيقاف التحميل الحالي", "⏹ Stop current download"),
                    Modifier.fillMaxWidth()
                ) { vm.cancelCurrent() }
            }

            Text(
                text = state.message.get(l.ar),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 13.sp,
                color = when {
                    state.isError -> ErrorC
                    !state.busy && state.progress >= 1f -> SuccessC
                    else -> c.muted
                }
            )
        }

        Spacer(Modifier.height(20.dp))

        QueueSection(vm)

        var histQuery by rememberSaveable { mutableStateOf("") }
        var toDelete by remember { mutableStateOf<HistoryItem?>(null) }
        val shownHistory = if (histQuery.isBlank()) history
        else history.filter { it.title.contains(histQuery.trim(), ignoreCase = true) }

        toDelete?.let { item ->
            AlertDialog(
                onDismissRequest = { toDelete = null },
                title = { Text(l.t("حذف التحميل", "Delete download")) },
                text = { Text(item.title, maxLines = 3, overflow = TextOverflow.Ellipsis) },
                confirmButton = {
                    TextButton(onClick = { vm.deleteHistory(item, true); toDelete = null }) {
                        Text(l.t("حذف الملف كمان", "Delete file too"), color = ErrorC, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = { vm.deleteHistory(item, false); toDelete = null }) {
                            Text(l.t("من السجل بس", "History only"))
                        }
                        TextButton(onClick = { toDelete = null }) {
                            Text(l.t("إلغاء", "Cancel"), color = c.muted)
                        }
                    }
                }
            )
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                l.t("سجل التحميلات", "Download history") + " (${history.size})",
                fontWeight = FontWeight.Bold, fontSize = 16.sp, color = c.text
            )
            if (history.isNotEmpty()) {
                TextButton(onClick = { vm.clearHistory() }) {
                    Text(l.t("مسح السجل", "Clear"), color = c.muted)
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        if (history.size > 3) {
            OutlinedTextField(
                value = histQuery,
                onValueChange = { histQuery = it },
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                placeholder = { Text(l.t("🔍 ابحث في السجل", "🔍 Search history"), color = c.muted) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = c.stroke,
                    focusedTextColor = c.text,
                    unfocusedTextColor = c.text,
                    cursorColor = Purple
                )
            )
        }

        if (history.isEmpty()) {
            Text(
                l.t("لا توجد تحميلات بعد", "No downloads yet"),
                color = c.muted, fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }

        shownHistory.forEach { item ->
            val itemShape = RoundedCornerShape(16.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clip(itemShape)
                    .background(c.card)
                    .border(1.dp, c.stroke, itemShape)
                    .clickable {
                        try {
                            val i = Intent(Intent.ACTION_VIEW)
                                .setDataAndType(Uri.parse(item.uri), item.mime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            context.startActivity(i)
                        } catch (e: Exception) {
                            Toast.makeText(
                                context,
                                l.t("تعذر فتح الملف (ممكن يكون اتحذف أو اتنقل)", "Couldn't open the file (it may have been deleted or moved)"),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (item.mime.startsWith("audio")) "🎵" else if (item.mime.startsWith("image")) "🖼" else "🎬", fontSize = 18.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        color = c.text, fontWeight = FontWeight.Medium, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "${labelText(l, item.label)}  •  ${item.date}",
                        fontSize = 11.sp, color = c.muted
                    )
                }
                Text(
                    "⤴",
                    fontSize = 20.sp, color = Cyan,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            try {
                                val send = Intent(Intent.ACTION_SEND)
                                    .setType(item.mime.ifEmpty { "*/*" })
                                    .putExtra(Intent.EXTRA_STREAM, Uri.parse(item.uri))
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                context.startActivity(Intent.createChooser(send, l.t("مشاركة", "Share")))
                            } catch (e: Exception) {
                                Toast.makeText(
                                    context, l.t("تعذرت المشاركة", "Couldn't share the file"), Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .padding(8.dp)
                )
                Text(
                    "🗑",
                    fontSize = 18.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { toDelete = item }
                        .padding(8.dp)
                )
            }
        }
        if (histQuery.isNotBlank() && shownHistory.isEmpty()) {
            Text(
                l.t("مفيش نتائج", "No results"),
                color = c.muted, fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}


// ============================== الطابور ==============================
@Composable
fun QueueSection(vm: DownloaderViewModel) {
    val c = LocalColors.current
    val l = LocalLang.current
    val queue by vm.queue.collectAsState()
    if (queue.isEmpty()) return
    val active = queue.count { it.status == ST_WAIT || it.status == ST_RUN }
    val hasFinished = queue.any { it.status >= ST_DONE }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            l.t("الطابور", "Queue") + " ($active)",
            fontWeight = FontWeight.Bold, fontSize = 16.sp, color = c.text
        )
        Row {
            if (queue.any { it.status == ST_WAIT } && queue.none { it.status == ST_RUN }) {
                TextButton(onClick = { vm.resumeQueue() }) {
                    Text(l.t("▶ استكمال", "▶ Resume"), color = Cyan, fontWeight = FontWeight.Bold)
                }
            }
            if (active > 0) {
                TextButton(onClick = { vm.cancelAll() }) {
                    Text(l.t("إلغاء الكل", "Cancel all"), color = ErrorC)
                }
            }
            if (hasFinished) {
                TextButton(onClick = { vm.clearFinished() }) {
                    Text(l.t("مسح المنتهي", "Clear finished"), color = c.muted)
                }
            }
        }
    }
    Spacer(Modifier.height(6.dp))

    queue.forEach { q ->
        val shape = RoundedCornerShape(16.dp)
        val platformName = platformOf(q.url)?.let { id -> Platforms.firstOrNull { it.id == id }?.name }
            ?: q.url.substringAfter("://").substringBefore('/')
        Column(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
                .clip(shape)
                .background(c.card)
                .border(1.dp, c.stroke, shape)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        platformName, color = c.text, fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    Text(
                        q.url, color = c.muted, fontSize = 11.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = TextStyle(textDirection = TextDirection.Ltr)
                    )
                }
                when (q.status) {
                    ST_WAIT, ST_RUN -> TextButton(onClick = { vm.cancelItem(q.id) }) {
                        Text(l.t("إلغاء", "Cancel"), color = ErrorC)
                    }
                    ST_FAIL, ST_CANCEL -> {
                        TextButton(onClick = { vm.retryItem(q.id) }) {
                            Text(l.t("إعادة", "Retry"), color = Cyan, fontWeight = FontWeight.Bold)
                        }
                        TextButton(onClick = { vm.removeItem(q.id) }) {
                            Text(l.t("إزالة", "Remove"), color = c.muted)
                        }
                    }
                    else -> TextButton(onClick = { vm.removeItem(q.id) }) {
                        Text(l.t("إزالة", "Remove"), color = c.muted)
                    }
                }
            }
            when (q.status) {
                ST_RUN -> {
                    LinearProgressIndicator(
                        progress = { q.progress },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                    Text(
                        "${(q.progress * 100).toInt()}%" + (if (q.detail.isNotEmpty()) "  •  " + q.detail else ""),
                        color = Cyan, fontSize = 12.sp
                    )
                }
                ST_WAIT -> Text(l.t("في الانتظار", "Waiting"), color = c.muted, fontSize = 12.sp)
                ST_DONE -> Text(l.t("تم ✓", "Done ✓"), color = SuccessC, fontSize = 12.sp)
                ST_CANCEL -> Text(l.t("تم الإلغاء", "Cancelled"), color = c.muted, fontSize = 12.sp)
                else -> Text(
                    (q.error?.get(l.ar) ?: l.t("فشل", "Failed")).lines().firstOrNull().orEmpty(),
                    color = ErrorC, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
    Spacer(Modifier.height(14.dp))
}

// ============================== الإعدادات ==============================
@Composable
fun SettingsScreen(vm: DownloaderViewModel) {
    val c = LocalColors.current
    val l = LocalLang.current
    val s by vm.settings.collectAsState()
    val upd by vm.update.collectAsState()
    val state by vm.state.collectAsState()
    val engineMsg by vm.engineMsg.collectAsState()
    val ctx = LocalContext.current
    val notifPrefs = remember { ctx.getSharedPreferences("notif", android.content.Context.MODE_PRIVATE) }
    var notifOn by remember { mutableStateOf(notifPrefs.getBoolean("update_notifs", true)) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text(l.t("الإعدادات", "Settings"), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = c.text)

        AppCard {
            SectionLabel(l.t("اللغة", "Language"))
            Segmented(
                options = listOf("العربية", "English"),
                selected = if (s.lang == "ar") 0 else 1
            ) { vm.setLang(if (it == 0) "ar" else "en") }
        }

        AppCard {
            SectionLabel(l.t("التحميل", "Downloads"))
            Text(
                l.t("بدء التحميل تلقائياً عند مشاركة رابط للتطبيق", "Start downloading automatically when a link is shared to the app"),
                color = c.muted, fontSize = 12.sp
            )
            Segmented(
                options = listOf(l.t("تشغيل", "On"), l.t("إيقاف", "Off")),
                selected = if (s.autoShare) 0 else 1
            ) { vm.setAutoShare(it == 0) }
            Text(
                l.t("التحميل على الواي فاي فقط (يوفر باقة الموبايل)", "Download on Wi-Fi only (saves mobile data)"),
                color = c.muted, fontSize = 12.sp
            )
            Segmented(
                options = listOf(l.t("تشغيل", "On"), l.t("إيقاف", "Off")),
                selected = if (s.wifiOnly) 0 else 1
            ) { vm.setWifiOnly(it == 0) }
            Text(
                l.t(
                    "التحميل السريع (aria2c بـ 16 اتصال). لو حسيت إنه أبطأ على منصة معينة، جرّب إيقافه.",
                    "Fast mode (aria2c, 16 connections). If a platform feels slower, try turning it off."
                ),
                color = c.muted, fontSize = 12.sp
            )
            Segmented(
                options = listOf(l.t("تشغيل", "On"), l.t("إيقاف", "Off")),
                selected = if (s.fastEngine) 0 else 1
            ) { vm.setFastEngine(it == 0) }
            Text(
                l.t(
                    "اقتراح الرابط من الحافظة عند فتح التطبيق (بيقرا الحافظة بس وانت فاتح التطبيق، ومش بيتبعت لأي مكان)",
                    "Suggest a link from the clipboard when the app opens (read only while the app is open, never sent anywhere)"
                ),
                color = c.muted, fontSize = 12.sp
            )
            Segmented(
                options = listOf(l.t("تشغيل", "On"), l.t("إيقاف", "Off")),
                selected = if (s.clipSuggest) 0 else 1
            ) { vm.setClipSuggest(it == 0) }
        }

        AppCard {
            SectionLabel(l.t("ترجمة الكلام التلقائية (Groq)", "Auto speech translation (Groq)"))
            Text(
                l.t(
                    "اعمل حساب مجاني على console.groq.com ← API Keys ← Create، وحط المفتاح هنا. المفتاح بيتحفظ على جهازك بس.",
                    "Create a free account at console.groq.com → API Keys → Create, and paste the key here. It's stored on your device only."
                ),
                color = c.muted, fontSize = 12.sp
            )
            var keyText by remember { mutableStateOf(s.groqKey) }
            OutlinedTextField(
                value = keyText,
                onValueChange = { keyText = it; vm.setGroqKey(it.trim()) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("gsk_...", color = c.muted) },
                singleLine = true,
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = c.stroke,
                    focusedTextColor = c.text,
                    unfocusedTextColor = c.text,
                    cursorColor = Purple
                )
            )
            val testRes by vm.aiTest.collectAsState()
            OutlineButton(
                l.t("🧪 اختبار الترجمة (ffmpeg + المفتاح + الترجمة)", "🧪 Test translation (ffmpeg + key + translate)"),
                Modifier.fillMaxWidth()
            ) { vm.runAiTest() }
            testRes?.let { Text(it, color = c.text, fontSize = 12.sp) }
        }

        AppCard {
            SectionLabel(l.t("المظهر", "Appearance"))
            Segmented(
                options = listOf(l.t("تلقائي", "System"), l.t("فاتح", "Light"), l.t("داكن", "Dark"), l.t("أسود", "Black")),
                selected = when (s.theme) { "system" -> 0; "light" -> 1; "amoled" -> 3; else -> 2 }
            ) { vm.setTheme(when (it) { 0 -> "system"; 1 -> "light"; 3 -> "amoled"; else -> "dark" }) }
        }

        AppCard {
            SectionLabel(l.t("لون التطبيق", "Theme color"))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AccentThemes.forEach { t ->
                    val sel = t.id == s.accent
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(t.primary, t.secondary)))
                            .border(if (sel) 3.dp else 1.dp, if (sel) c.text else c.stroke, CircleShape)
                            .clickable {
                                vm.setAccent(t.id)
                                Accent.set(t)
                            }
                    )
                }
            }
            val cur = Accent.byId(s.accent)
            Text(l.t(cur.nameAr, cur.nameEn), color = c.muted, fontSize = 12.sp)
        }

        AppCard {
            SectionLabel(l.t("تحديث التطبيق", "App update"))
            Text(
                l.t("الإصدار الحالي", "Current version") + ": v${BuildConfig.VERSION_NAME}",
                color = c.text, fontSize = 14.sp
            )
            val r = upd.available
            if (r != null) {
                Text(
                    l.t("إصدار جديد متاح", "New version available") + ": ${r.name}",
                    color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
                val abi = Updater.deviceAbi()
                val patchAsset = r.patch(BuildConfig.VERSION_CODE, abi)
                val sizeBytes = patchAsset?.size ?: r.full(abi)?.size ?: 0L
                if (sizeBytes > 0) {
                    Text(
                        l.t("حجم التحديث", "Update size") + ": " + fmtSize(sizeBytes) +
                            (if (patchAsset != null) l.t(" (التغييرات فقط)", " (changes only)") else ""),
                        color = c.muted, fontSize = 12.sp
                    )
                }
                if (r.notes.isNotBlank()) {
                    Text(r.notes.take(300), color = c.muted, fontSize = 12.sp)
                }
                GradientButton(
                    text = l.t("تحديث الآن", "Update now"),
                    enabled = !upd.downloading
                ) { vm.installUpdate() }
                if (upd.downloading) {
                    LinearProgressIndicator(
                        progress = { upd.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                }
            } else {
                GradientButton(
                    text = if (upd.checking) l.t("جاري التحقق...", "Checking...")
                    else l.t("التحقق من التحديثات", "Check for updates"),
                    enabled = !upd.checking
                ) { vm.checkUpdate(true) }
            }
            upd.message?.let {
                Text(it.get(l.ar), color = c.muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth())
            }
        }

        AppCard {
            SectionLabel(l.t("الإشعارات", "Notifications"))
            Text(
                l.t(
                    "إشعار التحديث بيوصلك حتى لو التطبيق مقفول.",
                    "Update alerts reach you even when the app is closed."
                ),
                color = c.muted, fontSize = 12.sp
            )
            Segmented(
                options = listOf(l.t("تشغيل", "On"), l.t("إيقاف", "Off")),
                selected = if (notifOn) 0 else 1
            ) {
                notifOn = it == 0
                notifPrefs.edit().putBoolean("update_notifs", notifOn).apply()
            }
            OutlineButton(l.t("إرسال إشعار تجريبي", "Send a test notification"), Modifier.fillMaxWidth()) {
                Notifier.test(ctx)
            }
            OutlineButton(
                l.t("السماح بالعمل في الخلفية (بدون قيود البطارية)", "Allow background activity (no battery limits)"),
                Modifier.fillMaxWidth()
            ) {
                try {
                    ctx.startActivity(
                        Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:" + ctx.packageName))
                    )
                } catch (e: Exception) {
                    try {
                        ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (e2: Exception) {
                        Toast.makeText(ctx, "Not available", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            OutlineButton(
                l.t("إعدادات التطبيق (التشغيل التلقائي / الإشعارات)", "App settings (auto-start / notifications)"),
                Modifier.fillMaxWidth()
            ) {
                try {
                    ctx.startActivity(
                        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.parse("package:" + ctx.packageName))
                    )
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Not available", Toast.LENGTH_SHORT).show()
                }
            }
            Text(
                l.t(
                    "على أوبو/ريلمي/شاومي/فيفو: فعّل «التشغيل التلقائي» للتطبيق وخلّي البطارية «بدون قيود»، وإلا النظام بيقفل الفحص في الخلفية.",
                    "On Oppo/Realme/Xiaomi/Vivo: enable \"Auto-start\" for the app and set battery to \"No restrictions\", otherwise the system kills background checks."
                ),
                color = c.muted, fontSize = 12.sp
            )
            var bgInfo by remember { mutableStateOf(UpdateCheckWorker.lastInfo(ctx, l.ar)) }
            Text(bgInfo, color = c.muted, fontSize = 12.sp)
            OutlineButton(l.t("فحص التحديث دلوقتي (زي الخلفية)", "Run the background check now"), Modifier.fillMaxWidth()) {
                AppScope.io.launch {
                    UpdateCheckWorker.check(ctx.applicationContext, force = true)
                    bgInfo = UpdateCheckWorker.lastInfo(ctx.applicationContext, l.ar)
                }
            }
        }

        AppCard {
            SectionLabel(l.t("محرك التحميل", "Download engine"))
            Text(
                l.t(
                    "لو منصة وقفت عن التحميل، حدّث المحرك وجرّب تاني.",
                    "If a platform stops working, update the engine and try again."
                ),
                color = c.muted, fontSize = 13.sp
            )
            OutlineButton(
                text = l.t("تحديث محرك التحميل", "Update download engine"),
                modifier = Modifier.fillMaxWidth(),
                enabled = state.ready && !state.busy
            ) { vm.updateEngine() }
            engineMsg?.let { Text(it.get(l.ar), color = c.muted, fontSize = 13.sp) }
        }

        AboutCard()
        Spacer(Modifier.height(24.dp))
    }
}

// ============================== حالات واتساب ==============================
@Composable
fun WhatsAppScreen(vm: DownloaderViewModel) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val s by vm.settings.collectAsState()
    val list by vm.statuses.collectAsState()
    val loading by vm.waLoading.collectAsState()
    val err by vm.waError.collectAsState()
    var variant by rememberSaveable { mutableStateOf(0) }
    val savedSet = remember { mutableStateListOf<String>() }
    val currentUri = if (variant == 0) s.waUri else s.wabUri

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            vm.setWaUri(variant, uri.toString())
        }
    }

    LaunchedEffect(variant, currentUri) { vm.loadStatuses(variant) }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    l.t("حالات واتساب", "WhatsApp Status"),
                    fontSize = 24.sp, fontWeight = FontWeight.Bold, color = c.text
                )
                Segmented(
                    options = listOf("WhatsApp", "WhatsApp Business"),
                    selected = variant
                ) { variant = it }
                Text(
                    l.t(
                        "افتح الحالة في واتساب الأول وشوفها، وبعدين ارجع هنا واضغط تحديث. " +
                            "أول مرة اختار مجلد الحالات (.Statuses) واضغط \"استخدام هذا المجلد\".",
                        "Open and view the status in WhatsApp first, then come back and tap Refresh. " +
                            "The first time, pick the statuses folder (.Statuses) and tap \"Use this folder\"."
                    ),
                    color = c.muted, fontSize = 12.sp
                )
                if (currentUri.isBlank()) {
                    GradientButton(l.t("اختيار مجلد الحالات", "Choose statuses folder")) {
                        picker.launch(waHintUri(variant))
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton(
                            l.t("تحديث", "Refresh"),
                            modifier = Modifier.weight(1f)
                        ) { vm.loadStatuses(variant) }
                        OutlineButton(
                            l.t("تغيير المجلد", "Change folder"),
                            modifier = Modifier.weight(1f)
                        ) { picker.launch(waHintUri(variant)) }
                    }
                }
                if (loading) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                }
                err?.let { Text(it.get(l.ar), color = c.muted, fontSize = 13.sp) }
            }
        }

        items(list, key = { it.uri }) { st ->
            StatusCard(
                item = st,
                saved = st.uri in savedSet,
                onSave = {
                    vm.saveStatus(st) { ok ->
                        if (ok) savedSet.add(st.uri)
                        Toast.makeText(
                            context,
                            if (ok) l.t("تم الحفظ في المعرض", "Saved to gallery")
                            else l.t("فشل الحفظ", "Save failed"),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            )
        }
    }
}

@Composable
fun StatusCard(item: StatusItem, saved: Boolean, onSave: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val shape = RoundedCornerShape(16.dp)
    val bmp by produceState<ImageBitmap?>(initialValue = null, key1 = item.uri) {
        value = withContext(Dispatchers.IO) {
            loadThumb(context, Uri.parse(item.uri), item.mime)?.asImageBitmap()
        }
    }

    Column(
        Modifier
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .background(c.bg)
                .clickable {
                    try {
                        val i = Intent(Intent.ACTION_VIEW)
                            .setDataAndType(Uri.parse(item.uri), item.mime)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        context.startActivity(i)
                    } catch (e: Exception) {
                        Toast.makeText(context, l.t("تعذر فتح الملف", "Couldn't open the file"), Toast.LENGTH_SHORT).show()
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                Image(
                    bitmap = b,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Text(if (item.isVideo) "🎬" else "🖼", fontSize = 30.sp, modifier = Modifier.alpha(0.6f))
            }
            if (item.isVideo) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x99000000))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) { Text("▶", color = Color.White, fontSize = 11.sp) }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(40.dp)
                .background(BrandBrush, alpha = if (saved) 0.45f else 1f)
                .clickable(onClick = onSave),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (saved) l.t("تم الحفظ ✓", "Saved ✓") else l.t("حفظ", "Save"),
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

// ============================== الشريط السفلي ==============================
@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val tabs = listOf(
        "⬇️" to l.t("تحميل", "Download"),
        "💬" to l.t("حالات واتساب", "WA Status"),
        "🎞️" to l.t("الاستوريهات", "Stories"),
        "⚙️" to l.t("الإعدادات", "Settings")
    )
    Column(Modifier.fillMaxWidth().background(c.card)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.stroke))
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            tabs.forEachIndexed { i, (icon, label) ->
                val sel = i == selected
                Column(
                    Modifier
                        .weight(1f)
                        .clickable { onSelect(i) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icon, fontSize = 20.sp, modifier = Modifier.alpha(if (sel) 1f else 0.5f))
                    Text(
                        label, fontSize = 11.sp,
                        color = if (sel) Purple else c.muted,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}


// ============================== حسابات + تسجيل الدخول ==============================
@Composable
fun AccountRow(
    name: String,
    loggedIn: Boolean,
    onSignIn: () -> Unit,
    onImport: () -> Unit,
    onSignOut: () -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(name, color = c.text, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Text(
                    if (loggedIn) l.t("مسجّل دخول", "Signed in") else l.t("غير مسجّل", "Not signed in"),
                    color = if (loggedIn) SuccessC else c.muted, fontSize = 12.sp
                )
            }
            OutlineButton(
                if (loggedIn) l.t("تسجيل خروج", "Sign out") else l.t("تسجيل دخول", "Sign in")
            ) { if (loggedIn) onSignOut() else onSignIn() }
        }
        if (!loggedIn) {
            TextButton(onClick = onImport) {
                Text(l.t("متقدم: لصق كوكيز بدل تسجيل الدخول", "Advanced: paste cookies instead"), color = c.muted, fontSize = 12.sp)
            }
        }
    }
}

private const val CHROME_UA =
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/124.0.0.0 Mobile Safari/537.36"

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/124.0.0.0 Safari/537.36"

private const val TEST_HTML =
    "<html><body style='margin:24px;background:#ffffff;color:#000000;font-family:sans-serif'>" +
        "<h1>WebView OK</h1><p>If you can read this, the WebView is working.</p></body></html>"

@Suppress("DEPRECATION")
private fun disableForceDark(w: WebSettings) {
    if (Build.VERSION.SDK_INT >= 29) w.forceDark = WebSettings.FORCE_DARK_OFF
}

private fun fmtSize(bytes: Long): String =
    String.format(java.util.Locale.US, "%.1f MB", bytes / 1048576.0)

@Composable
fun LoginScreen(site: String, onClose: (Boolean) -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val url = if (site == "ig") "https://www.instagram.com/accounts/login/" else "https://m.facebook.com/login"
    var progress by remember { mutableStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var diag by remember { mutableStateOf("") }
    var safe by remember { mutableStateOf(false) }
    var desktop by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf(0) }
    var debug by remember { mutableStateOf(false) }
    val closeState by rememberUpdatedState(onClose)
    val webRef = remember { arrayOfNulls<WebView>(1) }
    val wvInfo = remember {
        if (Build.VERSION.SDK_INT >= 26) {
            val p = WebView.getCurrentWebViewPackage()
            if (p != null) "${p.packageName} ${p.versionName}" else "no WebView"
        } else "WebView"
    }

    DisposableEffect(Unit) {
        onDispose {
            webRef[0]?.destroy()
            webRef[0] = null
        }
    }

    // يلتقط الجلسة تلقائياً أول ما يتسجّل الدخول (من غير ما تضغط الزر)
    LaunchedEffect(site) {
        delay(3000)
        while (true) {
            val ok = CookieStore.saveFromWebView(context, site)
            found = CookieStore.lastCount
            if (ok) {
                Toast.makeText(context, l.t("تم تسجيل الدخول ✓", "Signed in ✓"), Toast.LENGTH_SHORT).show()
                closeState(true)
                break
            }
            delay(1500)
        }
    }

    Column(Modifier.fillMaxSize().background(c.bg)) {
        if (progress in 1..99) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().height(4.dp),
                color = Cyan,
                trackColor = c.stroke
            )
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    webRef[0] = this
                    setBackgroundColor(android.graphics.Color.WHITE)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    settings.userAgentString = CHROME_UA
                    disableForceDark(settings)
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            error = null
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            view?.evaluateJavascript(
                                "(function(){return document.title+' | html='+document.documentElement.outerHTML.length})()"
                            ) { v -> diag = v ?: "" }
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            err: WebResourceError?
                        ) {
                            if (request?.isForMainFrame == true) {
                                error = err?.description?.toString() ?: "Unknown error"
                            }
                        }

                        override fun onReceivedSslError(
                            view: WebView?,
                            handler: SslErrorHandler?,
                            e: SslError?
                        ) {
                            handler?.cancel()
                            error = "SSL error"
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                        }
                    }
                    loadUrl(url)
                }
            }
        )
        Text(
            if (error != null) l.t("تعذر تحميل الصفحة", "Couldn't load the page") + ": " + error
            else if (progress in 1..99) l.t("جاري التحميل...", "Loading...") + " $progress%"
            else l.t(
                "سجّل دخول بحسابك، وبعد ما تظهر الصفحة الرئيسية اضغط \"تم تسجيل الدخول\".",
                "Sign in, and once your home page appears tap \"I'm signed in\"."
            ),
            color = if (error != null) ErrorC else c.muted,
            fontSize = 12.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().clickable { debug = !debug }.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        if (debug) {
            Text(
                "$wvInfo  $diag  cookies=$found",
                color = c.muted, fontSize = 10.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlineButton(l.t("إلغاء", "Cancel"), Modifier.weight(1f)) { onClose(false) }
            OutlineButton(l.t("إعادة تحميل", "Reload"), Modifier.weight(1f)) {
                error = null
                webRef[0]?.loadUrl(url)
            }
            GradientButton(l.t("تم تسجيل الدخول", "I'm signed in"), Modifier.weight(1.4f)) {
                if (CookieStore.saveFromWebView(context, site)) {
                    Toast.makeText(context, l.t("تم تسجيل الدخول ✓", "Signed in ✓"), Toast.LENGTH_SHORT).show()
                    onClose(true)
                } else {
                    Toast.makeText(
                        context,
                        l.t("تسجيل الدخول لسه ما اكتملش", "Sign-in isn't complete yet") +
                            " (cookies: " + CookieStore.lastCount + ")",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        if (debug) {
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlineButton(l.t("اختبار", "Test"), Modifier.weight(1f)) {
                webRef[0]?.loadDataWithBaseURL("https://example.com", TEST_HTML, "text/html", "UTF-8", null)
            }
            OutlineButton(
                if (safe) l.t("آمن: يعمل", "Safe: ON") else l.t("وضع آمن", "Safe mode"),
                Modifier.weight(1f)
            ) {
                safe = !safe
                webRef[0]?.setLayerType(if (safe) View.LAYER_TYPE_SOFTWARE else View.LAYER_TYPE_NONE, null)
                error = null
                webRef[0]?.loadUrl(url)
            }
            OutlineButton(
                if (desktop) "Desktop: ON" else "Desktop",
                Modifier.weight(1f)
            ) {
                desktop = !desktop
                webRef[0]?.settings?.userAgentString = if (desktop) DESKTOP_UA else CHROME_UA
                error = null
                webRef[0]?.loadUrl(url)
            }
        }
        }
    }
}

@Composable
fun CookieImportScreen(site: String, onClose: (Boolean) -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    val name = if (site == "ig") "Instagram" else "Facebook"

    Column(
        Modifier
            .fillMaxSize()
            .background(c.bg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            l.t("استيراد كوكيز ", "Import cookies for ") + name,
            fontSize = 22.sp, fontWeight = FontWeight.Bold, color = c.text
        )
        Text(
            l.t(
                "طريقة متقدمة: صدّر ملف cookies.txt من متصفح مسجّل فيه دخول (مثلاً Kiwi Browser مع إضافة Get cookies.txt LOCALLY) والصق النص كله هنا.",
                "Advanced: export cookies.txt from a browser where you're signed in (e.g. Kiwi Browser with the Get cookies.txt LOCALLY extension) and paste the whole text here."
            ),
            color = c.muted, fontSize = 13.sp
        )
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = 6,
            maxLines = 12,
            textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 12.sp),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Purple,
                unfocusedBorderColor = c.stroke,
                focusedTextColor = c.text,
                unfocusedTextColor = c.text,
                cursorColor = Purple
            )
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineButton(l.t("لصق", "Paste"), Modifier.weight(1f)) {
                text = clipboard.getText()?.text.orEmpty()
            }
            OutlineButton(l.t("إلغاء", "Cancel"), Modifier.weight(1f)) { onClose(false) }
        }
        GradientButton(l.t("حفظ", "Save")) {
            if (CookieStore.saveFromText(context, site, text)) {
                onClose(true)
            } else {
                Toast.makeText(
                    context,
                    l.t("النص مش صحيح أو ناقص كوكيز الدخول", "Invalid text or missing sign-in cookies"),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}

// ============================== About / Developer (English only) ==============================
private const val DEV_NAME = "Mostafa Mahmoud"
private const val DEV_EMAIL = "mostafa.potter@gmail.com"

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = c.muted, fontSize = 13.sp)
        Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun AboutCard() {
    val c = LocalColors.current
    val ctx = LocalContext.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        AppCard {
            SectionLabel("ABOUT")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_logo),
                    contentDescription = "MostafaDownloader logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(15.dp))
                )
                Column {
                    Text("MostafaDownloader", color = c.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("Version ${BuildConfig.VERSION_NAME}", color = c.muted, fontSize = 12.sp)
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(c.stroke))
            InfoRow("Developer", DEV_NAME, c.text)
            InfoRow("Contact", DEV_EMAIL, Cyan)
            GradientButton("Contact Developer") {
                try {
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$DEV_EMAIL"))
                        .putExtra(Intent.EXTRA_SUBJECT, "MostafaDownloader v${BuildConfig.VERSION_NAME} - Feedback")
                    ctx.startActivity(i)
                } catch (e: Exception) {
                    Toast.makeText(ctx, "No email app found", Toast.LENGTH_SHORT).show()
                }
            }
            Text(
                "\u00A9 2026 $DEV_NAME. All rights reserved.",
                color = c.muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}


// ============================== تبويب الاستوريهات ==============================
@Composable
fun StoriesScreen(
    vm: DownloaderViewModel,
    cookieTick: Int,
    onLogin: (String) -> Unit,
    onImport: (String) -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    val ctx = LocalContext.current
    val state by vm.state.collectAsState()
    val clipboard = LocalClipboardManager.current
    var tick by remember { mutableStateOf(0) }
    var input by rememberSaveable { mutableStateOf("") }
    val igIn = remember(cookieTick, tick) { CookieStore.isLoggedIn(ctx, "ig") }
    val fbIn = remember(cookieTick, tick) { CookieStore.isLoggedIn(ctx, "fb") }
    val site = CookieStore.siteOfUrl(input)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text(l.t("الاستوريهات", "Stories"), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = c.text)

        AppCard {
            SectionLabel(l.t("حسابات الاستوريهات", "Story accounts"))
            Text(
                l.t(
                    "عشان تحمّل استوريهات إنستجرام وفيسبوك لازم تسجّل دخول بحسابك. الجلسة بتتحفظ على جهازك بس، وتقدر تعمل تسجيل خروج في أي وقت.",
                    "To download Instagram and Facebook stories you need to sign in with your account. The session is stored on your device only, and you can sign out any time."
                ),
                color = c.muted, fontSize = 12.sp
            )
            AccountRow("Instagram", igIn, { onLogin("ig") }, { onImport("ig") }) {
                CookieStore.logout(ctx, "ig"); tick++
            }
            AccountRow("Facebook", fbIn, { onLogin("fb") }, { onImport("fb") }) {
                CookieStore.logout(ctx, "fb"); tick++
            }
            Text(
                l.t(
                    "تنبيه: استخدام حساب للتحميل الآلي ممكن يعرّضه لقيود من المنصة. الأفضل حساب ثانوي.",
                    "Note: using an account for automated downloads may lead to restrictions by the platform. A secondary account is safer."
                ),
                color = c.muted, fontSize = 11.sp
            )
        }

        AppCard {
            SectionLabel(l.t("تحميل استوري", "Download a story"))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(l.t("رابط الاستوري", "Story link")) },
                textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 14.sp),
                singleLine = true,
                enabled = !state.busy,
                shape = RoundedCornerShape(14.dp),
                trailingIcon = {
                    if (input.isBlank()) {
                        TextButton(
                            onClick = { input = clipboard.getText()?.text.orEmpty() },
                            enabled = !state.busy
                        ) { Text(l.t("لصق", "Paste"), color = Cyan, fontWeight = FontWeight.Bold) }
                    } else {
                        TextButton(onClick = { input = "" }, enabled = !state.busy) {
                            Text(l.t("مسح", "Clear"), color = c.muted)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = c.stroke,
                    focusedTextColor = c.text,
                    unfocusedTextColor = c.text,
                    disabledTextColor = c.muted,
                    focusedLabelColor = Purple,
                    unfocusedLabelColor = c.muted,
                    cursorColor = Purple
                )
            )
            if (input.isNotBlank() && site != null && !CookieStore.isLoggedIn(ctx, site)) {
                Text(
                    l.t(
                        "سجّل دخول للحساب المناسب من الأعلى الأول.",
                        "Sign in to the matching account above first."
                    ),
                    color = ErrorC, fontSize = 12.sp
                )
            }
            GradientButton(
                text = l.t("تحميل الاستوري", "Download story"),
                enabled = state.ready && !state.busy && input.isNotBlank()
            ) { vm.download(input, false, 0) }

            if (state.busy) {
                if (state.progress > 0f) {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = c.stroke
                    )
                }
            }
            if (state.busy && state.progress > 0f) {
                Text(
                    "${(state.progress * 100).toInt()}%" +
                        (if (state.detail.isNotEmpty()) "  •  " + state.detail else ""),
                    color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
            }
            Text(
                text = state.message.get(l.ar),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 13.sp,
                color = when {
                    state.isError -> ErrorC
                    !state.busy && state.progress >= 1f -> SuccessC
                    else -> c.muted
                }
            )
            if (state.isError) {
                OutlineButton(
                    l.t("نسخ نص الخطأ", "Copy error text"),
                    Modifier.fillMaxWidth()
                ) { clipboard.setText(AnnotatedString(state.message.get(l.ar))) }
            }
        }

        AppCard {
            SectionLabel(l.t("الخطوات", "How it works"))
            Text(
                l.t(
                    "1) سجّل دخول بحسابك من الأعلى.\n2) افتح الاستوري في التطبيق الأصلي واضغط مشاركة ← نسخ الرابط.\n3) الصق الرابط هنا واضغط تحميل.",
                    "1) Sign in with your account above.\n2) Open the story in the original app and tap Share → Copy link.\n3) Paste the link here and tap Download."
                ),
                color = c.muted, fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
