package com.mostafa.downloader

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** شاشة افتتاحية قصيرة (حوالي 3 ثواني): اللوجو كبير + اسم التطبيق بخط كبير، وبعدها الشاشة الرئيسية. اللمس بيتخطاها */
@Composable
fun SplashScreen(onFinish: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current

    val logoScale = remember { Animatable(0.45f) }
    val logoAlpha = remember { Animatable(0f) }
    val nameAlpha = remember { Animatable(0f) }
    val nameShift = remember { Animatable(36f) }
    val tagAlpha = remember { Animatable(0f) }
    val lineWidth = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }
    val platAlpha = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Reverse),
        label = "glow"
    )

    // شريط التقدم المتحرك في الأسفل
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(3000, easing = LinearEasing)) }

    LaunchedEffect(Unit) {
        // 1) اللوجو يظهر ويكبر بنطّة خفيفة
        kotlinx.coroutines.coroutineScope {
            launch { logoAlpha.animateTo(1f, tween(500)) }
            launch { logoScale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow)) }
        }
        // 2) الاسم يطلع من تحت
        kotlinx.coroutines.coroutineScope {
            launch { nameAlpha.animateTo(1f, tween(500)) }
            launch { nameShift.animateTo(0f, tween(550, easing = FastOutSlowInEasing)) }
            launch { lineWidth.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        }
        // 3) الشعار الفرعي
        tagAlpha.animateTo(1f, tween(400))
        platAlpha.animateTo(1f, tween(350))
        kotlinx.coroutines.delay(900)
        // 4) خروج ناعم
        exit.animateTo(0f, tween(350))
        onFinish()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(c.bg)
            .graphicsLayer { alpha = exit.value }
            .pointerInput(Unit) { detectTapGestures { onFinish() } },
        contentAlignment = Alignment.Center
    ) {
        // هالة ملونة ورا اللوجو
        Box(
            Modifier
                .size(420.dp)
                .graphicsLayer { alpha = 0.55f * glow * logoAlpha.value }
                .background(
                    Brush.radialGradient(listOf(Purple.copy(alpha = 0.55f), Cyan.copy(alpha = 0.25f), Color.Transparent))
                )
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.ic_splash_logo),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(230.dp)
                    .graphicsLayer {
                        scaleX = logoScale.value
                        scaleY = logoScale.value
                        alpha = logoAlpha.value
                    }
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Mostafa",
                color = Color.White,
                fontSize = 46.sp,
                fontWeight = FontWeight.ExtraBold,
                fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer {
                    alpha = nameAlpha.value
                    translationY = nameShift.value
                }
            )
            Text(
                "Downloader",
                color = Cyan,
                fontSize = 50.sp,
                fontWeight = FontWeight.ExtraBold,
                fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center,
                modifier = Modifier.graphicsLayer {
                    alpha = nameAlpha.value
                    translationY = nameShift.value
                }
            )
            Spacer(Modifier.height(10.dp))
            Text(
                l.t("تحميل سريع .. بكل سهولة", "Fast & easy downloads"),
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.graphicsLayer { alpha = tagAlpha.value }
            )
            Spacer(Modifier.height(26.dp))
            SplashPlatformRow(platAlpha.value)
        }
        // "جاري التحميل..." + شريط التقدم
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
                .graphicsLayer { alpha = logoAlpha.value },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                l.t("جاري التحميل...", "Loading..."),
                color = c.muted,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .width(180.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(c.stroke)
            ) {
                Box(
                    Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress.value)
                        .clip(RoundedCornerShape(50))
                        .background(Brush.horizontalGradient(listOf(Purple, Cyan)))
                )
            }
        }
    }
}
