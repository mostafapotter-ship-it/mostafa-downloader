package com.mostafa.downloader

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** 00:00 أو 1:02:03 */
fun fmtClock(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    val h = t / 3600
    val m = (t % 3600) / 60
    val s = t % 60
    return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(java.util.Locale.US, "%02d:%02d", m, s)
}

private const val THUMBS = 8

/** شاشة قص الفيديو: معاينة + شريط لقطات بمقبضين + حفظ المقطع */
@Composable
fun VideoTrimScreen(vm: DownloaderViewModel, onBack: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val ctx = LocalContext.current
    val tu by vm.trim.collectAsState()

    var picked by rememberSaveable { mutableStateOf("") }
    var startF by rememberSaveable { mutableStateOf(0f) }
    var endF by rememberSaveable { mutableStateOf(1f) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            picked = uri.toString()
            startF = 0f
            endF = 1f
            vm.clearTrim()
        }
    }

    val uri: Uri? = if (picked.isEmpty()) null else Uri.parse(picked)

    // مدة الفيديو + لقطات الشريط
    val info by produceState<Pair<Long, List<Bitmap>>?>(null, picked) {
        value = null
        val u = uri
        if (u == null) return@produceState
        value = withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, u)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val frames = ArrayList<Bitmap>()
                if (dur > 0) {
                    for (i in 0 until THUMBS) {
                        val t = dur * 1000L * i / THUMBS
                        val b = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        if (b != null) {
                            val h = 140
                            val w = (b.width * h / b.height.coerceAtLeast(1)).coerceAtLeast(1)
                            frames.add(Bitmap.createScaledBitmap(b, w, h, true))
                        }
                    }
                }
                dur to frames
            } catch (e: Exception) {
                0L to emptyList<Bitmap>()
            } finally {
                try {
                    r.release()
                } catch (e: Exception) {
                }
            }
        }
    }
    val durMs = info?.first ?: 0L
    val startMs = (startF * durMs).toLong()
    val endMs = (endF * durMs).toLong()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // ---------- هيدر: رجوع + العنوان + مقص ----------
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            val shape = RoundedCornerShape(20.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(c.card)
                    .border(1.dp, c.stroke, shape)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painterResource(R.drawable.ic_arrow_left), null, tint = c.text, modifier = Modifier.size(26.dp))
                }
                Text(
                    l.t("قص الفيديو", "Trim video"),
                    color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                )
                Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                    Icon(painterResource(R.drawable.ic_scissors), null, tint = Cyan, modifier = Modifier.size(26.dp))
                }
            }
        }
        Spacer(Modifier.height(14.dp))

        if (uri == null) {
            // ---------- لسه ما اخترتش فيديو ----------
            AppCard {
                Text(
                    l.t("اختر فيديو من هاتفك لقص جزء منه", "Choose a video from your phone to trim a part of it"),
                    color = c.muted, fontSize = 14.sp
                )
                Spacer(Modifier.height(12.dp))
                GradientButton(l.t("اختيار فيديو", "Choose video"), icon = R.drawable.ic_scissors) {
                    picker.launch("video/*")
                }
            }
            return@Column
        }

        val ready = info
        if (ready == null) {
            Text(l.t("جاري تحميل الفيديو...", "Loading the video..."), color = c.muted, fontSize = 14.sp)
            return@Column
        }
        if (durMs <= 0L) {
            AppCard {
                Text(
                    l.t("تعذّر قراءة الفيديو، اختر فيديو تاني", "Couldn't read this video, choose another one"),
                    color = ErrorC, fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlineButton(l.t("اختيار فيديو", "Choose video"), Modifier.fillMaxWidth()) { picker.launch("video/*") }
            }
            return@Column
        }

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            // ---------- المعاينة ----------
            var playing by remember { mutableStateOf(false) }
            var view by remember { mutableStateOf<VideoView?>(null) }
            val shape = RoundedCornerShape(20.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(shape)
                    .background(Color.Black)
                    .border(1.dp, c.stroke, shape),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { cx ->
                        VideoView(cx).also { v ->
                            v.setVideoURI(uri)
                            v.setOnPreparedListener { mp ->
                                mp.setVolume(1f, 1f)
                                v.seekTo(1)
                            }
                            v.setOnCompletionListener { playing = false }
                            view = v
                        }
                    }
                )
                if (!playing) {
                    Box(
                        Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color(0x99000000))
                            .border(1.5.dp, Cyan, CircleShape)
                            .clickable {
                                view?.let { v ->
                                    v.seekTo(startMs.toInt())
                                    v.start()
                                    playing = true
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(painterResource(R.drawable.ic_play), null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                } else {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .clickable {
                                view?.pause()
                                playing = false
                            }
                    )
                }
            }
            // نوقف التشغيل عند نهاية المقطع المختار
            LaunchedEffect(playing, endMs) {
                while (playing) {
                    val v = view
                    if (v != null && v.currentPosition >= endMs) {
                        v.pause()
                        playing = false
                    }
                    delay(120)
                }
            }

            Spacer(Modifier.height(14.dp))

            // ---------- شريط الوقت ----------
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(fmtClock(startMs), color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    "→  " + fmtClock(endMs) + "   ·   " + fmtClock(endMs - startMs),
                    color = c.muted, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                )
                Text(fmtClock(durMs), color = c.muted, fontSize = 15.sp)
            }
            Spacer(Modifier.height(8.dp))

            // ---------- شريط اللقطات + المقبضين ----------
            val density = LocalDensity.current
            val handleW = 16.dp
            BoxWithConstraints(Modifier.fillMaxWidth().height(64.dp)) {
                val totalPx = with(density) { maxWidth.toPx() }
                val handlePx = with(density) { handleW.toPx() }
                val trackPx = (totalPx - 2 * handlePx).coerceAtLeast(1f)
                val minGap = (1500f / durMs).coerceIn(0.02f, 0.5f)

                // اللقطات (بين المقبضين)
                Row(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = handleW)
                        .clip(RoundedCornerShape(6.dp))
                        .background(c.card)
                ) {
                    ready.second.forEach { bmp ->
                        Image(
                            bitmap = bmp.asImageBitmap(), contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.weight(1f).fillMaxHeight()
                        )
                    }
                }
                // تعتيم خارج المقطع المختار
                val startPx = startF * trackPx
                val endPx = endF * trackPx
                Box(
                    Modifier
                        .offset { IntOffset(handlePx.roundToInt(), 0) }
                        .width(with(density) { startPx.toDp() })
                        .fillMaxHeight()
                        .background(Color(0xAA000000))
                )
                Box(
                    Modifier
                        .offset { IntOffset((handlePx + endPx).roundToInt(), 0) }
                        .width(with(density) { (trackPx - endPx).coerceAtLeast(0f).toDp() })
                        .fillMaxHeight()
                        .background(Color(0xAA000000))
                )
                // إطار المقطع المختار
                Box(
                    Modifier
                        .offset { IntOffset(handlePx.roundToInt() + startPx.roundToInt(), 0) }
                        .width(with(density) { (endPx - startPx).coerceAtLeast(0f).toDp() })
                        .fillMaxHeight()
                        .border(2.dp, Cyan)
                )
                // مقبض البداية
                Box(
                    Modifier
                        .offset { IntOffset(startPx.roundToInt(), 0) }
                        .width(handleW)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
                        .background(Cyan)
                        .pointerInput(durMs, trackPx) {
                            detectHorizontalDragGestures(
                                onDragEnd = { view?.seekTo((startF * durMs).toInt()) }
                            ) { change, dx ->
                                change.consume()
                                startF = (startF + dx / trackPx).coerceIn(0f, endF - minGap)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.width(3.dp).height(22.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF07304A)))
                }
                // مقبض النهاية
                Box(
                    Modifier
                        .offset { IntOffset((handlePx + endPx).roundToInt(), 0) }
                        .width(handleW)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp))
                        .background(Cyan)
                        .pointerInput(durMs, trackPx) {
                            detectHorizontalDragGestures(
                                onDragEnd = { view?.seekTo((endF * durMs).toInt()) }
                            ) { change, dx ->
                                change.consume()
                                endF = (endF + dx / trackPx).coerceIn(startF + minGap, 1f)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.width(3.dp).height(22.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF07304A)))
                }
            }

            Spacer(Modifier.height(18.dp))

            // ---------- التقدم / النتيجة ----------
            if (tu.running) {
                Text(l.t("جاري حفظ المقطع...", "Saving the clip..."), color = c.text, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (tu.pct / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = Cyan, trackColor = c.card
                )
                Spacer(Modifier.height(14.dp))
            }
            if (tu.error != null) {
                Text(tu.error!!.get(l.ar), color = ErrorC, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
            }
            if (tu.doneUri.isNotEmpty()) {
                AppCard {
                    Text(l.t("✅ تم حفظ المقطع", "✅ Clip saved"), color = SuccessC, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(tu.doneWhere, color = c.muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlineButton(l.t("تشغيل", "Play"), Modifier.weight(1f)) {
                            try {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_VIEW)
                                        .setDataAndType(Uri.parse(tu.doneUri), tu.doneMime)
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                )
                            } catch (e: Exception) {
                                Toast.makeText(ctx, l.t("تعذر فتح الملف", "Couldn't open the file"), Toast.LENGTH_SHORT).show()
                            }
                        }
                        OutlineButton(l.t("مشاركة", "Share"), Modifier.weight(1f)) {
                            try {
                                val send = Intent(Intent.ACTION_SEND)
                                    .setType(tu.doneMime.ifEmpty { "*/*" })
                                    .putExtra(Intent.EXTRA_STREAM, Uri.parse(tu.doneUri))
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                ctx.startActivity(Intent.createChooser(send, l.t("مشاركة", "Share")))
                            } catch (e: Exception) {
                                Toast.makeText(ctx, l.t("تعذرت المشاركة", "Couldn't share the file"), Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // ---------- الأزرار: إلغاء | حفظ المقطع ----------
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(54.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(c.card)
                        .border(1.dp, c.stroke, RoundedCornerShape(16.dp))
                        .clickable {
                            if (tu.running) return@clickable
                            view?.stopPlayback()
                            picked = ""
                            vm.clearTrim()
                            onBack()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(l.t("إلغاء", "Cancel"), color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                GradientButton(
                    l.t("حفظ المقطع", "Save clip"),
                    Modifier.weight(1f),
                    enabled = !tu.running && endMs > startMs
                ) {
                    view?.pause()
                    playing = false
                    vm.trimLocal(uri, startMs, endMs)
                }
            }
        }
    }
}
