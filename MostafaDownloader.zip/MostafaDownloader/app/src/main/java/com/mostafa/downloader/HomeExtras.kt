package com.mostafa.downloader

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

// ============================== أدوات صغيرة ==============================

fun humanSize(bytes: Long): String = when {
    bytes <= 0L -> "—"
    bytes >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", bytes / 1073741824.0)
    bytes >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
    else -> String.format(Locale.US, "%d KB", bytes / 1024)
}

fun langName(code: String, ar: Boolean): String {
    val base = code.removeSuffix("-orig")
    val name = try {
        Locale.forLanguageTag(base.replace('_', '-')).getDisplayName(if (ar) Locale("ar") else Locale.ENGLISH)
    } catch (e: Exception) {
        ""
    }
    return if (name.isBlank() || name.equals(base, true)) base else name
}

@Composable
fun UrlImage(url: String, modifier: Modifier = Modifier) {
    val c = LocalColors.current
    val bmp by produceState<ImageBitmap?>(null, url) {
        value = withContext(Dispatchers.IO) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                val bytes = conn.inputStream.use { it.readBytes() }
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / sample > 900) sample *= 2
                val o = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)?.asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(modifier.background(c.bg), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text("🎞", fontSize = 28.sp)
        }
    }
}

// ============================== المعاينة ==============================

/**
 * زر المعاينة + بطاقة (صورة، عنوان، مدة، قايمة الجودات بأحجامها).
 * [link] = الرابط الوحيد في الخانة (أو null لو فاضية/أكتر من رابط).
 */
@Composable
fun PreviewSection(
    vm: DownloaderViewModel,
    ps: PreviewState,
    link: String?,
    ready: Boolean,
    mode: Int,
    selectedId: String,
    onSelect: (PFormat?) -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    if (link == null) return
    val mine = ps.url == link

    if (!mine || (!ps.loading && ps.data == null && ps.error == null)) {
        OutlineButton(
            l.t("🔍 معاينة (الصورة والجودات والأحجام)", "🔍 Preview (thumbnail, qualities, sizes)"),
            Modifier.fillMaxWidth(),
            enabled = ready
        ) { vm.loadPreview(link) }
        return
    }

    if (ps.loading) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CircularProgressIndicator(Modifier.size(22.dp), color = Cyan, strokeWidth = 2.5.dp)
            Text(
                l.t("جاري جلب معلومات الفيديو...", "Fetching video info..."),
                color = c.muted, fontSize = 13.sp, modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { vm.clearPreview() }) {
                Text(l.t("إلغاء", "Cancel"), color = ErrorC)
            }
        }
        return
    }

    ps.error?.let { err ->
        Text(err.get(l.ar), color = ErrorC, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { vm.loadPreview(link) }) {
                Text(l.t("إعادة المحاولة", "Retry"), color = Cyan, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = { vm.clearPreview() }) {
                Text(l.t("إخفاء", "Hide"), color = c.muted)
            }
        }
        return
    }

    val info = ps.data ?: return
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.bg)
            .border(1.dp, c.stroke, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (info.thumbnail.isNotEmpty()) {
            Box {
                UrlImage(
                    info.thumbnail,
                    Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp))
                )
                if (info.duration > 0) {
                    Text(
                        ClipTime.fmtShort(info.duration.toDouble()),
                        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xB3000000))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }
        Text(
            info.title.ifEmpty { l.t("بدون عنوان", "Untitled") },
            color = c.text, fontWeight = FontWeight.Bold, fontSize = 15.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        val meta = listOfNotNull(
            info.uploader.takeIf { it.isNotEmpty() },
            info.duration.takeIf { it > 0 }?.let { ClipTime.fmtShort(it.toDouble()) }
        ).joinToString("  •  ")
        if (meta.isNotEmpty()) Text(meta, color = c.muted, fontSize = 12.sp)

        if (mode == 0) {
            SectionLabel(l.t("الجودات المتاحة (اضغط لاختيار واحدة)", "Available qualities (tap to choose)"))
            if (info.formats.isEmpty()) {
                Text(
                    l.t("مفيش قايمة جودات لهذا الرابط — هيتحمّل بالجودة المختارة تحت.", "No quality list for this link — the quality chosen below will be used."),
                    color = c.muted, fontSize = 12.sp
                )
            } else {
                FormatRow(
                    title = l.t("تلقائي (الأفضل)", "Auto (best)"),
                    detail = "",
                    selected = selectedId.isEmpty()
                ) { onSelect(null) }
                info.formats.forEach { f ->
                    val sizeTxt = if (f.size > 0) (if (f.approx) "~" else "") + humanSize(f.size)
                    else l.t("الحجم غير معروف", "size unknown")
                    val extra = listOfNotNull(
                        f.ext.takeIf { it.isNotEmpty() }?.uppercase(Locale.US),
                        f.fps.takeIf { it > 30 }?.let { "${it}fps" }
                    ).joinToString(" • ")
                    FormatRow(
                        title = "${f.height}p",
                        detail = (if (extra.isNotEmpty()) "$extra  •  " else "") + sizeTxt,
                        selected = selectedId == f.id
                    ) { onSelect(f) }
                }
            }
        }
        TextButton(onClick = { vm.clearPreview() }) {
            Text(l.t("إخفاء المعاينة", "Hide preview"), color = c.muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun FormatRow(title: String, detail: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(if (selected) 1.5.dp else 1.dp, if (selected) Purple else c.stroke, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            (if (selected) "● " else "○ ") + title,
            color = if (selected) Purple else c.text,
            fontWeight = FontWeight.Bold, fontSize = 14.sp
        )
        if (detail.isNotEmpty()) Text(detail, color = c.muted, fontSize = 12.sp)
    }
}

// ============================== الترجمة التلقائية للكلام ==============================

@Composable
fun CompressSection(on: Boolean, onOn: (Boolean) -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        SectionLabel(l.t("📦 حجم صغير للواتساب", "📦 Small size for sharing"))
        Box(Modifier.fillMaxWidth(0.55f)) {
            Segmented(
                options = listOf(l.t("تشغيل", "On"), l.t("إيقاف", "Off")),
                selected = if (on) 0 else 1
            ) { onOn(it == 0) }
        }
    }
    if (on) {
        Text(
            l.t(
                "هيصغّر الفيديو (480p) بعد التحميل عشان يوفّر مساحة وباقة. بياخد وقت زيادة حسب طول الفيديو.",
                "Shrinks the video (480p) after download to save space and data. Takes extra time depending on length."
            ),
            color = c.muted, fontSize = 12.sp
        )
    }
}

@Composable
fun AiTransSection(
    mode: Int,
    onMode: (Int) -> Unit,
    hasKey: Boolean
) {
    val c = LocalColors.current
    val l = LocalLang.current

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        SectionLabel(l.t("الترجمة", "Translation"))
        Box(Modifier.fillMaxWidth(0.55f)) {
            Segmented(
                options = listOf(l.t("تشغيل", "On"), l.t("إيقاف", "Off")),
                selected = if (mode != 0) 0 else 1
            ) { onMode(if (it == 0) 1 else 0) }
        }
    }
    if (mode != 0) {
        if (!hasKey) {
            Text(
                l.t(
                    "⚠ لازم تضيف مفتاح Groq المجاني من الإعدادات الأول.",
                    "⚠ Add your free Groq API key in Settings first."
                ),
                color = ErrorC, fontSize = 12.sp
            )
        }
    }
}

// ============================== القص ==============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrimSection(
    on: Boolean,
    onOn: (Boolean) -> Unit,
    start: String,
    onStart: (String) -> Unit,
    end: String,
    onEnd: (String) -> Unit,
    precise: Boolean,
    onPrecise: (Boolean) -> Unit,
    durationSec: Long,
    audio: Boolean = false
) {
    val c = LocalColors.current
    val l = LocalLang.current

    SectionLabel(if (audio) l.t("✂ قص جزء من الصوت", "✂ Trim a part of the audio") else l.t("✂ قص جزء من الفيديو", "✂ Trim a part of the video"))
    Segmented(
        options = listOf(l.t("تحميل كامل", if (audio) "Full audio" else "Full video"), l.t("قص جزء", "Trim part")),
        selected = if (on) 1 else 0
    ) { onOn(it == 1) }
    if (!on) return

    if (durationSec > 0) {
        val total = durationSec.toFloat()
        val s = (ClipTime.parse(start) ?: 0.0).toFloat().coerceIn(0f, total)
        val e = (ClipTime.parse(end) ?: total.toDouble()).toFloat().coerceIn(0f, total)
        RangeSlider(
            value = minOf(s, e)..maxOf(s, e),
            onValueChange = { r ->
                onStart(ClipTime.fmtShort(r.start.toDouble()))
                onEnd(if (r.endInclusive >= total - 0.5f) "" else ClipTime.fmtShort(r.endInclusive.toDouble()))
            },
            valueRange = 0f..total,
            colors = SliderDefaults.colors(
                thumbColor = Purple,
                activeTrackColor = Purple,
                inactiveTrackColor = c.stroke
            )
        )
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        TimeField(start, onStart, l.t("من", "From"), "0:00", Modifier.weight(1f))
        TimeField(end, onEnd, l.t("إلى", "To"), if (audio) l.t("لآخر الصوت", "to the end") else l.t("لآخر الفيديو", "to the end"), Modifier.weight(1f))
    }
    if (durationSec > 0) {
        Text(
            if (audio) l.t("مدة الصوت: ", "Audio length: ") else l.t("مدة الفيديو: ", "Video length: ") + ClipTime.fmtShort(durationSec.toDouble()),
            color = c.muted, fontSize = 12.sp
        )
    }
    Segmented(
        options = listOf(l.t("قص سريع", "Fast cut"), l.t("قص دقيق (أبطأ)", "Exact cut (slower)")),
        selected = if (precise) 1 else 0
    ) { onPrecise(it == 1) }
    Text(
        l.t(
            "بيتحمّل الجزء ده بس من غير الفيديو كله. القص السريع بيبدأ من أقرب نقطة مفتاحية فممكن يزيد ثواني قليلة. اكتب الوقت زي 1:30 أو 0:01:30.",
            "Only this part is downloaded, not the whole video. The fast cut starts at the nearest keyframe, so it may add a few seconds. Use times like 1:30 or 0:01:30."
        ),
        color = c.muted, fontSize = 12.sp
    )
}

@Composable
private fun TimeField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    placeholder: String,
    modifier: Modifier
) {
    val c = LocalColors.current
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { ch -> ch.isDigit() || ch == ':' || ch == '.' }) },
        modifier = modifier,
        label = { Text(label) },
        placeholder = { Text(placeholder, color = c.muted, fontSize = 13.sp) },
        singleLine = true,
        textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 15.sp),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Purple,
            unfocusedBorderColor = c.stroke,
            focusedTextColor = c.text,
            unfocusedTextColor = c.text,
            focusedLabelColor = Purple,
            unfocusedLabelColor = c.muted,
            cursorColor = Purple
        )
    )
}
