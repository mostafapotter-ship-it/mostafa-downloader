package com.mostafa.downloader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** يحفظ طابور التحميل على الجهاز عشان يكمل بعد قفل التطبيق */
class QueueStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("queue", Context.MODE_PRIVATE)

    fun load(): List<QItem> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).mapNotNull {
            try {
                val o = arr.getJSONObject(it)
                val st = o.optInt("status", ST_WAIT)
                if (st == ST_DONE) return@mapNotNull null
                QItem(
                    id = o.getLong("id"),
                    url = o.getString("url"),
                    opts = DlOptions(
                        mode = o.optInt("mode", 0),
                        quality = o.optInt("quality", 0),
                        audioFmt = o.optString("audio", "mp3-320"),
                        imageFmt = o.optString("image", "jpg"),
                        formatId = o.optString("fid", ""),
                        muxed = o.optBoolean("muxed", false),
                        subMode = o.optInt("subMode", 0),
                        subLang = o.optString("subLang", ""),
                        clipStart = o.optString("clipS", ""),
                        clipEnd = o.optString("clipE", ""),
                        clipPrecise = o.optBoolean("clipP", false),
                        aiTrans = o.optInt("ai", 0)
                    ),
                    // اللي كان شغال لما التطبيق اتقفل يرجع للانتظار عشان يكمل
                    status = if (st == ST_RUN) ST_WAIT else st,
                    error = if (o.has("errAr")) Msg(o.optString("errAr"), o.optString("errEn")) else null
                )
            } catch (e: Exception) {
                null
            }
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<QItem>) {
        val arr = JSONArray()
        list.filter { it.status != ST_DONE }.take(60).forEach {
            val o = JSONObject()
                .put("id", it.id).put("url", it.url).put("status", it.status)
                .put("mode", it.opts.mode).put("quality", it.opts.quality)
                .put("audio", it.opts.audioFmt).put("image", it.opts.imageFmt)
                .put("fid", it.opts.formatId).put("muxed", it.opts.muxed)
                .put("subMode", it.opts.subMode).put("subLang", it.opts.subLang)
                .put("clipS", it.opts.clipStart).put("clipE", it.opts.clipEnd)
                .put("clipP", it.opts.clipPrecise).put("ai", it.opts.aiTrans)
            it.error?.let { e -> o.put("errAr", e.ar).put("errEn", e.en) }
            arr.put(o)
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
