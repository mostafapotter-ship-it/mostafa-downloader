package com.mostafa.downloader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.util.Locale

/**
 * حرق الترجمة جوه صورة الفيديو (بتظهر في أي مشغّل):
 * كل جملة بتترسم كصورة PNG شفافة بخط أندرويد (بيدعم تشكيل العربي)،
 * وبعدين ffmpeg يركّب الصور فوق الفيديو بفلتر overlay (مش محتاج libass ولا خطوط).
 */
object SubBurn {
    private class Info(val w: Int, val h: Int, val dur: Double)

    private fun probe(ctx: Context, video: File): Info? {
        val (_, out) = FfRun.run(ctx, listOf("-hide_banner", "-i", video.absolutePath))
        val sz = Regex("Video:.*?[ ,](\\d{2,5})x(\\d{2,5})[ ,\\[]").find(out) ?: return null
        var w = sz.groupValues[1].toInt()
        var h = sz.groupValues[2].toInt()
        val rot = Regex("rotat\\w*\\D{0,12}(-?\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        if (Math.abs(rot) % 180 == 90) { val t = w; w = h; h = t }
        val d = Regex("Duration: (\\d+):(\\d+):(\\d+(?:\\.\\d+)?)").find(out)
        val dur = if (d != null)
            d.groupValues[1].toInt() * 3600 + d.groupValues[2].toInt() * 60 + d.groupValues[3].toDouble()
        else 0.0
        return Info(w - w % 2, h - h % 2, dur)
    }

    private fun render(text: String, w: Int, stripH: Int, size: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, stripH, Bitmap.Config.ARGB_8888)
        if (text.isEmpty()) return bmp
        val c = Canvas(bmp)
        fun layout(p: TextPaint) = StaticLayout.Builder
            .obtain(text, 0, text.length, p, (w * 0.92f).toInt())
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, 1.05f)
            .build()
        val fill = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = size; isFakeBoldText = true
        }
        val stroke = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK; textSize = size; isFakeBoldText = true
            style = Paint.Style.STROKE; strokeWidth = size * 0.16f; strokeJoin = Paint.Join.ROUND
        }
        val lf = layout(fill)
        val ls = layout(stroke)
        val x = (w - lf.width) / 2f
        val y = (stripH - lf.height - size * 0.35f).coerceAtLeast(0f)
        c.save(); c.translate(x, y); ls.draw(c); lf.draw(c); c.restore()
        return bmp
    }

    private fun writePng(b: Bitmap, f: File) {
        f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        b.recycle()
    }

    /** بيرجع null لو نجح (والناتج في work/burned.mp4) أو رسالة الخطأ */
    fun burn(
        ctx: Context, video: File, segsIn: List<SubSeg>, work: File,
        onPct: (Int) -> Unit
    ): String? {
        val info = probe(ctx, video) ?: return "could not read video size"
        val size = minOf(info.w, info.h) * 0.055f
        val stripH = (size * 5.2f).toInt().coerceAtMost(info.h)
        val dir = File(work, "burn").apply { mkdirs() }

        // ترتيب الجمل وإزالة التداخل
        val segs = segsIn.filter { it.text.isNotBlank() }.sortedBy { it.start }
        val list = StringBuilder("ffconcat version 1.0\n")
        writePng(render("", info.w, stripH, size), File(dir, "blank.png"))
        var t = 0.0
        fun add(name: String, dur: Double) {
            if (dur <= 0.001) return
            list.append("file '$name'\nduration ").append(String.format(Locale.US, "%.3f", dur)).append('\n')
        }
        segs.forEachIndexed { i, s ->
            val end = minOf(s.end, segs.getOrNull(i + 1)?.start ?: s.end)
            if (end - s.start < 0.2) return@forEachIndexed
            add("blank.png", s.start - t)
            val n = "s%04d.png".format(i)
            writePng(render(s.text, info.w, stripH, size), File(dir, n))
            add(n, end - s.start)
            t = end
        }
        add("blank.png", 1.0)
        list.append("file 'blank.png'\n")
        val concat = File(dir, "list.txt")
        concat.writeText(list.toString())

        val out = File(work, "burned.mp4")
        fun args(vcodec: List<String>) = listOf(
            "-y", "-hide_banner", "-nostdin", "-nostats", "-progress", "pipe:1",
            "-i", video.absolutePath,
            "-f", "concat", "-safe", "0", "-i", concat.absolutePath,
            "-filter_complex", "[0:v][1:v]overlay=0:H-h:eof_action=pass:format=auto,format=yuv420p[v]",
            "-map", "[v]", "-map", "0:a?"
        ) + vcodec + listOf("-c:a", "copy", "-movflags", "+faststart", out.absolutePath)

        var lastPct = -1
        val onLine: (String) -> Unit = { line ->
            if (info.dur > 0 && line.startsWith("out_time_ms=")) {
                val us = line.substringAfter('=').toLongOrNull() ?: 0L
                val p = (us / 1_000_000.0 / info.dur * 100).toInt().coerceIn(0, 99)
                if (p != lastPct) { lastPct = p; onPct(p) }
            }
        }
        var (code, log) = FfRun.run(
            ctx, args(listOf("-c:v", "libx264", "-preset", "ultrafast", "-crf", "24")), onLine
        )
        if (code != 0 || !out.exists() || out.length() == 0L) {
            out.delete()
            // بديل لو libx264 مش موجود في نسخة ffmpeg
            val r = FfRun.run(ctx, args(listOf("-c:v", "mpeg4", "-q:v", "4")), onLine)
            code = r.first; log = r.second
        }
        dir.deleteRecursively()
        return if (code == 0 && out.exists() && out.length() > 0) null else log.takeLast(200)
    }
}
