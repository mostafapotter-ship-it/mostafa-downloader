package com.mostafa.downloader

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch

/** كل اللي محتاجه إشعار التحديث عشان يوصل والتطبيق مقفول: إذن الإشعارات + البطارية + التشغيل التلقائي */
object Background {
    fun notificationsOk(ctx: Context): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun batteryOk(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (e: Exception) {
        false
    }

    private fun start(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    fun openAppDetails(ctx: Context): Boolean =
        start(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:" + ctx.packageName)))

    fun openNotificationSettings(ctx: Context): Boolean =
        start(
            ctx,
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        ) || openAppDetails(ctx)

    private fun findActivity(ctx: Context): android.app.Activity? {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is android.app.Activity) return c
            c = c.baseContext
        }
        return null
    }

    /**
     * بيفتح شاشة إلغاء قيود البطارية. لو الإذن متفعّل بالفعل أو الشاشة ما ظهرتش
     * (بعض أجهزة Oppo/Realme/Xiaomi بتتجاهل الطلب بدون أي رسالة) بنفتح بديل بيظهر فعلاً.
     */
    fun requestBattery(ctx: Context): Boolean {
        if (batteryOk(ctx)) {
            try {
                android.widget.Toast.makeText(ctx, "البطارية: بدون قيود بالفعل ✅", android.widget.Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
            }
            return openAppDetails(ctx)
        }
        val direct = start(
            ctx,
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:" + ctx.packageName))
        )
        val act = findActivity(ctx)
        if (direct && act != null) {
            // لو بعد لحظة التطبيق لسه في الواجهة، يبقى الطلب ما ظهرش → نفتح البديل
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    if (!act.isFinishing && act.hasWindowFocus() && !batteryOk(ctx)) openBatteryFallback(ctx)
                } catch (e: Exception) {
                }
            }, 900)
            return true
        }
        return direct || openBatteryFallback(ctx)
    }

    private fun openBatteryFallback(ctx: Context): Boolean =
        start(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) || openAppDetails(ctx)

    private val autoStartScreens = listOf(
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.battery.ui.BatteryActivity",
        "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity",
        "com.asus.mobilemanager" to "com.asus.mobilemanager.autostart.AutoStartActivity"
    )

    /** يفتح شاشة "التشغيل التلقائي" بتاعة الشركة المصنّعة لو موجودة، وإلا يفتح معلومات التطبيق */
    fun openAutoStart(ctx: Context): Boolean {
        for ((pkg, cls) in autoStartScreens) {
            if (start(ctx, Intent().setComponent(ComponentName(pkg, cls)))) return true
        }
        return openAppDetails(ctx)
    }
}

@Composable
private fun StatusRow(ok: Boolean, okText: String, badText: String, action: String, onClick: () -> Unit) {
    val c = LocalColors.current
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            (if (ok) "✅ " else "❌ ") + (if (ok) okText else badText),
            color = if (ok) c.text else ErrorC, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        if (!ok) OutlineButton(action, onClick = onClick)
    }
}

/** قائمة فحص + أزرار الضبط. بتتنادى جوه AppCard */
@Composable
fun BackgroundSetup() {
    val c = LocalColors.current
    val l = LocalLang.current
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val notifOk = remember(tick) { Background.notificationsOk(ctx) }
    val batOk = remember(tick) { Background.batteryOk(ctx) }
    var info by remember(tick) { mutableStateOf(UpdateCheckWorker.lastInfo(ctx, l.ar)) }

    StatusRow(
        notifOk, l.t("الإشعارات مسموحة", "Notifications allowed"),
        l.t("الإشعارات مقفولة", "Notifications are off"), l.t("تفعيل", "Enable")
    ) { Background.openNotificationSettings(ctx) }
    StatusRow(
        batOk, l.t("البطارية: بدون قيود", "Battery: unrestricted"),
        l.t("البطارية بتقيّد التطبيق", "Battery restricts the app"), l.t("إلغاء القيود", "Unrestrict")
    ) { Background.requestBattery(ctx) }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            l.t("⚠ التشغيل التلقائي (Auto-start): فعّله يدوياً", "⚠ Auto-start: enable it manually"),
            color = c.text, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)
        )
        OutlineButton(l.t("فتح", "Open")) {
            if (!Background.openAutoStart(ctx)) Toast(ctx)
        }
    }
    Text(
        l.t(
            "أجهزة أوبو/ريلمي/شاومي/فيفو بتقفل التطبيقات اللي مش مسموح لها بالتشغيل التلقائي، ومن غيره مفيش إشعار هيوصل والتطبيق مقفول. كمان اعمل قفل للتطبيق من شاشة التطبيقات الأخيرة.",
            "Oppo/Realme/Xiaomi/Vivo kill apps without Auto-start permission, so no alert can arrive while the app is closed. Also lock the app in the recent-apps screen."
        ),
        color = c.muted, fontSize = 12.sp
    )
    Text(info, color = c.muted, fontSize = 12.sp)
    OutlineButton(l.t("فحص التحديث دلوقتي", "Check for updates now"), Modifier.fillMaxWidth()) {
        AppScope.io.launch {
            UpdateCheckWorker.check(ctx.applicationContext, force = true)
            info = UpdateCheckWorker.lastInfo(ctx.applicationContext, l.ar)
        }
    }
}

private fun Toast(ctx: Context) {
    android.widget.Toast.makeText(ctx, "Not available", android.widget.Toast.LENGTH_SHORT).show()
}
