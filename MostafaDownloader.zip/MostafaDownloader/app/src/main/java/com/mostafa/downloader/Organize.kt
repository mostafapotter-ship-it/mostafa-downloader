package com.mostafa.downloader

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.ui.draw.clip
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** نتيجة الحفظ: مكان الملف النهائي ونوعه ووصف المكان للعرض */
data class SaveRes(val uri: String, val mime: String, val where: String)

/** صيغة اسم الملف: {title} {platform} {quality} {date} */
object NameTemplate {
    const val DEFAULT = "{title}"
    val tokens = listOf("{title}", "{platform}", "{quality}", "{date}")

    fun sanitize(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), " ")
            .replace("✂", "")
            .replace(Regex("\\s+"), " ")
            .trim().trim('.').trim()
            .take(150)

    fun apply(tpl: String, title: String, platform: String, quality: String, date: String): String {
        val t = tpl.ifBlank { DEFAULT }
        val r = sanitize(
            t.replace("{title}", title).replace("{platform}", platform)
                .replace("{quality}", quality).replace("{date}", date)
        )
        return r.ifBlank { sanitize(title) }.ifBlank { "download" }
    }

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
}

/** الحفظ في مجلد اختاره المستخدم (Storage Access Framework) */
object SaveTree {
    fun describe(tree: String): String = try {
        val id = DocumentsContract.getTreeDocumentId(Uri.parse(tree))
        val vol = id.substringBefore(':')
        val path = id.substringAfter(':', "")
        (if (vol == "primary") "Internal storage" else vol) + (if (path.isNotEmpty()) "/$path" else "")
    } catch (e: Exception) {
        tree
    }

    private fun findOrCreateDir(ctx: Context, tree: Uri, parent: Uri, name: String): Uri {
        val res = ctx.contentResolver
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent))
        res.query(
            children,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) == name && c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0))
                }
            }
        }
        return DocumentsContract.createDocument(res, parent, DocumentsContract.Document.MIME_TYPE_DIR, name)
            ?: throw IllegalStateException("Cannot create folder")
    }

    fun save(ctx: Context, treeStr: String, sub: String?, file: File, mime: String, name: String): String {
        val tree = Uri.parse(treeStr)
        var parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        if (sub != null) parent = findOrCreateDir(ctx, tree, parent, sub)
        val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, mime, name)
            ?: throw IllegalStateException("Cannot create file")
        ctx.contentResolver.openOutputStream(doc)!!.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        return doc.toString()
    }
}

/** بطاقة "تنظيم الملفات" في الإعدادات */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StorageCard(vm: DownloaderViewModel, s: AppSettings) {
    val c = LocalColors.current
    val l = LocalLang.current
    val ctx = LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
            }
            vm.setSaveUri(uri.toString())
        }
    }

    AppCard {
        SectionLabel(l.t("تنظيم الملفات 📁", "File organization 📁"))

        // مكان الحفظ
        Text(l.t("مكان الحفظ", "Save location"), color = c.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(
            if (s.saveUri.isBlank()) "Downloads/MostafaDownloader" else SaveTree.describe(s.saveUri),
            color = c.muted, fontSize = 12.sp
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlineButton(l.t("اختيار مجلد", "Choose folder"), Modifier.weight(1f)) { picker.launch(null) }
            if (s.saveUri.isNotBlank()) {
                OutlineButton(l.t("الافتراضي", "Default"), Modifier.weight(1f)) { vm.setSaveUri("") }
            }
        }
    }
}
