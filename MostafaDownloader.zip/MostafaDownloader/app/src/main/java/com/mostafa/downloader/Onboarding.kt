package com.mostafa.downloader

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class OnbPage(val emoji: String, val titleAr: String, val titleEn: String, val bodyAr: String, val bodyEn: String)

private val pages = listOf(
    OnbPage(
        "👋", "أهلاً بيك في SC Downloader", "Welcome to SC Downloader",
        "حمّل الفيديوهات والصور والصوت من فيسبوك وتيك توك وإنستجرام وX ويوتيوب وسناب وواتساب، من مكان واحد.",
        "Download videos, photos and audio from Facebook, TikTok, Instagram, X, YouTube, Snapchat and WhatsApp in one place."
    ),
    OnbPage(
        "🔗", "الصق الرابط وخلاص", "Just paste the link",
        "أول ما تلصق الرابط بتظهر معاينة بالصورة والجودات والأحجام تلقائياً، وتختار اللي يناسبك وتدوس تحميل.",
        "As soon as you paste a link, a preview appears with the thumbnail, qualities and sizes. Pick one and tap Download."
    ),
    OnbPage(
        "🎙", "ترجمة تلقائية للفيديوهات", "Auto-translate videos",
        "يمكنك تشغيل الترجمة من الإعدادات للفيديوهات الأجنبية فقط.",
        "You can turn on translation from Settings for foreign-language videos."
    ),
    OnbPage(
        "📁", "نظّم ملفاتك وتابع إحصائياتك", "Organize files & track your stats",
        "كل تحميل بيتحفظ تلقائياً في مجلد منصته، وتقدر تغيّر مكان الحفظ من الإعدادات. وشوف عدد تحميلاتك وحجمها لكل منصة.",
        "Every download is saved automatically in its platform's folder, and you can change the save location in Settings. See your downloads and sizes per platform."
    ),
    OnbPage(
        "🔋", "خلّي تنبيهات التحديث توصلك", "Make update alerts reach you",
        "عشان إشعار التحديث يوصلك والتطبيق مقفول: فعّل «التشغيل التلقائي» وشيل قيود البطارية عن التطبيق.",
        "To get update alerts while the app is closed: enable Auto-start and remove battery limits for the app."
    ),
    OnbPage(
        "🔔", "فعّل التنبيهات", "Enable notifications",
        "عشان توصلك تحديثات التطبيق وتنبيه انتهاء التحميل حتى لو التطبيق مقفول.",
        "So you get app updates and download-finished alerts even when the app is closed."
    )
)

@Composable
fun Onboarding(onDone: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    var page by rememberSaveable { mutableStateOf(0) }
    val last = page == pages.lastIndex
    val ctx = androidx.compose.ui.platform.LocalContext.current

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { onDone() }

    Column(
        Modifier.fillMaxSize().background(c.bg).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            if (!last) {
                Text(
                    l.t("تخطي", "Skip"), color = c.muted, fontSize = 14.sp,
                    modifier = Modifier.clip(CircleShape).clickable { onDone() }.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            } else {
                Spacer(Modifier.height(36.dp))
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Crossfade(targetState = page, label = "onb") { i ->
                val p = pages[i]
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Box(
                        Modifier.size(120.dp).clip(CircleShape).background(BrandBrush),
                        contentAlignment = Alignment.Center
                    ) { Text(p.emoji, fontSize = 54.sp) }
                    Text(
                        l.t(p.titleAr, p.titleEn), color = c.text, fontSize = 24.sp,
                        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
                    )
                    Text(
                        l.t(p.bodyAr, p.bodyEn), color = c.muted, fontSize = 15.sp,
                        textAlign = TextAlign.Center, lineHeight = 24.sp
                    )
                    if (i == 4) {
                        OutlineButton(l.t("1) التشغيل التلقائي (Auto-start)", "1) Auto-start"), Modifier.fillMaxWidth()) {
                            Background.openAutoStart(ctx)
                        }
                        OutlineButton(l.t("2) بدون قيود البطارية", "2) Unrestricted battery"), Modifier.fillMaxWidth()) {
                            Background.requestBattery(ctx)
                        }
                    }
                    if (i == 0) {
                        Spacer(Modifier.height(4.dp))
                        Platforms.chunked(4).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                row.forEach { PlatformIcon(it, 44.dp) }
                            }
                        }
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 20.dp)) {
            pages.indices.forEach { i ->
                Box(
                    Modifier.size(if (i == page) 22.dp else 8.dp, 8.dp).clip(CircleShape)
                        .background(if (i == page) Purple else c.stroke)
                )
            }
        }

        GradientButton(if (last) l.t("ابدأ", "Get started") else l.t("التالي", "Next")) {
            if (!last) {
                page++
            } else if (Build.VERSION.SDK_INT >= 33) {
                permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                onDone()
            }
        }
        if (page > 0) {
            Text(
                l.t("رجوع", "Back"), color = c.muted, fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp).clip(CircleShape).clickable { page-- }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}
