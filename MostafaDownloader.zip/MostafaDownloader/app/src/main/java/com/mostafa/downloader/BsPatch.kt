package com.mostafa.downloader

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile

/** تطبيق باتش بصيغة BSDIFF40 (تغييرات فقط) على ملف قديم لإنتاج الملف الجديد */
object BsPatch {
    private fun offt(b: ByteArray, off: Int): Long {
        var y = (b[off + 7].toLong() and 0x7F)
        for (i in 6 downTo 0) y = y * 256 + (b[off + i].toLong() and 0xFF)
        return if ((b[off + 7].toLong() and 0x80) != 0L) -y else y
    }

    private fun readFully(input: InputStream, buf: ByteArray, n: Int) {
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) throw EOFException()
            off += r
        }
    }

    fun apply(oldFile: File, patchFile: File, outFile: File) {
        val patch = patchFile.readBytes()
        if (patch.size < 32 || String(patch, 0, 8, Charsets.US_ASCII) != "BSDIFF40") {
            throw IOException("Bad patch header")
        }
        val ctrlLen = offt(patch, 8).toInt()
        val diffLen = offt(patch, 16).toInt()
        val newSize = offt(patch, 24)
        val extraStart = 32 + ctrlLen + diffLen
        val ctrl = DataInputStream(BZip2CompressorInputStream(ByteArrayInputStream(patch, 32, ctrlLen)))
        val diff = BZip2CompressorInputStream(ByteArrayInputStream(patch, 32 + ctrlLen, diffLen))
        val extra = BZip2CompressorInputStream(
            ByteArrayInputStream(patch, extraStart, patch.size - extraStart)
        )

        val oldSize = oldFile.length()
        val oldBuf = ByteArray(64 * 1024)
        val diffBuf = ByteArray(64 * 1024)
        val cbuf = ByteArray(24)

        RandomAccessFile(oldFile, "r").use { old ->
            BufferedOutputStream(FileOutputStream(outFile), 256 * 1024).use { out ->
                var oldPos = 0L
                var newPos = 0L
                while (newPos < newSize) {
                    ctrl.readFully(cbuf)
                    val x = offt(cbuf, 0)
                    val y = offt(cbuf, 8)
                    val z = offt(cbuf, 16)
                    if (x < 0 || y < 0 || newPos + x + y > newSize) throw IOException("Corrupt patch")

                    var done = 0L
                    while (done < x) {
                        val n = minOf(x - done, oldBuf.size.toLong()).toInt()
                        readFully(diff, diffBuf, n)
                        oldBuf.fill(0.toByte(), 0, n)
                        val pos = oldPos + done
                        if (pos >= 0 && pos < oldSize) {
                            val avail = minOf(n.toLong(), oldSize - pos).toInt()
                            old.seek(pos)
                            old.readFully(oldBuf, 0, avail)
                        }
                        for (i in 0 until n) oldBuf[i] = (oldBuf[i] + diffBuf[i]).toByte()
                        out.write(oldBuf, 0, n)
                        done += n
                    }

                    var copied = 0L
                    while (copied < y) {
                        val n = minOf(y - copied, diffBuf.size.toLong()).toInt()
                        readFully(extra, diffBuf, n)
                        out.write(diffBuf, 0, n)
                        copied += n
                    }

                    newPos += x + y
                    oldPos += x + z
                }
            }
        }
    }
}
