package com.mostafa.downloader

import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.layout.width
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Platform(val id: String, val name: String, val res: Int, val color: Long = 0xFF1A2150)

val Platforms = listOf(
    Platform("fb", "Facebook", R.drawable.ic_fb,   0xFF1877F2),
    Platform("ig", "Instagram", R.drawable.ic_ig,   0xFFE1306C),
    Platform("tt", "TikTok",    R.drawable.ic_tt,   0xFF010101),
    Platform("x",  "X",         R.drawable.ic_x,    0xFF14171A),
    Platform("yt", "YouTube",   R.drawable.ic_yt,   0xFFFF0000),
    Platform("wa", "WhatsApp",  R.drawable.ic_wa,   0xFF25D366),
    Platform("sc", "Snapchat",  R.drawable.ic_sc,   0xFFFFFC00)
)

/** اسم المنصة بالعربي لعنوان شاشة التحميل */
fun platformNameAr(id: String?): String = when (id) {
    "fb" -> "فيسبوك"; "ig" -> "انستجرام"; "tt" -> "تيك توك"; "x" -> "X"
    "yt" -> "يوتيوب"; "wa" -> "واتساب"; "sc" -> "سناب شات"; else -> ""
}

/** يحدد المنصة من الرابط الملصوق (للتمييز البصري فقط) */
fun platformOf(text: String): String? {
    val t = text.lowercase()
    return when {
        "tiktok" in t -> "tt"
        "instagram" in t -> "ig"
        "snapchat" in t -> "sc"
        "facebook" in t || "fb.watch" in t || "fb.com" in t -> "fb"
        "youtube" in t || "youtu.be" in t -> "yt"
        Regex("://([a-z0-9-]+\\.)?(x|twitter)\\.com").containsMatchIn(t) -> "x"
        else -> null
    }
}

@Composable
fun PlatformIcon(p: Platform, size: Dp, dimmed: Boolean = false) {
    Image(
        painter = painterResource(p.res),
        contentDescription = p.name,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .size(size)
            .alpha(if (dimmed) 0.35f else 1f)
    )
}

/** بلاطة منصة في الشبكة الرئيسية (بطاقة داكنة بإطار متوهج + الأيقونة + الاسم) */
@Composable
private fun PlatformTile(p: Platform, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .aspectRatio(1.05f)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1A2556), Color(0xFF0E1736))))
            .border(1.5.dp, Brush.verticalGradient(listOf(Color(0xFF4A6BFF).copy(alpha = 0.75f), Color(0xFF2A3C8F).copy(alpha = 0.35f))), shape)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(painter = painterResource(p.res), contentDescription = p.name, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(5.dp))
        Text(p.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun MoreTile(label: String, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .aspectRatio(1.05f)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF8B4DF0), Color(0xFF5B2BC9))))
            .border(1.5.dp, Color(0xFFB48CFF).copy(alpha = 0.6f), shape)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("•••", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** الشاشة الرئيسية: هيدر بصورة دائرية + شبكة المنصات (3 أعمدة) بالترتيب المرجعي */
@Composable
fun PlatformLauncherScreen(
    hasUpdate: Boolean,
    onOpenSettings: () -> Unit,
    onSelect: (String) -> Unit,
    l: Lang,
    c: AppColors
) {
    val byId = { id: String -> Platforms.first { it.id == id } }
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0A1030), Color(0xFF070B1E))))
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ---------- الهيدر ----------
        Box(Modifier.fillMaxWidth()) {
            Canvas(Modifier.fillMaxWidth().height(215.dp)) {
                val w = size.width
                val h = size.height
                val path = Path().apply {
                    moveTo(0f, 0f); lineTo(w, 0f); lineTo(w, h * 0.74f)
                    cubicTo(w * 0.78f, h * 0.96f, w * 0.58f, h * 0.62f, w * 0.34f, h * 0.80f)
                    cubicTo(w * 0.2f, h * 0.9f, w * 0.08f, h * 0.84f, 0f, h * 0.76f)
                    close()
                }
                drawPath(path, Brush.verticalGradient(listOf(Color(0xFF12246E), Color(0xFF0B1744))))
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("👑", fontSize = 26.sp)
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).clickable { onOpenSettings() },
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.material3.Icon(
                            painter = painterResource(R.drawable.ic_nav_settings),
                            contentDescription = null, tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
            Box(Modifier.align(Alignment.Center).padding(top = 8.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(170.dp).background(
                        Brush.radialGradient(listOf(Cyan.copy(alpha = 0.40f), Purple.copy(alpha = 0.15f), Color.Transparent)),
                        CircleShape
                    )
                )
                Box(
                    Modifier.size(118.dp).clip(CircleShape)
                        .border(3.dp, Brush.sweepGradient(listOf(Cyan, Purple, Cyan)), CircleShape)
                        .padding(5.dp).clip(CircleShape)
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_logo), contentDescription = null,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        if (hasUpdate) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(14.dp)).background(BrandBrush)
                    .clickable { onOpenSettings() }.padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(l.t("يوجد تحديث جديد", "Update available"), color = Color.White,
                    fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(l.t("تحديث ←", "Update →"), color = Color.White, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
        }

        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White)) { append("Mostafa") }
                withStyle(SpanStyle(color = Cyan)) { append("Downloader") }
            },
            fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
            style = androidx.compose.ui.text.TextStyle(textDirection = androidx.compose.ui.text.style.TextDirection.Ltr)
        )
        Text(l.t("تحميل سريع .. بكل سهولة", "Fast & easy downloads"), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        // الترتيب البصري من اليسار لليمين زي التصميم: fb ig tt / x yt sc / wa more
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                listOf(listOf("fb", "ig", "tt"), listOf("x", "yt", "sc")).forEach { ids ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ids.forEach { id -> PlatformTile(byId(id), Modifier.weight(1f)) { onSelect(id) } }
                    }
                }
                Row(Modifier.fillMaxWidth(0.68f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PlatformTile(byId("wa"), Modifier.weight(1f)) { onSelect("wa") }
                    MoreTile(l.t("المزيد", "More"), Modifier.weight(1f)) { onSelect("other") }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
