package com.mostafa.downloader

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Platform(val id: String, val name: String, val res: Int, val color: Long = 0xFF1A2150)

val Platforms = listOf(
    Platform("fb", "Facebook", R.drawable.ic_fb,   0xFF1877F2),
    Platform("ig", "Instagram", R.drawable.ic_ig,   0xFFE1306C),
    Platform("tt", "TikTok",    R.drawable.ic_tt,   0xFF010101),
    Platform("x",  "X",         R.drawable.ic_x,    0xFF14171A),
    Platform("yt", "YouTube",   R.drawable.ic_yt,   0xFFFF0000),
    Platform("wa", "WhatsApp",  R.drawable.ic_wa,   0xFF25D366),
    Platform("sc", "Snapchat",  R.drawable.ic_sc,   0xFFFFFC00)
)

/** يحدد المنصة من الرابط الملصوق (للتمييز البصري فقط) */
fun platformOf(text: String): String? {
    val t = text.lowercase()
    return when {
        "tiktok" in t -> "tt"
        "instagram" in t -> "ig"
        "snapchat" in t -> "sc"
        "facebook" in t || "fb.watch" in t || "fb.com" in t -> "fb"
        "youtube" in t || "youtu.be" in t -> "yt"
        Regex("://([a-z0-9-]+\\.)?(x|twitter)\\.com").containsMatchIn(t) -> "x"
        else -> null
    }
}

@Composable
fun PlatformIcon(p: Platform, size: Dp, dimmed: Boolean = false) {
    Image(
        painter = painterResource(p.res),
        contentDescription = p.name,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .size(size)
            .alpha(if (dimmed) 0.35f else 1f)
    )
}

/** شاشة الإطلاق الرئيسية: شبكة المنصات ذات التصميم الجديد */
@Composable
fun PlatformLauncherScreen(
    hasUpdate: Boolean,
    onOpenSettings: () -> Unit,
    onSelect: (String) -> Unit,
    l: Lang,
    c: AppColors
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0A0E2A), Color(0xFF070B1A))))
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(36.dp))

        if (hasUpdate) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(14.dp)).background(BrandBrush)
                    .clickable { onOpenSettings() }.padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(l.t("يوجد تحديث جديد", "Update available"), color = Color.White,
                    fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(l.t("تحديث ←", "Update →"), color = Color.White, fontSize = 13.sp)
            }
            Spacer(Modifier.height(16.dp))
        }

        Box(contentAlignment = Alignment.Center) {
            Box(Modifier.size(200.dp).background(
                Brush.radialGradient(listOf(Purple.copy(alpha = 0.38f), Cyan.copy(alpha = 0.12f), Color.Transparent))
            ))
            Image(
                painter = androidx.compose.ui.res.painterResource(R.drawable.ic_logo),
                contentDescription = null,
                modifier = Modifier.size(108.dp).clip(RoundedCornerShape(26.dp))
            )
        }
        Spacer(Modifier.height(14.dp))
        Row {
            Text("Mostafa",     color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Downloader", color = Cyan,        fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text(l.t("تحميل سريع .. بكل سهولة", "Fast & easy downloads"), color = c.muted, fontSize = 13.sp)
        Spacer(Modifier.height(34.dp))

        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            listOf(
                listOf(Platforms[0], Platforms[1], Platforms[2]),
                listOf(Platforms[3], Platforms[4], Platforms[5])
            ).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { PlatformGridButton(it, onClick = { onSelect(it.id) }, size = 88.dp) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                PlatformGridButton(Platforms[6], onClick = { onSelect(Platforms[6].id) }, size = 88.dp)
                MoreGridButton(l.t("المزيد", "More"), onClick = { onSelect("other") }, size = 88.dp)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}
