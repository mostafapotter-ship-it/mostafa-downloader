package com.mostafa.downloader

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Platform(val id: String, val name: String, val res: Int)

val Platforms = listOf(
    Platform("fb", "Facebook", R.drawable.ic_fb),
    Platform("tt", "TikTok", R.drawable.ic_tt),
    Platform("ig", "Instagram", R.drawable.ic_ig),
    Platform("x", "X", R.drawable.ic_x),
    Platform("yt", "YouTube", R.drawable.ic_yt),
    Platform("wa", "WhatsApp", R.drawable.ic_wa)
)

/** يحدد المنصة من الرابط الملصوق (للتمييز البصري فقط) */
fun platformOf(text: String): String? {
    val t = text.lowercase()
    return when {
        "tiktok" in t -> "tt"
        "instagram" in t -> "ig"
        "facebook" in t || "fb.watch" in t || "fb.com" in t -> "fb"
        "youtube" in t || "youtu.be" in t -> "yt"
        Regex("://([a-z0-9-]+\\.)?(x|twitter)\\.com").containsMatchIn(t) -> "x"
        else -> null
    }
}

@Composable
fun PlatformIcon(p: Platform, size: Dp, dimmed: Boolean = false) {
    Image(
        painter = painterResource(p.res),
        contentDescription = p.name,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .size(size)
            .alpha(if (dimmed) 0.35f else 1f)
    )
}

@Composable
fun PlatformGrid(detected: String?, onWhatsApp: () -> Unit) {
    val c = LocalColors.current
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Platforms.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { p ->
                    Column(
                        Modifier
                            .weight(1f)
                            .then(if (p.id == "wa") Modifier.clickable(onClick = onWhatsApp) else Modifier),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PlatformIcon(p, 76.dp, dimmed = detected != null && detected != p.id)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            p.name, fontSize = 12.sp, color = c.text,
                            fontWeight = FontWeight.Medium, maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
