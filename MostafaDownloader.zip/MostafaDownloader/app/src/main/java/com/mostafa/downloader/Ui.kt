package com.mostafa.downloader

import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class AccentTheme(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color
)

val AccentThemes = listOf(
    AccentTheme("violet", "بنفسجي", "Violet", Color(0xFF7C5CFF), Color(0xFF3D8BFF), Color(0xFF00C8E6)),
    AccentTheme("ocean", "محيط", "Ocean", Color(0xFF0EA5E9), Color(0xFF2563EB), Color(0xFF22D3EE)),
    AccentTheme("emerald", "زمردي", "Emerald", Color(0xFF10B981), Color(0xFF0891B2), Color(0xFF34D399)),
    AccentTheme("sunset", "غروب", "Sunset", Color(0xFFF97316), Color(0xFFEF4444), Color(0xFFFBBF24)),
    AccentTheme("rose", "وردي", "Rose", Color(0xFFEC4899), Color(0xFF8B5CF6), Color(0xFFF472B6)),
    AccentTheme("gold", "ذهبي", "Gold", Color(0xFFF59E0B), Color(0xFFD97706), Color(0xFFFDE047))
)

object Accent {
    var primary by mutableStateOf(AccentThemes[0].primary)
    var secondary by mutableStateOf(AccentThemes[0].secondary)
    var tertiary by mutableStateOf(AccentThemes[0].tertiary)

    fun set(t: AccentTheme) {
        primary = t.primary
        secondary = t.secondary
        tertiary = t.tertiary
    }

    fun byId(id: String): AccentTheme = AccentThemes.firstOrNull { it.id == id } ?: AccentThemes[0]
}

val Purple: Color get() = Accent.primary
val Blue: Color get() = Accent.secondary
val Cyan: Color get() = Accent.tertiary
val ErrorC = Color(0xFFFF6B6B)
val SuccessC = Color(0xFF22C55E)
val BrandBrush: Brush get() = Brush.horizontalGradient(listOf(Accent.primary, Accent.secondary))

@Immutable
data class AppColors(
    val bg: Color,
    val card: Color,
    val stroke: Color,
    val text: Color,
    val muted: Color,
    val dark: Boolean
)

val DarkColors = AppColors(
    Color(0xFF070B1A), Color(0xFF0D1228), Color(0xFF1C2444),
    Color.White, Color(0xFF8A94BB), true
)
val LightColors = AppColors(
    Color(0xFFF3F4FA), Color.White, Color(0xFFDDE1EE),
    Color(0xFF14172B), Color(0xFF6A7194), false
)

val AmoledColors = AppColors(
    Color(0xFF000000), Color(0xFF0C0C0E), Color(0xFF232328),
    Color.White, Color(0xFF8E8E99), true
)

val LocalColors = staticCompositionLocalOf { DarkColors }

class Lang(val ar: Boolean) {
    fun t(a: String, e: String): String = if (ar) a else e
}

val LocalLang = staticCompositionLocalOf { Lang(true) }

@Composable
fun SectionLabel(text: String) {
    Text(text, color = LocalColors.current.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
fun Segmented(options: List<String>, selected: Int, enabled: Boolean = true, onSelect: (Int) -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.bg)
            .border(1.dp, c.stroke, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) BrandBrush else SolidColor(Color.Transparent))
                    .clickable(enabled = enabled) { onSelect(i) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (sel) Color.White else c.muted,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun GradientButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(BrandBrush, alpha = if (enabled) 1f else 0.35f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun OutlineButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .height(48.dp)
            .clip(shape)
            .border(1.dp, c.stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (enabled) c.text else c.muted,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.unit.Dp

/** زرار منصة في الشبكة الرئيسية */
@Composable
fun PlatformGridButton(
    platform: Platform,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 80.dp
) {
    val platColor = androidx.compose.ui.graphics.Color(platform.color)
    Column(
        modifier.size(size).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier
                .size(size - 20.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(platColor.copy(alpha = 0.18f))
                .border(1.5.dp, platColor.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(platform.res),
                contentDescription = platform.name,
                modifier = Modifier.size(34.dp)
            )
        }
        Text(platform.name, color = LocalColors.current.text, fontSize = 11.sp,
            fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** زرار "المزيد" في شبكة المنصات */
@Composable
fun MoreGridButton(label: String, onClick: () -> Unit, size: Dp = 80.dp) {
    val c = LocalColors.current
    Column(
        Modifier.size(size).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier
                .size(size - 20.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(BrandBrush),
            contentAlignment = Alignment.Center
        ) {
            Text("···", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
        Text(label, color = c.text, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

/** كارت بإطار متوهج خفيف */
@Composable
fun GlowCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.dp, Purple.copy(alpha = 0.28f), shape)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}
