package com.mostafa.downloader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Purple = Color(0xFF7C5CFF)
val Blue = Color(0xFF3D8BFF)
val Cyan = Color(0xFF00C8E6)
val ErrorC = Color(0xFFFF6B6B)
val SuccessC = Color(0xFF22C55E)
val BrandBrush = Brush.horizontalGradient(listOf(Purple, Blue))

@Immutable
data class AppColors(
    val bg: Color,
    val card: Color,
    val stroke: Color,
    val text: Color,
    val muted: Color,
    val dark: Boolean
)

val DarkColors = AppColors(
    Color(0xFF0E1120), Color(0xFF171B30), Color(0xFF2A3050),
    Color.White, Color(0xFF9AA3C7), true
)
val LightColors = AppColors(
    Color(0xFFF3F4FA), Color.White, Color(0xFFDDE1EE),
    Color(0xFF14172B), Color(0xFF6A7194), false
)

val LocalColors = staticCompositionLocalOf { DarkColors }

class Lang(val ar: Boolean) {
    fun t(a: String, e: String): String = if (ar) a else e
}

val LocalLang = staticCompositionLocalOf { Lang(true) }

@Composable
fun SectionLabel(text: String) {
    Text(text, color = LocalColors.current.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
fun Segmented(options: List<String>, selected: Int, enabled: Boolean = true, onSelect: (Int) -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.bg)
            .border(1.dp, c.stroke, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) BrandBrush else SolidColor(Color.Transparent))
                    .clickable(enabled = enabled) { onSelect(i) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (sel) Color.White else c.muted,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun GradientButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(BrandBrush, alpha = if (enabled) 1f else 0.35f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun OutlineButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .height(48.dp)
            .clip(shape)
            .border(1.dp, c.stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (enabled) c.text else c.muted,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
