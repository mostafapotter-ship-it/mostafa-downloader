package com.mostafa.downloader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

/**
 * تبويب "المزيد" (تبويب 7): شبكة أدوات (الحالات / الترجمة / قص الفيديو / الإحصائيات)
 * وزرار ⚙ بيفتح الإعدادات (تبويب 4).
 */
@Composable
fun MoreScreen(
    vm: DownloaderViewModel,
    onOpenTab: (Int) -> Unit,
    onSettings: () -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    val stats by vm.stats.collectAsState()
    var showStats by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(Modifier.size(40.dp))
                Text(l.t("المزيد", "More"), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = c.text)
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(50)).clickable { onSettings() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_nav_settings), contentDescription = l.t("الإعدادات", "Settings"),
                        tint = c.text, modifier = Modifier.size(26.dp)
                    )
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ToolTile(
                R.drawable.ic_nav_status, null,
                l.t("الحالات", "Statuses"), l.t("واتساب وستوري المنصات", "WhatsApp and platform stories")
            ) { onOpenTab(2) }
            ToolTile(
                R.drawable.ic_globe, null,
                l.t("ترجمة الفيديو", "Video translation"), l.t("ترجمة ونص وملخص", "Translate, transcript, summary")
            ) { onOpenTab(3) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ToolTile(
                R.drawable.ic_scissors, null,
                l.t("قص الفيديو", "Trim video"), l.t("اقتطع جزء من فيديو", "Cut a part of a video")
            ) { onOpenTab(6) }
            ToolTile(
                null, "📊",
                l.t("إحصائياتك", "Your stats"), if (showStats) l.t("اضغط للإخفاء", "Tap to hide") else l.t("اضغط للعرض", "Tap to show")
            ) { showStats = !showStats }
        }

        if (showStats) {
            StatsCard(stats) { vm.resetStats() }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RowScope.ToolTile(
    iconRes: Int?,
    emoji: String?,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .weight(1f)
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape)
            .clickable { onClick() }
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(34.dp), contentAlignment = Alignment.CenterStart) {
            if (iconRes != null) {
                Icon(
                    painter = painterResource(iconRes), contentDescription = null,
                    tint = Cyan, modifier = Modifier.size(28.dp)
                )
            } else if (emoji != null) {
                Text(emoji, fontSize = 24.sp)
            }
        }
        Text(title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = c.muted, fontSize = 12.sp, minLines = 2, maxLines = 2)
    }
}
