package com.mostafa.downloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/** خطأ بنقدر نعرضه للمستخدم بالعربي والإنجليزي */
class AiTransException(val msg: Msg) : Exception(msg.en)

data class SubSeg(val start: Double, val end: Double, var text: String)

/** تشغيل ffmpeg اللي جوه مكتبة youtubedl-android مباشرة (من غير yt-dlp) */
object FfRun {
    private fun ffmpegFile(ctx: Context): File {
        try {
            val f = YoutubeDL::class.java.getDeclaredField("ffmpegPath")
            f.isAccessible = true
            val v = f.get(YoutubeDL.getInstance()) as? File
            if (v != null && v.exists()) return v
        } catch (_: Throwable) {
        }
        return File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so")
    }

    private fun ldPath(ctx: Context): String {
        try {
            val f = YoutubeDL::class.java.getDeclaredField("ENV_LD_LIBRARY_PATH")
            f.isAccessible = true
            val v = f.get(YoutubeDL.getInstance()) as? String
            if (!v.isNullOrBlank()) return v
        } catch (_: Throwable) {
        }
        val base = File(ctx.noBackupFilesDir, "youtubedl-android/packages")
        return listOf("python", "ffmpeg", "aria2c")
            .joinToString(":") { File(base, "$it/usr/lib").absolutePath }
    }

    /** بيرجع (كود الخروج، آخر جزء من المخرجات) */
    fun run(ctx: Context, args: List<String>): Pair<Int, String> {
        val bin = ffmpegFile(ctx)
        if (!bin.exists()) return -1 to "ffmpeg binary not found at ${bin.absolutePath}"
        val pb = ProcessBuilder(listOf(bin.absolutePath) + args).redirectErrorStream(true)
        val env = pb.environment()
        val old = env["LD_LIBRARY_PATH"]
        env["LD_LIBRARY_PATH"] = ldPath(ctx) + if (old.isNullOrEmpty()) "" else ":$old"
        env["TMPDIR"] = ctx.cacheDir.absolutePath
        val p = pb.start()
        val out = StringBuilder()
        p.inputStream.bufferedReader().useLines { lines ->
            lines.forEach {
                out.append(it).append('\n')
                if (out.length > 6000) out.delete(0, out.length - 3000)
            }
        }
        return p.waitFor() to out.toString()
    }
}

/**
 * ترجمة كلام الفيديو تلقائياً (إنجليزي ← عربي، وعربي ← إنجليزي) ودمجها في الفيديو:
 * 1) ffmpeg يطلّع الصوت مقسّم لأجزاء 10 دقايق
 * 2) Groq Whisper يحوّل الكلام لنص بتوقيتات ويحدد اللغة
 * 3) الترجمة عن طريق Google Translate (من غير مفتاح)
 * 4) دمج ملف SRT جوه الـ MP4 كمسار ترجمة (من غير إعادة ترميز)
 */
object AiTrans {
    private const val CHUNK_SEC = 600
    private const val GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
    private const val MODEL = "whisper-large-v3-turbo"

    data class Result(val src: String, val target: String, val muxed: Boolean, val note: Msg?)

    private val langNames = mapOf(
        "english" to "en", "arabic" to "ar", "french" to "fr", "spanish" to "es",
        "german" to "de", "turkish" to "tr", "russian" to "ru", "italian" to "it",
        "portuguese" to "pt", "hindi" to "hi", "urdu" to "ur", "persian" to "fa",
        "japanese" to "ja", "korean" to "ko", "chinese" to "zh", "indonesian" to "id",
        "dutch" to "nl"
    )

    suspend fun run(
        ctx: Context,
        video: File,
        apiKey: String,
        keepSrt: Boolean,
        onStage: (Msg) -> Unit,
        cancelled: () -> Boolean
    ): Result = withContext(Dispatchers.IO) {
        val work = File(ctx.cacheDir, "ai/${System.nanoTime()}").apply { mkdirs() }
        try {
            fun check() {
                if (cancelled()) throw IllegalStateException("cancelled")
            }

            // 1) استخراج الصوت
            onStage(Msg("جاري استخراج الصوت...", "Extracting the audio..."))
            val (code, log) = FfRun.run(
                ctx,
                listOf(
                    "-y", "-hide_banner", "-nostdin", "-i", video.absolutePath,
                    "-vn", "-ac", "1", "-ar", "16000", "-c:a", "libmp3lame", "-b:a", "32k",
                    "-f", "segment", "-segment_time", CHUNK_SEC.toString(), "-reset_timestamps", "1",
                    File(work, "c%03d.mp3").absolutePath
                )
            )
            val chunks = work.listFiles { f -> f.extension == "mp3" && f.length() > 0 }
                ?.sortedBy { it.name }.orEmpty()
            if (chunks.isEmpty()) {
                if (log.contains("does not contain any stream") || log.contains("Stream map") ||
                    log.contains("no audio", true)
                ) throw AiTransException(Msg("الفيديو ده مفيهوش صوت", "This video has no audio"))
                throw AiTransException(
                    Msg(
                        "تعذّر استخراج الصوت (ffmpeg code $code): ${log.takeLast(200)}",
                        "Could not extract audio (ffmpeg code $code): ${log.takeLast(200)}"
                    )
                )
            }
            check()

            // 2) التعرف على الكلام
            val segs = ArrayList<SubSeg>()
            var srcName = ""
            var srcCode: String? = null
            chunks.forEachIndexed { i, f ->
                check()
                onStage(
                    Msg(
                        "جاري التعرف على الكلام (${i + 1}/${chunks.size})...",
                        "Recognizing speech (${i + 1}/${chunks.size})..."
                    )
                )
                val j = transcribe(apiKey, f, srcCode)
                if (srcName.isEmpty()) {
                    srcName = j.optString("language", "").lowercase(Locale.US)
                    srcCode = langNames[srcName]
                }
                val arr = j.optJSONArray("segments") ?: JSONArray()
                val off = i * CHUNK_SEC.toDouble()
                for (k in 0 until arr.length()) {
                    val s = arr.getJSONObject(k)
                    val t = s.optString("text", "").trim()
                    if (t.isEmpty()) continue
                    if (s.optDouble("no_speech_prob", 0.0) > 0.9) continue
                    val a = off + s.optDouble("start", 0.0)
                    val b = off + s.optDouble("end", a - off + 2.0)
                    segs.add(SubSeg(a, if (b > a) b else a + 2.0, t))
                }
            }
            if (segs.isEmpty()) {
                throw AiTransException(
                    Msg("مفيش كلام واضح في الفيديو", "No clear speech was found in the video")
                )
            }

            // 3) الترجمة: عربي ← إنجليزي، أي لغة تانية ← عربي
            val src = srcCode ?: "auto"
            val target = if (src == "ar") "en" else "ar"
            val done = AtomicInteger(0)
            val failed = AtomicInteger(0)
            val sem = Semaphore(4)
            coroutineScope {
                segs.map { s ->
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            if (cancelled()) return@withPermit
                            val r = translateOne(s.text, src, target)
                            if (r == null) failed.incrementAndGet() else s.text = r
                            val n = done.incrementAndGet()
                            if (n % 8 == 0 || n == segs.size) {
                                onStage(
                                    Msg(
                                        "جاري الترجمة ($n/${segs.size})...",
                                        "Translating ($n/${segs.size})..."
                                    )
                                )
                            }
                        }
                    }
                }.awaitAll()
            }
            check()
            if (failed.get() > segs.size / 2) {
                throw AiTransException(
                    Msg(
                        "فشلت الترجمة — اتأكد من الإنترنت وجرّب تاني",
                        "Translation failed — check your connection and try again"
                    )
                )
            }

            // 4) كتابة SRT ودمجه
            onStage(Msg("جاري دمج الترجمة في الفيديو...", "Embedding subtitles into the video..."))
            val srt = File(work, "${video.nameWithoutExtension}.$target.srt")
            srt.writeText(buildSrt(segs, target == "ar"), Charsets.UTF_8)

            var muxed = false
            var note: Msg? = null
            val ext = video.extension.lowercase(Locale.US)
            if (ext in setOf("mp4", "m4v", "mov")) {
                val out = File(work, "out.$ext")
                val iso = when (target) { "ar" -> "ara"; "en" -> "eng"; else -> "und" }
                val (mc, mlog) = FfRun.run(
                    ctx,
                    listOf(
                        "-y", "-hide_banner", "-nostdin",
                        "-i", video.absolutePath, "-i", srt.absolutePath,
                        "-map", "0:v", "-map", "0:a?", "-map", "1:0",
                        "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
                        "-metadata:s:s:0", "language=$iso",
                        "-disposition:s:0", "default",
                        "-movflags", "+faststart",
                        out.absolutePath
                    )
                )
                if (mc == 0 && out.exists() && out.length() > 0) {
                    video.delete()
                    if (!out.renameTo(video)) {
                        out.copyTo(video, overwrite = true)
                    }
                    muxed = true
                } else {
                    note = Msg(
                        "ما قدرتش أدمج الترجمة (${mlog.takeLast(120)}) — حفظت ملف SRT منفصل.",
                        "Couldn't embed the subtitles (${mlog.takeLast(120)}) — saved a separate SRT file."
                    )
                }
            } else {
                note = Msg(
                    "صيغة الفيديو (.$ext) مش بتدعم دمج الترجمة — حفظت ملف SRT منفصل.",
                    "This video format (.$ext) can't hold embedded subtitles — saved a separate SRT file."
                )
            }
            // لو الدمج ما نفعش أو المستخدم طلب ملف SRT نسيب الملف جنب الفيديو
            if (keepSrt || !muxed) {
                srt.copyTo(File(video.parentFile, srt.name), overwrite = true)
            }
            Result(src, target, muxed, note)
        } finally {
            work.deleteRecursively()
        }
    }

    // ---------------- Groq Whisper ----------------

    private fun transcribe(key: String, f: File, lang: String?): JSONObject {
        val boundary = "----md" + System.nanoTime()
        val conn = URL(GROQ_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 20000
            conn.readTimeout = 180000
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            conn.setChunkedStreamingMode(0)
            DataOutputStream(conn.outputStream).use { out ->
                fun field(n: String, v: String) {
                    out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n")
                }
                field("model", MODEL)
                field("response_format", "verbose_json")
                field("temperature", "0")
                if (lang != null) field("language", lang)
                out.writeBytes(
                    "--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"${f.name}\"\r\n" +
                        "Content-Type: audio/mpeg\r\n\r\n"
                )
                f.inputStream().use { it.copyTo(out) }
                out.writeBytes("\r\n--$boundary--\r\n")
            }
            val code = conn.responseCode
            val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code in 200..299) return JSONObject(body)
            val em = try {
                JSONObject(body).getJSONObject("error").optString("message", body.take(150))
            } catch (_: Exception) {
                body.take(150)
            }
            throw AiTransException(
                when (code) {
                    401 -> Msg(
                        "مفتاح Groq غير صحيح — راجعه من الإعدادات",
                        "Invalid Groq API key — check it in Settings"
                    )
                    413 -> Msg("جزء الصوت كبير أوي على Groq", "The audio chunk is too large for Groq")
                    429 -> Msg(
                        "وصلت للحد المجاني من Groq مؤقتاً — استنى شوية وجرّب تاني. ($em)",
                        "Groq free-tier limit reached for now — wait a bit and try again. ($em)"
                    )
                    else -> Msg("خطأ من Groq ($code): $em", "Groq error ($code): $em")
                }
            )
        } catch (e: AiTransException) {
            throw e
        } catch (e: Exception) {
            throw AiTransException(
                Msg(
                    "تعذّر الاتصال بـ Groq: ${e.message}",
                    "Couldn't reach Groq: ${e.message}"
                )
            )
        } finally {
            conn.disconnect()
        }
    }

    // ---------------- Google Translate (gtx) ----------------

    private fun translateOne(text: String, sl: String, tl: String): String? {
        repeat(3) { attempt ->
            try {
                val u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=" +
                    URLEncoder.encode(text, "UTF-8")
                val conn = URL(u).openConnection() as HttpURLConnection
                try {
                    conn.connectTimeout = 10000
                    conn.readTimeout = 15000
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    if (conn.responseCode == 200) {
                        val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
                            .getJSONArray(0)
                        val sb = StringBuilder()
                        for (i in 0 until arr.length()) {
                            val part = arr.getJSONArray(i)
                            if (!part.isNull(0)) sb.append(part.getString(0))
                        }
                        val r = sb.toString().trim()
                        if (r.isNotEmpty()) return r
                    }
                } finally {
                    conn.disconnect()
                }
            } catch (_: Exception) {
            }
            try {
                Thread.sleep(400L * (attempt + 1))
            } catch (_: InterruptedException) {
            }
        }
        return null
    }

    // ---------------- SRT ----------------

    private fun fmt(sec: Double): String {
        val t = Math.round(sec * 1000).coerceAtLeast(0)
        return String.format(
            Locale.US, "%02d:%02d:%02d,%03d",
            t / 3600000, (t / 60000) % 60, (t / 1000) % 60, t % 1000
        )
    }

    private fun wrap(text: String, max: Int = 42): List<String> {
        val lines = ArrayList<String>()
        var cur = StringBuilder()
        for (w in text.trim().split(Regex("\\s+"))) {
            if (cur.isNotEmpty() && cur.length + 1 + w.length > max) {
                lines.add(cur.toString())
                cur = StringBuilder()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
        }
        if (cur.isNotEmpty()) lines.add(cur.toString())
        return lines
    }

    private fun buildSrt(segs: List<SubSeg>, rtl: Boolean): String {
        val sb = StringBuilder()
        var n = 1
        for (s in segs) {
            if (s.text.isBlank()) continue
            sb.append(n++).append('\n')
                .append(fmt(s.start)).append(" --> ").append(fmt(s.end)).append('\n')
            wrap(s.text).forEach { line ->
                // RLE ... PDF عشان علامات الترقيم تظهر في الجهة الصح مع العربي
                if (rtl) sb.append('\u202B').append(line).append('\u202C') else sb.append(line)
                sb.append('\n')
            }
            sb.append('\n')
        }
        return sb.toString()
    }
}
