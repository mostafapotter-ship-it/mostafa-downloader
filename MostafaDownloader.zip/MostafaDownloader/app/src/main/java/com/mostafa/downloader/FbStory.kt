package com.mostafa.downloader

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import kotlin.coroutines.resume

/**
 * محاولة احتياطية لتحميل استوريهات فيسبوك (المحرك الأساسي مش بيدعمها).
 * 1) بتفتح الصفحة في متصفح مخفي (WebView) بجلسة الدخول المحفوظة وتدوّر على روابط الفيديو/الصورة.
 * 2) لو فشلت بتجرّب طلبات مباشرة بأكتر من شكل.
 */
object FbStory {
    private const val UA_DESKTOP =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private const val UA_MOBILE =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

    private class Page(val html: String, val finalUrl: String)
    private class Parsed(val items: List<Pair<String, String>>, val diag: String)

    private fun cookieHeader(ctx: Context): String {
        val f = CookieStore.file(ctx, "fb")
        if (!f.exists()) return ""
        val seen = LinkedHashMap<String, String>()
        f.readLines()
            .filter { !it.startsWith("#") || it.startsWith("#HttpOnly_") }
            .forEach { line ->
                val p = line.split('\t')
                if (p.size >= 7) seen[p[5].trim()] = p[6].trim()
            }
        return seen.entries.joinToString("; ") { it.key + "=" + it.value }
    }

    private fun unescape(s: String): String {
        val r = Regex("\\\\u([0-9a-fA-F]{4})").replace(s) { it.groupValues[1].toInt(16).toChar().toString() }
        return r.replace("\\/", "/")
    }

    private fun grab(html: String, key: String): List<String> =
        Regex("\"" + key + "\":\"(https:[^\"]+)\"").findAll(html)
            .map { unescape(it.groupValues[1]) }.distinct().toList()

    private fun grabNested(html: String, outer: String, inner: String): List<String> =
        Regex("\"" + outer + "\":\\{\"" + inner + "\":\"(https:[^\"]+)\"").findAll(html)
            .map { unescape(it.groupValues[1]) }.distinct().toList()

    private fun hostOf(u: String): String =
        Regex("^https://([^/]+)").find(u)?.groupValues?.get(1) ?: u.take(24)

    private fun parse(html: String): Parsed {
        val hd = grab(html, "browser_native_hd_url")
        val sd = grab(html, "browser_native_sd_url")
        val pl = grab(html, "playable_url")
        val videos = when {
            hd.isNotEmpty() -> hd
            sd.isNotEmpty() -> sd
            else -> pl
        }
        val photos = grabNested(html, "photo_image", "uri")
        val items: List<Pair<String, String>> =
            if (videos.isNotEmpty()) videos.map { it to "mp4" } else photos.map { it to "jpg" }
        val keys = Regex("\"([A-Za-z_]*(?:url|uri)[A-Za-z_]*)\":\"https:").findAll(html)
            .map { it.groupValues[1] }.toSet().take(10).joinToString(",")
        val title = Regex("<title[^>]*>([^<]{0,60})").find(html)?.groupValues?.get(1)?.trim() ?: ""
        return Parsed(
            items,
            "page=${html.length}, title=$title, hd=${hd.size}, sd=${sd.size}, pl=${pl.size}, ph=${photos.size}, keys=$keys"
        )
    }

    // ---------- 1) متصفح مخفي ----------
    private fun decodeJs(raw: String?): String {
        if (raw == null || raw == "null") return ""
        return try {
            val v = JSONTokener(raw).nextValue()
            if (v is String) v else ""
        } catch (e: Exception) {
            ""
        }
    }

    private suspend fun evalHtml(w: WebView?): String? = suspendCancellableCoroutine { cont ->
        if (w == null) {
            cont.resume(null)
        } else {
            w.evaluateJavascript("(function(){return document.documentElement.outerHTML})()") { v ->
                if (cont.isActive) cont.resume(v)
            }
        }
    }

    private fun stripRange(u: String): String =
        u.replace(Regex("[&?]bytestart=\\d+"), "").replace(Regex("[&?]byteend=\\d+"), "")

    private suspend fun scanWithWebView(ctx: Context, url: String): Parsed {
        val media = Collections.synchronizedSet(LinkedHashSet<String>())
        var wv: WebView? = null
        try {
            withContext(Dispatchers.Main) {
                val w = WebView(ctx.applicationContext)
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.userAgentString = UA_DESKTOP
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val u = request?.url?.toString()
                        if (u != null && u.contains(".mp4")) media.add(u)
                        return null
                    }
                }
                w.loadUrl(url)
                wv = w
            }

            var lastDiag = ""
            val deadline = System.currentTimeMillis() + 40000
            var round = 0
            while (System.currentTimeMillis() < deadline) {
                delay(2500)
                round++
                val raw: String? = withContext(Dispatchers.Main) { evalHtml(wv) }
                val parsed = parse(decodeJs(raw))
                lastDiag = parsed.diag
                if (parsed.items.isNotEmpty()) return parsed
                if (media.isNotEmpty() && round >= 3) break
            }
            val snapshot = synchronized(media) { media.toList() }
            val m = snapshot.map { stripRange(it) }.distinct().take(4)
            if (m.isNotEmpty()) return Parsed(m.map { it to "mp4" }, "captured ${m.size} media requests")
            val cur = withContext(Dispatchers.Main) { wv?.url }
            return Parsed(emptyList(), "url=${cur?.take(70)}, media=${media.size}, $lastDiag")
        } finally {
            withContext(Dispatchers.Main) {
                try {
                    wv?.destroy()
                } catch (e: Exception) {
                }
            }
        }
    }

    // ---------- 2) طلبات مباشرة ----------
    private fun open(ctx: Context, url: String, ua: String, withCookies: Boolean = true): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        if (withCookies) conn.setRequestProperty("Cookie", cookieHeader(ctx))
        conn.setRequestProperty("User-Agent", ua)
        conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        return conn
    }

    private fun load(ctx: Context, url: String, ua: String): Page {
        val conn = open(ctx, url, ua)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            val html = conn.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
            return Page(html, conn.url.toString())
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchFile(ctx: Context, u: String, dest: File) {
        val conn = open(ctx, u, UA_DESKTOP, false)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("media HTTP $code")
            conn.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
    }

    private fun saveItems(ctx: Context, items: List<Pair<String, String>>, dir: File) {
        items.take(10).forEachIndexed { i, (m, ext) ->
            fetchFile(ctx, m, File(dir, "facebook_story_${i + 1}.$ext"))
        }
    }

    suspend fun download(ctx: Context, urls: List<String>, dir: File) {
        val notes = ArrayList<String>()

        // 1) المتصفح المخفي
        val target = urls.firstOrNull()
        if (target != null) {
            try {
                val r = scanWithWebView(ctx, target)
                if (r.items.isNotEmpty()) {
                    saveItems(ctx, r.items, dir)
                    return
                }
                notes.add("webview: no media (${r.diag})")
            } catch (e: Exception) {
                notes.add("webview: ${e.message ?: e.javaClass.simpleName}")
            }
        }

        // 2) طلبات مباشرة
        val attempts = ArrayList<Pair<String, String>>()
        for (u in urls) {
            attempts.add(u to UA_DESKTOP)
            attempts.add(u to UA_MOBILE)
        }
        val host = target?.let { Regex("^https://[^/]+").find(it)?.value }
        if (target != null && host != null) {
            attempts.add(target.replaceFirst(host, "https://mbasic.facebook.com") to UA_MOBILE)
        }
        for ((u, ua) in attempts) {
            val tag = hostOf(u) + (if (ua == UA_MOBILE) "/m" else "/d")
            try {
                val page = load(ctx, u, ua)
                if (page.finalUrl.contains("/login") || page.finalUrl.contains("checkpoint")) {
                    notes.add("$tag: redirected to sign-in")
                    continue
                }
                val parsed = parse(page.html)
                if (parsed.items.isEmpty()) {
                    notes.add("$tag: no media (${parsed.diag})")
                    continue
                }
                saveItems(ctx, parsed.items, dir)
                return
            } catch (e: Exception) {
                notes.add("$tag: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        throw IllegalStateException("ERROR: Facebook story failed. " + notes.joinToString(" | "))
    }
}
