package com.mostafa.downloader

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * محاولة احتياطية لتحميل استوريهات فيسبوك (المحرك الأساسي مش بيدعمها).
 * بتفتح صفحة الاستوري بجلسة الدخول المحفوظة وتدوّر على روابط الفيديو/الصورة جواها.
 */
object FbStory {
    private const val UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun cookieHeader(ctx: Context): String {
        val f = CookieStore.file(ctx, "fb")
        if (!f.exists()) return ""
        return f.readLines()
            .filter { !it.startsWith("#") || it.startsWith("#HttpOnly_") }
            .mapNotNull { line ->
                val p = line.split('\t')
                if (p.size >= 7) p[5] + "=" + p[6] else null
            }
            .joinToString("; ")
    }

    private fun unescape(s: String): String {
        val r = Regex("\\\\u([0-9a-fA-F]{4})").replace(s) { it.groupValues[1].toInt(16).toChar().toString() }
        return r.replace("\\/", "/")
    }

    private fun grab(html: String, key: String): List<String> =
        Regex("\"" + key + "\":\"(https:[^\"]+)\"").findAll(html)
            .map { unescape(it.groupValues[1]) }.distinct().toList()

    private fun grabNested(html: String, outer: String, inner: String): List<String> =
        Regex("\"" + outer + "\":\\{\"" + inner + "\":\"(https:[^\"]+)\"").findAll(html)
            .map { unescape(it.groupValues[1]) }.distinct().toList()

    private fun open(ctx: Context, url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("Cookie", cookieHeader(ctx))
        conn.setRequestProperty("User-Agent", UA)
        conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        return conn
    }

    fun download(ctx: Context, url: String, dir: File) {
        val html: String
        val finalUrl: String
        val conn = open(ctx, url)
        try {
            html = conn.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
            finalUrl = conn.url.toString()
        } catch (e: IOException) {
            throw IllegalStateException("Facebook page request failed: " + (e.message ?: ""))
        } finally {
            conn.disconnect()
        }
        if (finalUrl.contains("/login") || finalUrl.contains("checkpoint")) {
            throw IllegalStateException("Facebook asked for a new sign-in. Sign out and in again from the Stories tab.")
        }

        val hd = grab(html, "browser_native_hd_url")
        val sd = grab(html, "browser_native_sd_url")
        val pl = grab(html, "playable_url")
        val videos = when {
            hd.isNotEmpty() -> hd
            sd.isNotEmpty() -> sd
            else -> pl
        }
        val photos = grabNested(html, "photo_image", "uri")
        val items: List<Pair<String, String>> =
            if (videos.isNotEmpty()) videos.map { it to "mp4" } else photos.map { it to "jpg" }

        if (items.isEmpty()) {
            val keys = Regex("\"([A-Za-z_]*(?:url|uri)[A-Za-z_]*)\":\"https:").findAll(html)
                .map { it.groupValues[1] }.toSet().take(15).joinToString(",")
            throw IllegalStateException(
                "ERROR: Facebook story: no media found (page=${html.length}, hd=${hd.size}, sd=${sd.size}, " +
                    "pl=${pl.size}, ph=${photos.size}, url=${finalUrl.take(70)}, keys=$keys)"
            )
        }
        items.take(10).forEachIndexed { i, (u, ext) ->
            fetchFile(ctx, u, File(dir, "facebook_story_${i + 1}.$ext"))
        }
    }

    private fun fetchFile(ctx: Context, u: String, dest: File) {
        val conn = open(ctx, u)
        try {
            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
            conn.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
    }
}
