package com.mostafa.downloader

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * محاولة احتياطية لتحميل استوريهات فيسبوك (المحرك الأساسي مش بيدعمها).
 * بتفتح صفحة الاستوري بجلسة الدخول المحفوظة (بأكتر من طريقة) وتدوّر على روابط الفيديو/الصورة جواها.
 */
object FbStory {
    private const val UA_DESKTOP =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private const val UA_MOBILE =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

    private class Page(val html: String, val finalUrl: String)
    private class Parsed(val items: List<Pair<String, String>>, val diag: String)

    private fun cookieHeader(ctx: Context): String {
        val f = CookieStore.file(ctx, "fb")
        if (!f.exists()) return ""
        return f.readLines()
            .filter { !it.startsWith("#") || it.startsWith("#HttpOnly_") }
            .mapNotNull { line ->
                val p = line.split('\t')
                if (p.size >= 7) p[5] + "=" + p[6] else null
            }
            .joinToString("; ")
    }

    private fun unescape(s: String): String {
        val r = Regex("\\\\u([0-9a-fA-F]{4})").replace(s) { it.groupValues[1].toInt(16).toChar().toString() }
        return r.replace("\\/", "/")
    }

    private fun grab(html: String, key: String): List<String> =
        Regex("\"" + key + "\":\"(https:[^\"]+)\"").findAll(html)
            .map { unescape(it.groupValues[1]) }.distinct().toList()

    private fun grabNested(html: String, outer: String, inner: String): List<String> =
        Regex("\"" + outer + "\":\\{\"" + inner + "\":\"(https:[^\"]+)\"").findAll(html)
            .map { unescape(it.groupValues[1]) }.distinct().toList()

    private fun hostOf(u: String): String =
        Regex("^https://([^/]+)").find(u)?.groupValues?.get(1) ?: u.take(24)

    private fun open(ctx: Context, url: String, ua: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("Cookie", cookieHeader(ctx))
        conn.setRequestProperty("User-Agent", ua)
        conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        return conn
    }

    private fun load(ctx: Context, url: String, ua: String): Page {
        val conn = open(ctx, url, ua)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            val html = conn.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
            return Page(html, conn.url.toString())
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(html: String): Parsed {
        val hd = grab(html, "browser_native_hd_url")
        val sd = grab(html, "browser_native_sd_url")
        val pl = grab(html, "playable_url")
        val videos = when {
            hd.isNotEmpty() -> hd
            sd.isNotEmpty() -> sd
            else -> pl
        }
        val photos = grabNested(html, "photo_image", "uri")
        val items: List<Pair<String, String>> =
            if (videos.isNotEmpty()) videos.map { it to "mp4" } else photos.map { it to "jpg" }
        val keys = Regex("\"([A-Za-z_]*(?:url|uri)[A-Za-z_]*)\":\"https:").findAll(html)
            .map { it.groupValues[1] }.toSet().take(12).joinToString(",")
        return Parsed(items, "page=${html.length}, hd=${hd.size}, sd=${sd.size}, pl=${pl.size}, ph=${photos.size}, keys=$keys")
    }

    private fun fetchFile(ctx: Context, u: String, dest: File) {
        val conn = open(ctx, u, UA_DESKTOP)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("media HTTP $code")
            conn.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
    }

    fun download(ctx: Context, urls: List<String>, dir: File) {
        val attempts = ArrayList<Pair<String, String>>()
        for (u in urls) {
            attempts.add(u to UA_DESKTOP)
            attempts.add(u to UA_MOBILE)
        }
        val first = urls.firstOrNull()
        val host = first?.let { Regex("^https://[^/]+").find(it)?.value }
        if (first != null && host != null) {
            attempts.add(first.replaceFirst(host, "https://m.facebook.com") to UA_MOBILE)
            attempts.add(first.replaceFirst(host, "https://mbasic.facebook.com") to UA_MOBILE)
        }

        val notes = ArrayList<String>()
        for ((u, ua) in attempts) {
            val tag = hostOf(u) + (if (ua == UA_MOBILE) "/m" else "/d")
            try {
                val page = load(ctx, u, ua)
                if (page.finalUrl.contains("/login") || page.finalUrl.contains("checkpoint")) {
                    notes.add("$tag: redirected to sign-in")
                    continue
                }
                val parsed = parse(page.html)
                if (parsed.items.isEmpty()) {
                    notes.add("$tag: no media (${parsed.diag})")
                    continue
                }
                parsed.items.take(10).forEachIndexed { i, (m, ext) ->
                    fetchFile(ctx, m, File(dir, "facebook_story_${i + 1}.$ext"))
                }
                return
            } catch (e: Exception) {
                notes.add("$tag: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        throw IllegalStateException("ERROR: Facebook story failed. " + notes.joinToString(" | "))
    }
}
