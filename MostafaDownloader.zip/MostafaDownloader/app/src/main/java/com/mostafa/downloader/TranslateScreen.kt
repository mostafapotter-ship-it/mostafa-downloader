package com.mostafa.downloader

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import android.widget.Toast
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** تبويب الترجمة: بتختار فيديو من موبايلك والتطبيق يترجمه ويحرق الترجمة على الصورة */
@Composable
fun TranslateScreen(vm: DownloaderViewModel, onOpenSettings: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val s by vm.settings.collectAsState()
    val t by vm.trans.collectAsState()
    val hasKey = s.groqKey.isNotBlank()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) vm.translateLocal(uri)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            l.t("🌐 أدوات الفيديو الذكية", "🌐 Smart Video Tools"),
            color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(10.dp))
        var part by rememberSaveable { mutableStateOf(0) }
        Segmented(
            options = listOf(l.t("ترجمة على الفيديو", "Burn-in translation"), l.t("نص وملخص", "Transcript & summary")),
            selected = part
        ) { part = it }
        Spacer(Modifier.height(10.dp))
        if (part == 1) {
            TranscriptPanel(vm, hasKey, onOpenSettings)
            return@Column
        }
        Text(
            l.t(
                "اختر الفيديو من هاتفك، وسيتولى التطبيق ترجمته تلقائياً.",
                "Choose a video from your phone and the app will translate it automatically."
            ),
            color = c.muted, fontSize = 14.sp
        )
        Spacer(Modifier.height(16.dp))

        AppCard {
            if (!hasKey) {
                Text(
                    l.t(
                        "محتاج مفتاح Groq المجاني الأول، ضيفه من الإعدادات.",
                        "You need your free Groq key first. Add it in Settings."
                    ),
                    color = c.text, fontSize = 14.sp
                )
                Spacer(Modifier.height(12.dp))
                GradientButton(l.t("فتح الإعدادات", "Open Settings")) { onOpenSettings() }
            } else if (t.running) {
                Text(
                    t.stage?.get(l.ar) ?: l.t("جاري الشغل...", "Working..."),
                    color = c.text, fontSize = 15.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = Cyan, trackColor = c.stroke
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    l.t(
                        "يرجى إبقاء التطبيق مفتوحاً حتى تكتمل الترجمة.",
                        "Please keep the app open until the translation completes."
                    ),
                    color = c.muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlineButton(l.t("إلغاء", "Cancel")) { vm.cancelTranslate() }
            } else {
                GradientButton(l.t("🎬 اختيار فيديو", "🎬 Choose a video")) { picker.launch("video/*") }
            }
        }

        if (!t.running && t.error != null) {
            Spacer(Modifier.height(12.dp))
            AppCard {
                Text(t.error!!.get(l.ar), color = ErrorC, fontSize = 14.sp)
            }
        }

        if (!t.running && t.doneUri.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            AppCard {
                Text(
                    l.t("✅ تمت الترجمة", "✅ Translation done"),
                    color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    l.t("اتحفظ في ", "Saved to ") + t.doneWhere,
                    color = c.muted, fontSize = 13.sp
                )
                t.note?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it.get(l.ar), color = c.muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(12.dp))
                GradientButton(l.t("▶ تشغيل الفيديو", "▶ Play video")) {
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW)
                                .setDataAndType(Uri.parse(t.doneUri), t.doneMime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlineButton(l.t("ترجمة فيديو تاني", "Translate another video")) {
                    vm.clearTrans()
                    picker.launch("video/*")
                }
            }
        }
    }
}

/** قسم "نص وملخص": بيطلّع كلام الفيديو مكتوب + ملخص بنقاط */
@Composable
private fun TranscriptPanel(vm: DownloaderViewModel, hasKey: Boolean, onOpenSettings: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val t by vm.transcript.collectAsState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) vm.transcribeLocal(uri)
    }

    Text(
        l.t(
            "الصق رابط فيديو (بيتحمّل الصوت بس) أو اختر ملفاً من هاتفك، وسيستخرج التطبيق كلامه مكتوباً مع ملخص بالنقاط الرئيسية.",
            "Paste a video link (only the audio is downloaded) or pick a file, and the app writes out the speech with a short summary."
        ),
        color = c.muted, fontSize = 14.sp
    )
    Spacer(Modifier.height(16.dp))

    AppCard {
        if (!hasKey) {
            Text(
                l.t(
                    "محتاج مفتاح Groq المجاني الأول، ضيفه من الإعدادات.",
                    "You need your free Groq key first. Add it in Settings."
                ),
                color = c.text, fontSize = 14.sp
            )
            Spacer(Modifier.height(12.dp))
            GradientButton(l.t("فتح الإعدادات", "Open Settings")) { onOpenSettings() }
        } else if (t.running) {
            Text(
                t.stage?.get(l.ar) ?: l.t("جاري الشغل...", "Working..."),
                color = c.text, fontSize = 15.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().height(4.dp),
                color = Cyan, trackColor = c.stroke
            )
            Spacer(Modifier.height(12.dp))
            OutlineButton(l.t("إلغاء", "Cancel")) { vm.cancelTranscript() }
        } else {
            var link by rememberSaveable { mutableStateOf("") }
            androidx.compose.material3.OutlinedTextField(
                value = link,
                onValueChange = { link = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(l.t("رابط الفيديو", "Video link")) },
                textStyle = androidx.compose.ui.text.TextStyle(
                    textDirection = androidx.compose.ui.text.style.TextDirection.Ltr, fontSize = 14.sp
                ),
                minLines = 1,
                maxLines = 3,
                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                trailingIcon = {
                    androidx.compose.material3.TextButton(
                        onClick = {
                            link = if (link.isBlank()) clipboard.getText()?.text.orEmpty() else ""
                        }
                    ) {
                        Text(
                            if (link.isBlank()) l.t("لصق", "Paste") else l.t("مسح", "Clear"),
                            color = if (link.isBlank()) Cyan else c.muted
                        )
                    }
                },
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = c.stroke,
                    focusedTextColor = c.text,
                    unfocusedTextColor = c.text,
                    focusedLabelColor = Purple,
                    unfocusedLabelColor = c.muted,
                    cursorColor = Cyan
                )
            )
            Spacer(Modifier.height(10.dp))
            GradientButton(l.t("📝 استخراج النص من الرابط", "📝 Transcribe from link")) {
                vm.transcribeUrl(link)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                l.t("أو من ملف على هاتفك", "or from a file on your phone"),
                color = c.muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlineButton(l.t("🎬 اختيار فيديو أو صوت", "🎬 Choose a video or audio")) { picker.launch("*/*") }
        }
    }

    if (!t.running && t.error != null) {
        Spacer(Modifier.height(12.dp))
        AppCard { Text(t.error!!.get(l.ar), color = ErrorC, fontSize = 14.sp) }
    }

    if (!t.running && t.text.isNotEmpty()) {
        fun copy(label: String, value: String) {
            clipboard.setText(AnnotatedString(value))
            Toast.makeText(context, l.t("تم نسخ $label", "$label copied"), Toast.LENGTH_SHORT).show()
        }
        if (t.summary.isBlank() && t.summaryError != null) {
            Spacer(Modifier.height(12.dp))
            AppCard {
                Text(l.t("📝 الملخص", "📝 Summary"), color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    l.t("النص اتطلّع بنجاح، لكن التلخيص تعذّر: ", "The transcript is ready, but summarizing failed: ") +
                        t.summaryError!!.get(l.ar),
                    color = c.muted, fontSize = 13.sp
                )
            }
        }
        if (t.summary.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            AppCard {
                Text(l.t("📝 الملخص", "📝 Summary"), color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(t.summary, color = c.text, fontSize = 14.sp)
                if (t.truncated) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        l.t(
                            "الفيديو طويل: الملخص مبني على الجزء الأول من الكلام.",
                            "Long video: the summary is based on the first part of the speech."
                        ),
                        color = c.muted, fontSize = 12.sp
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlineButton(l.t("نسخ الملخص", "Copy summary")) { copy(l.t("الملخص", "Summary"), t.summary) }
            }
        }
        Spacer(Modifier.height(12.dp))
        AppCard {
            var expanded by rememberSaveable { mutableStateOf(false) }
            Text(l.t("📄 النص الكامل", "📄 Full transcript"), color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                if (expanded || t.text.length <= 600) t.text else t.text.take(600) + "…",
                color = c.text, fontSize = 13.sp
            )
            if (t.text.length > 600) {
                Spacer(Modifier.height(8.dp))
                OutlineButton(if (expanded) l.t("إخفاء", "Collapse") else l.t("عرض الكل", "Show all")) { expanded = !expanded }
            }
            Spacer(Modifier.height(10.dp))
            OutlineButton(l.t("نسخ النص", "Copy transcript")) { copy(l.t("النص", "Transcript"), t.text) }
            Spacer(Modifier.height(8.dp))
            OutlineButton(l.t("مشاركة", "Share")) {
                val body = (if (t.summary.isNotBlank()) t.summary + "\n\n" else "") + t.text
                try {
                    context.startActivity(
                        Intent.createChooser(
                            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, body),
                            null
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlineButton(l.t("حفظ كملف نصي", "Save as a text file")) {
                vm.saveTranscript { where ->
                    Toast.makeText(
                        context,
                        if (where != null) l.t("اتحفظ في ", "Saved to ") + where else l.t("تعذر الحفظ", "Couldn't save"),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            Spacer(Modifier.height(8.dp))
            GradientButton(l.t("استخراج نص لملف تاني", "Transcribe another file")) {
                vm.clearTranscript()
                picker.launch("*/*")
            }
        }
    }
    Spacer(Modifier.height(24.dp))
}
