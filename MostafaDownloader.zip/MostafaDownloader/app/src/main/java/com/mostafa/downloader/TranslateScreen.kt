package com.mostafa.downloader

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** تبويب الترجمة: بتختار فيديو من موبايلك والتطبيق يترجمه ويحرق الترجمة على الصورة */
@Composable
fun TranslateScreen(vm: DownloaderViewModel, onOpenSettings: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    val context = LocalContext.current
    val s by vm.settings.collectAsState()
    val t by vm.trans.collectAsState()
    val hasKey = s.groqKey.isNotBlank()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) vm.translateLocal(uri)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            l.t("🌐 ترجمة فيديو من موبايلك", "🌐 Translate a video from your phone"),
            color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(6.dp))
        Text(
            l.t(
                "اختار فيديو بلغة أجنبية والتطبيق يسمع الكلام ويترجمه للعربي ويكتبه على الفيديو نفسه.",
                "Pick a foreign-language video and the app listens, translates it to Arabic and writes the subtitles onto the video."
            ),
            color = c.muted, fontSize = 14.sp
        )
        Spacer(Modifier.height(16.dp))

        AppCard {
            if (!hasKey) {
                Text(
                    l.t(
                        "محتاج مفتاح Groq المجاني الأول، ضيفه من الإعدادات.",
                        "You need your free Groq key first. Add it in Settings."
                    ),
                    color = c.text, fontSize = 14.sp
                )
                Spacer(Modifier.height(12.dp))
                GradientButton(l.t("فتح الإعدادات", "Open Settings")) { onOpenSettings() }
            } else if (t.running) {
                Text(
                    t.stage?.get(l.ar) ?: l.t("جاري الشغل...", "Working..."),
                    color = c.text, fontSize = 15.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = Cyan, trackColor = c.stroke
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    l.t(
                        "سيب التطبيق مفتوح لحد ما يخلص. الفيديو الطويل بياخد وقت.",
                        "Keep the app open until it finishes. Long videos take a while."
                    ),
                    color = c.muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlineButton(l.t("إلغاء", "Cancel")) { vm.cancelTranslate() }
            } else {
                GradientButton(l.t("🎬 اختر فيديو من الموبايل", "🎬 Choose a video")) { picker.launch("video/*") }
            }
        }

        if (!t.running && t.error != null) {
            Spacer(Modifier.height(12.dp))
            AppCard {
                Text(t.error!!.get(l.ar), color = ErrorC, fontSize = 14.sp)
            }
        }

        if (!t.running && t.doneUri.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            AppCard {
                Text(
                    l.t("✅ تمت الترجمة", "✅ Translation done"),
                    color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    l.t("اتحفظ في ", "Saved to ") + t.doneWhere,
                    color = c.muted, fontSize = 13.sp
                )
                t.note?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it.get(l.ar), color = c.muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(12.dp))
                GradientButton(l.t("▶ تشغيل الفيديو", "▶ Play video")) {
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW)
                                .setDataAndType(Uri.parse(t.doneUri), t.doneMime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlineButton(l.t("ترجمة فيديو تاني", "Translate another video")) {
                    vm.clearTrans()
                    picker.launch("video/*")
                }
            }
        }
    }
}
