package com.mostafa.downloader

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * شفافة: بتقرا الحافظة (أندرويد 10+ بيسمح بس لما الشاشة في الواجهة)،
 * فلو فيه رابط بتبعته للتطبيق بنفس طريقة "مشاركة رابط" فيبدأ التحميل تلقائياً.
 */
class QuickPasteActivity : Activity() {
    private var handled = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || handled) return
        handled = true
        val txt = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        } catch (e: Exception) {
            ""
        }
        if (Regex("https?://\\S+").find(txt) == null) {
            Toast.makeText(this, R.string.widget_no_link, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val i = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, txt)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(i)
        finish()
    }
}
