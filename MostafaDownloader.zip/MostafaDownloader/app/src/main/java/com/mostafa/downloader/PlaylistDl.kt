package com.mostafa.downloader

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

/** أقصى عدد فيديوهات بنجيبها من القائمة/الحساب مرة واحدة */
const val LIST_MAX = 200

data class ListUi(
    val loading: Boolean = false,
    val url: String = "",
    val title: String = "",
    val urls: List<String> = emptyList(),
    val error: Msg? = null
)

object PlaylistParser {
    private val ytTab = Regex("^/(@[^/]+|channel/[^/]+|c/[^/]+|user/[^/]+)(/(videos|shorts|streams))?/?$")
    private val ytChannelNoTab = Regex("^/(@[^/]+|channel/[^/]+|c/[^/]+|user/[^/]+)/?$")
    private val ttProfile = Regex("^/@[^/]+/?$")
    private val igProfile = Regex("^/[A-Za-z0-9._]+/?$")
    private val igReserved = setOf("p", "reel", "reels", "stories", "explore", "tv", "accounts", "direct", "about")

    /** هل الرابط قائمة تشغيل أو صفحة حساب/قناة (مش فيديو واحد)؟ */
    fun isListLink(url: String): Boolean {
        val u = try { Uri.parse(url) } catch (e: Exception) { return false }
        val host = (u.host ?: return false).lowercase()
        val path = u.path ?: ""
        return when {
            host.endsWith("youtube.com") ->
                path.startsWith("/playlist") || ytTab.matches(path)
            host.endsWith("tiktok.com") -> ttProfile.matches(path)
            host.endsWith("instagram.com") ->
                igProfile.matches(path) && path.trim('/').lowercase() !in igReserved
            else -> false
        }
    }

    /** قناة يوتيوب من غير تبويب: نضيف /videos عشان نجيب الفيديوهات مباشرة */
    fun normalize(url: String): String {
        val u = try { Uri.parse(url) } catch (e: Exception) { return url }
        val host = (u.host ?: return url).lowercase()
        val path = u.path ?: ""
        if (host.endsWith("youtube.com") && ytChannelNoTab.matches(path)) {
            return url.substringBefore('?').trimEnd('/') + "/videos"
        }
        return url
    }

    class Result(val title: String, val urls: List<String>)

    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun collect(arr: JSONArray, out: LinkedHashSet<String>) {
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val nested = e.optJSONArray("entries")
            if (nested != null) {
                collect(nested, out)
                continue
            }
            var u = str(e, "url").ifEmpty { str(e, "webpage_url") }
            if (!u.startsWith("http")) {
                val id = str(e, "id")
                val ie = str(e, "ie_key").lowercase()
                u = if (id.isNotEmpty() && ie.startsWith("youtube")) "https://www.youtube.com/watch?v=$id" else ""
            }
            if (u.startsWith("http")) out.add(u)
        }
    }

    fun parse(raw: String): Result {
        val root = JSONObject(raw.trim())
        val out = LinkedHashSet<String>()
        root.optJSONArray("entries")?.let { collect(it, out) }
        val title = str(root, "title").ifEmpty { str(root, "uploader") }.ifEmpty { str(root, "channel") }
        return Result(title, out.toList().take(LIST_MAX))
    }
}

/**
 * بطاقة تحميل قائمة/حساب كامل: بتعرض عدد الفيديوهات وأزرار (آخر 10 / 25 / 50 / الكل).
 * [onDownload] بيستلم العدد المطلوب.
 */
@Composable
fun ListSection(
    ls: ListUi,
    link: String,
    ready: Boolean,
    onRetry: () -> Unit,
    onHide: () -> Unit,
    onDownload: (Int) -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    val mine = ls.url == link

    if (!mine || (!ls.loading && ls.error == null && ls.urls.isEmpty())) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                l.t("الرابط ده قائمة أو حساب", "This link is a playlist or profile"),
                color = c.muted, fontSize = 13.sp, modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onRetry, enabled = ready) {
                Text(l.t("جيب الفيديوهات", "Load videos"), color = Cyan, fontWeight = FontWeight.Bold)
            }
        }
        return
    }

    if (ls.loading) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CircularProgressIndicator(Modifier.size(22.dp), color = Cyan, strokeWidth = 2.5.dp)
            Text(
                l.t("جاري جلب فيديوهات القائمة...", "Fetching the list..."),
                color = c.muted, fontSize = 13.sp, modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onHide) {
                Text(l.t("إلغاء", "Cancel"), color = ErrorC)
            }
        }
        return
    }

    ls.error?.let { err ->
        Text(err.get(l.ar), color = ErrorC, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onRetry) {
                Text(l.t("إعادة المحاولة", "Retry"), color = Cyan, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onHide) {
                Text(l.t("إخفاء", "Hide"), color = c.muted)
            }
        }
        return
    }

    val total = ls.urls.size
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            (if (ls.title.isNotBlank()) ls.title + " — " else "") +
                l.t("$total فيديو", "$total videos"),
            color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Bold
        )
        Text(
            l.t("اختار تحمّل كام فيديو (من الأول):", "Choose how many to download (from the top):"),
            color = c.muted, fontSize = 12.sp
        )
        val steps = listOf(10, 25, 50).filter { it < total }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            steps.forEach { n ->
                OutlineButton("$n", Modifier.weight(1f), enabled = ready) { onDownload(n) }
            }
            OutlineButton(
                l.t("الكل ($total)", "All ($total)"),
                Modifier.weight(1.4f),
                enabled = ready
            ) { onDownload(total) }
        }
        if (total >= LIST_MAX) {
            Text(
                l.t("بنجيب أول $LIST_MAX فيديو بس مرة واحدة.", "Only the first $LIST_MAX videos are fetched at once."),
                color = c.muted, fontSize = 11.sp
            )
        }
    }
}
