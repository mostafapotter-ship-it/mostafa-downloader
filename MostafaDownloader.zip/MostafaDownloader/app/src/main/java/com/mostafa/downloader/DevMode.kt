package com.mostafa.downloader

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput

/** وضع المطوّر المخفي: ضغطة مطوّلة (أو 5 ضغطات سريعة) على رقم الإصدار */
object DevMode {
    val on = mutableStateOf(false)
    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        on.value = ctx.getSharedPreferences("dev", Context.MODE_PRIVATE).getBoolean("on", false)
    }

    fun toggle(ctx: Context, ar: Boolean) {
        on.value = !on.value
        ctx.getSharedPreferences("dev", Context.MODE_PRIVATE).edit().putBoolean("on", on.value).apply()
        Toast.makeText(
            ctx,
            if (on.value) (if (ar) "وضع المطوّر: مفعّل" else "Developer mode: on")
            else (if (ar) "وضع المطوّر: متوقف" else "Developer mode: off"),
            Toast.LENGTH_SHORT
        ).show()
    }
}

fun Modifier.devGesture(ctx: Context, ar: Boolean): Modifier = this.pointerInput(Unit) {
    var taps = 0
    var last = 0L
    detectTapGestures(
        onLongPress = { DevMode.toggle(ctx, ar) },
        onTap = {
            val now = System.currentTimeMillis()
            taps = if (now - last < 900) taps + 1 else 1
            last = now
            if (taps >= 5) {
                taps = 0
                DevMode.toggle(ctx, ar)
            }
        }
    )
}
