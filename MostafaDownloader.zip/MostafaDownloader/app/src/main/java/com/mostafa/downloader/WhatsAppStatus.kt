package com.mostafa.downloader

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import java.io.File

data class StatusItem(
    val uri: String,
    val name: String,
    val mime: String,
    val size: Long,
    val modified: Long
) {
    val isVideo: Boolean get() = mime.startsWith("video/")
}

/** المجلد المقترح عند فتح منتقي المجلدات (variant: 0 = WhatsApp, 1 = Business) */
fun waHintUri(variant: Int): Uri {
    val pkg = if (variant == 0) "com.whatsapp" else "com.whatsapp.w4b"
    val folder = if (variant == 0) "WhatsApp" else "WhatsApp Business"
    val path = if (Build.VERSION.SDK_INT >= 30) "Android/media/$pkg/$folder/Media/.Statuses"
    else "$folder/Media/.Statuses"
    return DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:$path")
}

private val IMG_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic")
private val VID_EXT = setOf("mp4", "3gp", "mkv", "webm", "mov", "m4v")

private fun statusMime(mime: String?, name: String): String? {
    val m = mime ?: ""
    if (m.startsWith("image/") || m.startsWith("video/")) return m
    // بعض الأجهزة بترجّع نوع عام للملف، فنعتمد على الامتداد
    return when (name.substringAfterLast('.', "").lowercase()) {
        in IMG_EXT -> "image/jpeg"
        in VID_EXT -> "video/mp4"
        else -> null
    }
}

/** بيقرأ مجلد الحالات بطلب واحد للمزوّد (أسرع بكتير من DocumentFile.listFiles مع الحالات الكتير) */
fun listStatuses(ctx: Context, treeUri: String): List<StatusItem> {
    val tree = Uri.parse(treeUri)
    val rootId = DocumentsContract.getTreeDocumentId(tree)
    val cols = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED
    )
    fun children(parentId: String): List<StatusItem> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val out = ArrayList<StatusItem>()
        ctx.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: ""
                val rawMime = c.getString(2)
                if (rawMime == DocumentsContract.Document.MIME_TYPE_DIR) continue
                if (name.startsWith(".nomedia")) continue
                val mime = statusMime(rawMime, name) ?: continue
                out.add(
                    StatusItem(
                        DocumentsContract.buildDocumentUriUsingTree(tree, id).toString(),
                        name, mime, c.getLong(3), c.getLong(4)
                    )
                )
            }
        } ?: throw IllegalStateException("Cannot read folder")
        return out
    }

    // لو المستخدم اختار مجلد أعلى (مثلاً Media) بندوّر على .Statuses جواه
    val isStatuses = rootId.substringAfterLast('/').trimEnd('/') == ".Statuses"
    var targetId = rootId
    if (!isStatuses) {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId)
        ctx.contentResolver.query(
            childrenUri,
            arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) == ".Statuses") { targetId = c.getString(0); break }
            }
        }
    }
    return children(targetId).sortedByDescending { it.modified }
}

fun loadThumb(ctx: Context, uri: Uri, mime: String): Bitmap? = try {
    if (mime.startsWith("image/")) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 480) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    } else {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            r.getFrameAtTime(0)
        } finally {
            r.release()
        }
    }
} catch (e: Exception) {
    null
}

/** يحفظ الحالة في المعرض (Pictures أو Movies / MostafaDownloader) */
fun saveStatusToGallery(ctx: Context, item: StatusItem): Boolean {
    val src = Uri.parse(item.uri)
    val isVideo = item.isVideo
    val baseDir = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
    val fileName = "WA_" + item.name
    val input = ctx.contentResolver.openInputStream(src) ?: return false
    input.use { inp ->
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, item.mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$baseDir/MostafaDownloader")
            }
            val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val dest = ctx.contentResolver.insert(collection, values) ?: return false
            val out = ctx.contentResolver.openOutputStream(dest) ?: return false
            out.use { inp.copyTo(it) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(baseDir), "MostafaDownloader")
            dir.mkdirs()
            val dest = File(dir, fileName)
            dest.outputStream().use { inp.copyTo(it) }
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(item.mime), null)
        }
    }
    return true
}
