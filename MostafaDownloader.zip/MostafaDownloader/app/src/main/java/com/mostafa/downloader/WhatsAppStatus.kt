package com.mostafa.downloader

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import java.io.File

data class StatusItem(
    val uri: String,
    val name: String,
    val mime: String,
    val size: Long,
    val modified: Long
) {
    val isVideo: Boolean get() = mime.startsWith("video/")
}

/** المجلد المقترح عند فتح منتقي المجلدات (variant: 0 = WhatsApp, 1 = Business) */
fun waHintUri(variant: Int): Uri {
    val pkg = if (variant == 0) "com.whatsapp" else "com.whatsapp.w4b"
    val folder = if (variant == 0) "WhatsApp" else "WhatsApp Business"
    val path = if (Build.VERSION.SDK_INT >= 30) "Android/media/$pkg/$folder/Media/.Statuses"
    else "$folder/Media/.Statuses"
    return DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:$path")
}

fun listStatuses(ctx: Context, treeUri: String): List<StatusItem> {
    val root = DocumentFile.fromTreeUri(ctx, Uri.parse(treeUri)) ?: return emptyList()
    val dir = if (root.name == ".Statuses") root else (root.findFile(".Statuses") ?: root)
    return dir.listFiles().mapNotNull { f ->
        val t = f.type ?: return@mapNotNull null
        if (f.isFile && (t.startsWith("image/") || t.startsWith("video/"))) {
            StatusItem(f.uri.toString(), f.name ?: "", t, f.length(), f.lastModified())
        } else null
    }.sortedByDescending { it.modified }
}

fun loadThumb(ctx: Context, uri: Uri, mime: String): Bitmap? = try {
    if (mime.startsWith("image/")) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 480) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    } else {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            r.getFrameAtTime(0)
        } finally {
            r.release()
        }
    }
} catch (e: Exception) {
    null
}

/** يحفظ الحالة في المعرض (Pictures أو Movies / MostafaDownloader) */
fun saveStatusToGallery(ctx: Context, item: StatusItem): Boolean {
    val src = Uri.parse(item.uri)
    val isVideo = item.isVideo
    val baseDir = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
    val fileName = "WA_" + item.name
    val input = ctx.contentResolver.openInputStream(src) ?: return false
    input.use { inp ->
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, item.mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$baseDir/MostafaDownloader")
            }
            val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val dest = ctx.contentResolver.insert(collection, values) ?: return false
            val out = ctx.contentResolver.openOutputStream(dest) ?: return false
            out.use { inp.copyTo(it) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(baseDir), "MostafaDownloader")
            dir.mkdirs()
            val dest = File(dir, fileName)
            dest.outputStream().use { inp.copyTo(it) }
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(item.mime), null)
        }
    }
    return true
}
