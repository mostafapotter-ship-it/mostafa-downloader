package com.mostafa.downloader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * محاولة احتياطية لتحميل محتوى سناب شات العام (الاستوريهات العامة / سبوتلايت)
 * لما المحرك الأساسي ما يدعمش الرابط. مفيش تسجيل دخول مطلوب.
 */
object SnapStory {
    private const val UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun hostOf(u: String): String =
        Regex("^https://([^/]+)").find(u)?.groupValues?.get(1) ?: u.take(24)

    private fun unescape(s: String): String {
        val r = Regex("\\\\u([0-9a-fA-F]{4})").replace(s) { it.groupValues[1].toInt(16).toChar().toString() }
        return r.replace("\\/", "/").replace("&amp;", "&")
    }

    private fun candidates(urls: List<String>): List<String> {
        val out = LinkedHashSet<String>()
        for (u in urls) {
            out.add(u)
            val user = Regex("snapchat\\.com/(?:add|s)/([A-Za-z0-9._-]+)").find(u)?.groupValues?.get(1)
                ?: Regex("snapchat\\.com/@([A-Za-z0-9._-]+)").find(u)?.groupValues?.get(1)
            if (user != null) {
                out.add("https://story.snapchat.com/@$user")
                out.add("https://www.snapchat.com/add/$user")
            }
        }
        return out.toList()
    }

    private fun open(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("User-Agent", UA)
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        return conn
    }

    private fun load(url: String): String {
        val conn = open(url)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return conn.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
        } finally {
            conn.disconnect()
        }
    }

    private fun walk(node: Any?, out: MutableList<Pair<String, String>>) {
        when (node) {
            is JSONObject -> {
                val snap = node.optJSONObject("snapUrls")
                val media = snap?.optString("mediaUrl").orEmpty()
                if (media.startsWith("http")) {
                    val t = node.opt("snapMediaType")?.toString() ?: ""
                    val video = t == "1" || t.contains("VIDEO", true) || media.contains(".mp4")
                    out.add(media to (if (video) "mp4" else "jpg"))
                }
                val content = node.optString("contentUrl")
                if (content.startsWith("http")) out.add(content to "mp4")
                val keys = node.keys()
                while (keys.hasNext()) walk(node.opt(keys.next()), out)
            }
            is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i), out)
        }
    }

    private fun mediaFrom(html: String): List<Pair<String, String>> {
        val items = ArrayList<Pair<String, String>>()
        val m = Regex("<script id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>", RegexOption.DOT_MATCHES_ALL).find(html)
        if (m != null) {
            try {
                walk(JSONObject(m.groupValues[1]), items)
            } catch (e: Exception) {
            }
        }
        if (items.isEmpty()) {
            Regex("\"contentUrl\"\\s*:\\s*\"([^\"]+)\"").findAll(html)
                .forEach { items.add(unescape(it.groupValues[1]) to "mp4") }
        }
        if (items.isEmpty()) {
            Regex("property=\"og:video(?::url)?\"\\s+content=\"([^\"]+)\"").find(html)
                ?.let { items.add(unescape(it.groupValues[1]) to "mp4") }
        }
        return items.distinctBy { it.first }
    }

    private fun fetchFile(u: String, dest: File) {
        val conn = open(u)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("media HTTP $code")
            conn.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
    }

    fun download(ctx: Context, urls: List<String>, dir: File) {
        val notes = ArrayList<String>()
        for (u in candidates(urls)) {
            try {
                val html = load(u)
                val items = mediaFrom(html)
                if (items.isEmpty()) {
                    notes.add("${hostOf(u)}: no media (page=${html.length})")
                    continue
                }
                items.take(20).forEachIndexed { i, (m, ext) ->
                    fetchFile(m, File(dir, "snapchat_${i + 1}.$ext"))
                }
                return
            } catch (e: Exception) {
                notes.add("${hostOf(u)}: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        throw IllegalStateException("ERROR: Snapchat failed. " + notes.joinToString(" | "))
    }
}
