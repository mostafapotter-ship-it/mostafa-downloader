package com.mostafa.downloader

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PStat(val count: Int, val bytes: Long)

data class StatsData(val per: Map<String, PStat> = emptyMap(), val since: String = "") {
    val totalCount: Int get() = per.values.sumOf { it.count }
    val totalBytes: Long get() = per.values.sumOf { it.bytes }
}

/** إحصائيات تراكمية (مش مرتبطة بحد الـ 100 عنصر في السجل) */
class StatsStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("stats", Context.MODE_PRIVATE)

    fun load(): StatsData = try {
        val o = JSONObject(prefs.getString("data", "{}") ?: "{}")
        val p = o.optJSONObject("p") ?: JSONObject()
        val m = LinkedHashMap<String, PStat>()
        p.keys().forEach { k ->
            val e = p.getJSONObject(k)
            m[k] = PStat(e.optInt("c"), e.optLong("b"))
        }
        StatsData(m, o.optString("since", ""))
    } catch (e: Exception) {
        StatsData()
    }

    private fun write(d: StatsData) {
        val p = JSONObject()
        d.per.forEach { (k, v) -> p.put(k, JSONObject().put("c", v.count).put("b", v.bytes)) }
        prefs.edit().putString("data", JSONObject().put("since", d.since).put("p", p).toString()).apply()
    }

    @Synchronized
    fun record(platform: String, bytes: Long): StatsData {
        val cur = load()
        val old = cur.per[platform] ?: PStat(0, 0)
        val since = cur.since.ifEmpty { SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date()) }
        val d = StatsData(cur.per + (platform to PStat(old.count + 1, old.bytes + bytes)), since)
        write(d)
        return d
    }

    @Synchronized
    fun reset(): StatsData {
        prefs.edit().remove("data").apply()
        return StatsData()
    }
}

fun fmtSize(b: Long): String = when {
    b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    b >= 1L shl 10 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}

@Composable
fun StatsCard(data: StatsData, onReset: () -> Unit) {
    val c = LocalColors.current
    val l = LocalLang.current
    AppCard {
        SectionLabel(l.t("إحصائياتك 📊", "Your stats 📊"))
        if (data.totalCount == 0) {
            Text(
                l.t(
                    "لسه مفيش تحميلات. أول ما تحمّل حاجة هتظهر هنا الأعداد والأحجام لكل منصة.",
                    "No downloads yet. Counts and sizes per platform will show up here."
                ),
                color = c.muted, fontSize = 13.sp
            )
            return@AppCard
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigNumber(Modifier.weight(1f), data.totalCount.toString(), l.t("تحميل", "Downloads"))
            BigNumber(Modifier.weight(1f), fmtSize(data.totalBytes), l.t("الحجم الكلي", "Total size"))
        }
        val maxCount = data.per.values.maxOf { it.count }.coerceAtLeast(1)
        data.per.entries.sortedByDescending { it.value.bytes }.forEach { (id, st) ->
            val plat = Platforms.firstOrNull { it.id == id }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (plat != null) PlatformIcon(plat, 30.dp) else Text("🌐", fontSize = 24.sp, modifier = Modifier.width(30.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            plat?.name ?: l.t("أخرى", "Other"),
                            color = c.text, fontWeight = FontWeight.Medium, fontSize = 14.sp
                        )
                        Text("${st.count} • ${fmtSize(st.bytes)}", color = c.muted, fontSize = 12.sp)
                    }
                    Box(
                        Modifier.fillMaxWidth().height(6.dp)
                            .clip(RoundedCornerShape(50)).background(c.bg)
                    ) {
                        Box(
                            Modifier.fillMaxWidth(st.count / maxCount.toFloat()).height(6.dp)
                                .clip(RoundedCornerShape(50)).background(BrandBrush)
                        )
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (data.since.isNotEmpty()) l.t("من ${data.since}", "Since ${data.since}") else "",
                color = c.muted, fontSize = 11.sp
            )
            Text(
                l.t("تصفير", "Reset"), color = ErrorC, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onReset).padding(6.dp)
            )
        }
    }
}

@Composable
private fun BigNumber(modifier: Modifier, value: String, label: String) {
    val c = LocalColors.current
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(c.bg).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(value, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = c.muted, fontSize = 12.sp)
    }
}
