package com.mostafa.downloader

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import java.io.File

/** يحفظ جلسة الدخول (كوكيز) بصيغة Netscape ليستخدمها yt-dlp مع الاستوريهات. الملفات خاصة بالتطبيق فقط. */
object CookieStore {
    private data class Site(val urls: List<String>, val domain: String, val required: List<String>)

    private val sites = mapOf(
        "ig" to Site(
            listOf("https://www.instagram.com", "https://instagram.com"),
            ".instagram.com", listOf("sessionid")
        ),
        "fb" to Site(
            listOf("https://www.facebook.com", "https://m.facebook.com"),
            ".facebook.com", listOf("c_user", "xs")
        )
    )

    var lastCount: Int = 0

    fun file(ctx: Context, site: String): File = File(ctx.filesDir, "cookies_$site.txt")

    fun isLoggedIn(ctx: Context, site: String?): Boolean {
        if (site == null) return false
        val f = file(ctx, site)
        return f.exists() && f.length() > 0
    }

    fun siteOfUrl(url: String): String? {
        val u = url.lowercase()
        return when {
            "instagram.com" in u -> "ig"
            "facebook.com" in u || "fb.watch" in u || "fb.com" in u -> "fb"
            else -> null
        }
    }

    private fun writeCookies(ctx: Context, site: String, s: Site, map: Map<String, String>): Boolean {
        if (!s.required.all { map.containsKey(it) }) return false
        val expiry = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for ((k, v) in map) {
            sb.append(s.domain).append('\t').append("TRUE").append('\t').append('/').append('\t')
                .append("TRUE").append('\t').append(expiry).append('\t')
                .append(k).append('\t').append(v).append('\n')
        }
        file(ctx, site).writeText(sb.toString())
        return true
    }

    fun saveFromWebView(ctx: Context, site: String): Boolean {
        val s = sites[site] ?: return false
        val cm = CookieManager.getInstance()
        cm.flush()
        val map = LinkedHashMap<String, String>()
        for (u in s.urls) {
            val raw = cm.getCookie(u) ?: continue
            for (part in raw.split(";")) {
                val i = part.indexOf('=')
                if (i <= 0) continue
                map[part.substring(0, i).trim()] = part.substring(i + 1).trim()
            }
        }
        lastCount = map.size
        return writeCookies(ctx, site, s, map)
    }

    /** يقبل نص cookies.txt (Netscape) أو سطر Cookie بصيغة a=b; c=d */
    fun saveFromText(ctx: Context, site: String, text: String): Boolean {
        val s = sites[site] ?: return false
        val t = text.trim()
        if (t.isEmpty()) return false
        val lines = t.lines()
        if (lines.any { it.split('\t').size >= 7 }) {
            val names = lines
                .filter { !it.startsWith("#") || it.startsWith("#HttpOnly_") }
                .mapNotNull { it.split('\t').getOrNull(5) }
                .toSet()
            if (!s.required.all { it in names }) return false
            val body = if (t.startsWith("# Netscape")) t else "# Netscape HTTP Cookie File\n$t"
            file(ctx, site).writeText(body + "\n")
            return true
        }
        val map = LinkedHashMap<String, String>()
        for (part in t.replace("\n", ";").split(";")) {
            val i = part.indexOf('=')
            if (i <= 0) continue
            map[part.substring(0, i).trim()] = part.substring(i + 1).trim()
        }
        return writeCookies(ctx, site, s, map)
    }

    fun logout(ctx: Context, site: String) {
        file(ctx, site).delete()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }
}
