package com.mostafa.downloader

import org.json.JSONObject
import java.io.File
import java.util.Locale

/** جودة واحدة متاحة في الفيديو (أفضل صيغة لكل ارتفاع) */
data class PFormat(
    val id: String,
    val height: Int,
    val ext: String,
    val fps: Int,
    val size: Long,        // بالبايت (شامل الصوت لو الفيديو منفصل)، 0 = مجهول
    val approx: Boolean,   // الحجم تقديري
    val muxed: Boolean     // فيه صوت جوه نفس الملف
)

data class SubLang(val code: String, val auto: Boolean)

data class PreviewInfo(
    val url: String,
    val title: String,
    val uploader: String,
    val duration: Long,    // بالثواني، 0 = مجهول
    val thumbnail: String,
    val formats: List<PFormat>,
    val subs: List<SubLang>
)

data class PreviewState(
    val loading: Boolean = false,
    val url: String = "",
    val data: PreviewInfo? = null,
    val error: Msg? = null
)

object PreviewParser {
    private val COMMON_AUTO = setOf(
        "ar", "en", "fr", "es", "de", "tr", "ru", "hi", "ur", "id", "pt", "it", "ja", "ko",
        "zh-Hans", "zh-Hant", "fa", "bn", "nl", "pl"
    )

    // org.json على أندرويد بيرجّع "null" كنص لو القيمة null، فبنتعامل معاها بإيدينا
    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")
    private fun num(o: JSONObject, k: String): Double = if (o.isNull(k)) 0.0 else o.optDouble(k, 0.0).let { if (it.isNaN()) 0.0 else it }

    fun parse(raw: String, url: String): PreviewInfo {
        var root = JSONObject(raw.trim())
        root.optJSONArray("entries")?.let { arr ->
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i)
                if (e != null) { root = e; break }
            }
        }
        val duration = num(root, "duration").toLong()
        val title = str(root, "title").ifEmpty { str(root, "fulltitle") }
        val uploader = str(root, "uploader").ifEmpty { str(root, "channel") }
        var thumb = str(root, "thumbnail")
        if (thumb.isEmpty()) {
            root.optJSONArray("thumbnails")?.let { ta ->
                for (i in ta.length() - 1 downTo 0) {
                    val t = ta.optJSONObject(i) ?: continue
                    val u = str(t, "url")
                    if (u.startsWith("http")) { thumb = u; break }
                }
            }
        }

        // --- الصيغ ---
        class Raw(val o: JSONObject, val height: Int, val tbr: Double, val ext: String, val vc: String, val muxed: Boolean)

        val videos = ArrayList<Raw>()
        var bestAudio: JSONObject? = null
        var bestAudioTbr = -1.0
        val fa = root.optJSONArray("formats")
        if (fa != null) {
            for (i in 0 until fa.length()) {
                val f = fa.optJSONObject(i) ?: continue
                val ext = str(f, "ext")
                val note = str(f, "format_note")
                if (ext == "mhtml" || note.contains("storyboard", true)) continue
                val vc = str(f, "vcodec")
                val ac = str(f, "acodec")
                val h = if (f.isNull("height")) 0 else f.optInt("height", 0)
                val tbr = num(f, "tbr")
                val isAudioOnly = vc == "none" && ac.isNotEmpty() && ac != "none"
                val isVideoOnly = vc.isNotEmpty() && vc != "none" && ac == "none"
                when {
                    isAudioOnly -> if (tbr > bestAudioTbr) { bestAudio = f; bestAudioTbr = tbr }
                    h > 0 -> videos.add(Raw(f, h, tbr, ext, vc, muxed = !isVideoOnly))
                }
            }
        }

        fun sizeOf(o: JSONObject): Pair<Long, Boolean> {
            val exact = num(o, "filesize").toLong()
            if (exact > 0) return exact to false
            val approx = num(o, "filesize_approx").toLong()
            if (approx > 0) return approx to true
            val tbr = num(o, "tbr")
            if (tbr > 0 && duration > 0) return (tbr * duration * 125).toLong() to true
            return 0L to true
        }

        val audioSize = bestAudio?.let { sizeOf(it).first } ?: 0L

        val byHeight = videos.groupBy { it.height }
        val formats = byHeight.map { (h, list) ->
            // نفضّل mp4/avc (متوافق مع كل الأجهزة) وبعدين أعلى معدل بيانات
            val best = list.maxWith(
                compareBy<Raw>({ if (it.ext == "mp4") 1 else 0 }, { if (it.vc.startsWith("avc")) 1 else 0 }, { it.tbr })
            )
            val (sz, approx) = sizeOf(best.o)
            val total = if (sz > 0) sz + (if (best.muxed) 0L else audioSize) else 0L
            PFormat(
                id = str(best.o, "format_id"),
                height = h,
                ext = best.ext,
                fps = if (best.o.isNull("fps")) 0 else best.o.optDouble("fps", 0.0).toInt(),
                size = total,
                approx = approx || (!best.muxed && audioSize == 0L),
                muxed = best.muxed
            )
        }.filter { it.id.isNotEmpty() }
            .sortedByDescending { it.height }
            .take(12)

        // --- الترجمات ---
        val subs = ArrayList<SubLang>()
        val manual = HashSet<String>()
        root.optJSONObject("subtitles")?.let { so ->
            so.keys().asSequence().filter { it != "live_chat" }.sorted().forEach {
                manual.add(it); subs.add(SubLang(it, false))
            }
        }
        root.optJSONObject("automatic_captions")?.let { ao ->
            ao.keys().asSequence().sorted().forEach { code ->
                if (code in manual) return@forEach
                if (code.endsWith("-orig") || code in COMMON_AUTO) subs.add(SubLang(code, true))
            }
        }
        val prio = listOf("ar", "en")
        val sortedSubs = subs.sortedWith(
            compareBy<SubLang>({ it.auto }, { prio.indexOf(it.code.removeSuffix("-orig")).let { i -> if (i < 0) 99 else i } }, { it.code })
        )

        return PreviewInfo(url, title, uploader, duration, thumb, formats, sortedSubs)
    }
}

/** تحويل أوقات القص: "90" / "1:30" / "01:02:03" / "1:30.5" */
object ClipTime {
    fun parse(s: String): Double? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val parts = t.split(':')
        if (parts.size > 3) return null
        var total = 0.0
        for (p in parts) {
            val v = p.trim().toDoubleOrNull() ?: return null
            if (v < 0 || v.isNaN() || v.isInfinite()) return null
            total = total * 60 + v
        }
        return total
    }

    /** صيغة yt-dlp: HH:MM:SS أو HH:MM:SS.mmm */
    fun fmt(sec: Double): String {
        val h = (sec / 3600).toInt()
        val m = ((sec % 3600) / 60).toInt()
        val s = sec % 60
        return if (s == Math.floor(s)) String.format(Locale.US, "%02d:%02d:%02d", h, m, s.toInt())
        else String.format(Locale.US, "%02d:%02d:%06.3f", h, m, s)
    }

    /** صيغة العرض للمستخدم: m:ss أو h:mm:ss */
    fun fmtShort(sec: Double): String {
        val total = Math.round(sec).toInt()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }
}

/** قص ملف SRT بنفس مدى الفيديو المقصوص وإزاحة التوقيتات */
object SrtTool {
    private val timeRe = Regex("(\\d{1,2}):(\\d{2}):(\\d{2})[,.](\\d{1,3})\\s*-->\\s*(\\d{1,2}):(\\d{2}):(\\d{2})[,.](\\d{1,3})(.*)")

    private fun toSec(h: String, m: String, s: String, ms: String): Double =
        h.toInt() * 3600 + m.toInt() * 60 + s.toInt() + ms.padEnd(3, '0').toInt() / 1000.0

    private fun fmt(sec: Double): String {
        val t = Math.round(sec * 1000).coerceAtLeast(0)
        val ms = (t % 1000).toInt()
        val s = ((t / 1000) % 60).toInt()
        val m = ((t / 60000) % 60).toInt()
        val h = (t / 3600000).toInt()
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, ms)
    }

    fun clip(file: File, start: Double, end: Double?) {
        val text = file.readText(Charsets.UTF_8).replace("\r\n", "\n")
        val out = StringBuilder()
        var idx = 1
        for (block in text.split(Regex("\n{2,}"))) {
            val lines = block.trim().split("\n")
            val ti = lines.indexOfFirst { timeRe.containsMatchIn(it) }
            if (ti < 0) continue
            val m = timeRe.find(lines[ti])!!.groupValues
            val a = toSec(m[1], m[2], m[3], m[4])
            val b = toSec(m[5], m[6], m[7], m[8])
            if (b <= start || (end != null && a >= end)) continue
            val na = (a - start).coerceAtLeast(0.0)
            val nb = (minOf(b, end ?: b) - start)
            if (nb <= na) continue
            val body = lines.drop(ti + 1).joinToString("\n")
            if (body.isBlank()) continue
            out.append(idx++).append('\n')
                .append(fmt(na)).append(" --> ").append(fmt(nb)).append('\n')
                .append(body).append("\n\n")
        }
        file.writeText(out.toString(), Charsets.UTF_8)
    }
}
