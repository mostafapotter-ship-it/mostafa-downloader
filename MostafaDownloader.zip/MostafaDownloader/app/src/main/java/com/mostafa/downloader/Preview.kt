package com.mostafa.downloader

import org.json.JSONObject
import java.io.File
import java.util.Locale

/** جودة واحدة متاحة في الفيديو (أفضل صيغة لكل ارتفاع) */
data class PFormat(
    val id: String,
    val height: Int,
    val ext: String,
    val fps: Int,
    val size: Long,        // بالبايت (شامل الصوت لو الفيديو منفصل)، 0 = مجهول
    val approx: Boolean,   // الحجم تقديري
    val muxed: Boolean     // فيه صوت جوه نفس الملف
)

data class PreviewInfo(
    val url: String,
    val title: String,
    val uploader: String,
    val duration: Long,    // بالثواني، 0 = مجهول
    val thumbnail: String,
    val formats: List<PFormat>
)

data class PreviewState(
    val loading: Boolean = false,
    val url: String = "",
    val data: PreviewInfo? = null,
    val error: Msg? = null
)

object PreviewParser {
    // org.json على أندرويد بيرجّع "null" كنص لو القيمة null، فبنتعامل معاها بإيدينا
    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")
    private fun num(o: JSONObject, k: String): Double = if (o.isNull(k)) 0.0 else o.optDouble(k, 0.0).let { if (it.isNaN()) 0.0 else it }

    fun parse(raw: String, url: String): PreviewInfo {
        var root = JSONObject(raw.trim())
        root.optJSONArray("entries")?.let { arr ->
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i)
                if (e != null) { root = e; break }
            }
        }
        val duration = num(root, "duration").toLong()
        val title = str(root, "title").ifEmpty { str(root, "fulltitle") }
        val uploader = str(root, "uploader").ifEmpty { str(root, "channel") }
        var thumb = str(root, "thumbnail")
        if (thumb.isEmpty()) {
            root.optJSONArray("thumbnails")?.let { ta ->
                for (i in ta.length() - 1 downTo 0) {
                    val t = ta.optJSONObject(i) ?: continue
                    val u = str(t, "url")
                    if (u.startsWith("http")) { thumb = u; break }
                }
            }
        }

        // --- الصيغ ---
        class Raw(val o: JSONObject, val height: Int, val tbr: Double, val ext: String, val vc: String, val muxed: Boolean)

        val videos = ArrayList<Raw>()
        var bestAudio: JSONObject? = null
        var bestAudioTbr = -1.0
        val fa = root.optJSONArray("formats")
        if (fa != null) {
            for (i in 0 until fa.length()) {
                val f = fa.optJSONObject(i) ?: continue
                val ext = str(f, "ext")
                val note = str(f, "format_note")
                if (ext == "mhtml" || note.contains("storyboard", true)) continue
                val vc = str(f, "vcodec")
                val ac = str(f, "acodec")
                val h = if (f.isNull("height")) 0 else f.optInt("height", 0)
                val tbr = num(f, "tbr")
                val isAudioOnly = vc == "none" && ac.isNotEmpty() && ac != "none"
                val isVideoOnly = vc.isNotEmpty() && vc != "none" && ac == "none"
                when {
                    isAudioOnly -> if (tbr > bestAudioTbr) { bestAudio = f; bestAudioTbr = tbr }
                    h > 0 -> videos.add(Raw(f, h, tbr, ext, vc, muxed = !isVideoOnly))
                }
            }
        }

        fun sizeOf(o: JSONObject): Pair<Long, Boolean> {
            val exact = num(o, "filesize").toLong()
            if (exact > 0) return exact to false
            val approx = num(o, "filesize_approx").toLong()
            if (approx > 0) return approx to true
            val tbr = num(o, "tbr")
            if (tbr > 0 && duration > 0) return (tbr * duration * 125).toLong() to true
            return 0L to true
        }

        val audioSize = bestAudio?.let { sizeOf(it).first } ?: 0L

        val byHeight = videos.groupBy { it.height }
        val formats = byHeight.map { (h, list) ->
            // نفضّل mp4/avc (متوافق مع كل الأجهزة) وبعدين أعلى معدل بيانات
            val best = list.maxWith(
                compareBy<Raw>({ if (it.ext == "mp4") 1 else 0 }, { if (it.vc.startsWith("avc")) 1 else 0 }, { it.tbr })
            )
            val (sz, approx) = sizeOf(best.o)
            val total = if (sz > 0) sz + (if (best.muxed) 0L else audioSize) else 0L
            PFormat(
                id = str(best.o, "format_id"),
                height = h,
                ext = best.ext,
                fps = if (best.o.isNull("fps")) 0 else best.o.optDouble("fps", 0.0).toInt(),
                size = total,
                approx = approx || (!best.muxed && audioSize == 0L),
                muxed = best.muxed
            )
        }.filter { it.id.isNotEmpty() }
            .sortedByDescending { it.height }
            .take(12)

        return PreviewInfo(url, title, uploader, duration, thumb, formats)
    }
}

/** تحويل أوقات القص: "90" / "1:30" / "01:02:03" / "1:30.5" */
object ClipTime {
    fun parse(s: String): Double? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val parts = t.split(':')
        if (parts.size > 3) return null
        var total = 0.0
        for (p in parts) {
            val v = p.trim().toDoubleOrNull() ?: return null
            if (v < 0 || v.isNaN() || v.isInfinite()) return null
            total = total * 60 + v
        }
        return total
    }

    /** صيغة yt-dlp: HH:MM:SS أو HH:MM:SS.mmm */
    fun fmt(sec: Double): String {
        val h = (sec / 3600).toInt()
        val m = ((sec % 3600) / 60).toInt()
        val s = sec % 60
        return if (s == Math.floor(s)) String.format(Locale.US, "%02d:%02d:%02d", h, m, s.toInt())
        else String.format(Locale.US, "%02d:%02d:%06.3f", h, m, s)
    }

    /** صيغة العرض للمستخدم: m:ss أو h:mm:ss */
    fun fmtShort(sec: Double): String {
        val total = Math.round(sec).toInt()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }
}
