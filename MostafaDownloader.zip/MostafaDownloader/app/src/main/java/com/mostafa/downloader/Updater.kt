package com.mostafa.downloader

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

object Updater {
    const val OWNER = "mostafapotter-ship-it"
    const val REPO = "mostafa-downloader"

    data class Asset(val name: String, val url: String, val size: Long)

    data class Release(val versionCode: Int, val name: String, val notes: String, val assets: List<Asset>) {
        fun full(abi: String): Asset? =
            assets.firstOrNull { it.name == "MostafaDownloader-$abi.apk" }
                ?: assets.firstOrNull { it.name.endsWith(".apk") }

        fun patch(fromCode: Int, abi: String): Asset? =
            assets.firstOrNull { it.name == "patch-from-$fromCode-$abi.bin" }

        fun sha(abi: String): Asset? =
            assets.firstOrNull { it.name == "MostafaDownloader-$abi.apk.sha256" }
    }

    fun deviceAbi(): String =
        Build.SUPPORTED_ABIS.firstOrNull { it == "arm64-v8a" || it == "armeabi-v7a" } ?: "arm64-v8a"

    /** يجلب آخر إصدار منشور على GitHub (blocking - استدعيه من خيط خلفي) */
    fun fetchLatest(): Release? {
        val conn = URL("https://api.github.com/repos/$OWNER/$REPO/releases/latest")
            .openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "MostafaDownloader")
            if (conn.responseCode != 200) return null
            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            val tag = json.getString("tag_name")
            val code = tag.trimStart('v', 'V').toIntOrNull() ?: return null
            val arr = json.getJSONArray("assets")
            val assets = ArrayList<Asset>()
            for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i)
                assets.add(Asset(a.getString("name"), a.getString("browser_download_url"), a.optLong("size", 0L)))
            }
            if (assets.none { it.name.endsWith(".apk") }) return null
            val notes = json.optString("body", "").takeIf { it != "null" } ?: ""
            return Release(code, json.optString("name", tag), notes, assets)
        } finally {
            conn.disconnect()
        }
    }

    /** تحميل متوازي (4 اتصالات) وبيرجع للتحميل العادي لو السيرفر مش بيدعمه أو حصل خطأ. */
    private fun downloadTo(url: String, dest: File, onProgress: (Float) -> Unit) {
        try {
            if (downloadParallel(url, dest, onProgress)) return
        } catch (e: Throwable) {
            // نكمل بالتحميل العادي
        }
        dest.delete()
        downloadSingle(url, dest, onProgress)
    }

    private fun downloadParallel(url: String, dest: File, onProgress: (Float) -> Unit): Boolean {
        val total: Long
        val finalUrl: String
        val probe = URL(url).openConnection() as HttpURLConnection
        try {
            probe.connectTimeout = 20000
            probe.readTimeout = 30000
            probe.setRequestProperty("User-Agent", "MostafaDownloader")
            probe.setRequestProperty("Range", "bytes=0-0")
            if (probe.responseCode != 206) return false
            val cr = probe.getHeaderField("Content-Range") ?: return false
            total = cr.substringAfter('/').trim().toLongOrNull() ?: return false
            finalUrl = probe.url.toString() // الرابط النهائي بعد التحويلات (CDN مباشر)
        } finally {
            probe.disconnect()
        }
        if (total < 2_000_000L) return false

        val parts = 4
        val chunk = (total + parts - 1) / parts
        RandomAccessFile(dest, "rw").use { it.setLength(total) }
        val done = AtomicLong(0)
        val err = AtomicReference<Throwable?>(null)

        val threads = (0 until parts).map { i ->
            val start = i * chunk
            val end = minOf(total - 1, start + chunk - 1)
            Thread {
                try {
                    var pos = start
                    var attempts = 0
                    while (pos <= end && err.get() == null) {
                        try {
                            val c = URL(finalUrl).openConnection() as HttpURLConnection
                            try {
                                c.connectTimeout = 20000
                                c.readTimeout = 30000
                                c.setRequestProperty("User-Agent", "MostafaDownloader")
                                c.setRequestProperty("Range", "bytes=$pos-$end")
                                if (c.responseCode != 206) throw IllegalStateException("HTTP ${c.responseCode}")
                                RandomAccessFile(dest, "rw").use { raf ->
                                    raf.seek(pos)
                                    c.inputStream.use { input ->
                                        val buf = ByteArray(128 * 1024)
                                        while (pos <= end) {
                                            val n = input.read(buf)
                                            if (n < 0) break
                                            val w = minOf(n.toLong(), end - pos + 1).toInt()
                                            raf.write(buf, 0, w)
                                            pos += w
                                            done.addAndGet(w.toLong())
                                        }
                                    }
                                }
                            } finally {
                                c.disconnect()
                            }
                            if (pos <= end) throw IllegalStateException("short read")
                        } catch (e: Throwable) {
                            attempts++
                            if (attempts >= 3) throw e
                            Thread.sleep(500)
                        }
                    }
                } catch (e: Throwable) {
                    err.compareAndSet(null, e)
                }
            }.also { it.start() }
        }

        while (threads.any { it.isAlive }) {
            onProgress((done.get().toFloat() / total).coerceIn(0f, 1f))
            Thread.sleep(200)
        }
        err.get()?.let { throw it }
        if (done.get() != total) throw IllegalStateException("incomplete download")
        onProgress(1f)
        return true
    }

    private fun downloadSingle(url: String, dest: File, onProgress: (Float) -> Unit) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", "MostafaDownloader")
            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                dest.outputStream().use { output ->
                    val buf = ByteArray(128 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress(done.toFloat() / total)
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchText(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.setRequestProperty("User-Agent", "MostafaDownloader")
            return conn.inputStream.bufferedReader().readText()
        } finally {
            conn.disconnect()
        }
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * يجهّز ملف التحديث: لو فيه باتش (تغييرات فقط) من النسخة الحالية يستخدمه،
     * ولو فشل لأي سبب يرجع للتحميل الكامل.
     */
    fun prepare(ctx: Context, r: Release, onProgress: (Float) -> Unit, onMode: (Boolean) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates").apply { deleteRecursively(); mkdirs() }
        val abi = deviceAbi()
        val out = File(dir, "update.apk")

        val patch = r.patch(BuildConfig.VERSION_CODE, abi)
        val sha = r.sha(abi)
        if (patch != null && sha != null) {
            try {
                onMode(true)
                val pf = File(dir, "update.patch")
                downloadTo(patch.url, pf, onProgress)
                val expected = fetchText(sha.url).trim().split(" ")[0].lowercase()
                BsPatch.apply(File(ctx.applicationInfo.sourceDir), pf, out)
                if (sha256(out) == expected) return out
            } catch (e: Throwable) {
                // نكمل بالتحميل الكامل
            }
            out.delete()
        }

        onMode(false)
        val full = r.full(abi) ?: throw IllegalStateException("No APK in the release")
        downloadTo(full.url, out, onProgress)
        return out
    }

    fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 26 || ctx.packageManager.canRequestPackageInstalls()

    fun openInstallSettings(ctx: Context) {
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    fun install(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}
