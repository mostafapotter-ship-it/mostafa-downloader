package com.mostafa.downloader

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.yausername.youtubedl_android.YoutubeDL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * تحديث محرك yt-dlp تلقائياً (المواقع بتغيّر نفسها كل كام أسبوع):
 *  1) عند فتح التطبيق لو عدّى 12 ساعة.
 *  2) في الخلفية كل 12 ساعة حتى لو التطبيق مقفول.
 *  3) لو تحميل فشل بسبب تغيّر في الموقع: يتحدّث المحرك ويعيد المحاولة تلقائياً.
 */
object EngineUpdater {
    private const val PREFS = "engine"
    private const val FRESH_MS = 12L * 3600L * 1000L
    private const val RETRY_GAP_MS = 20L * 60L * 1000L
    private val lock = Any()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun lastUpdate(ctx: Context): Long = prefs(ctx).getLong("last_update", 0L)

    fun isStale(ctx: Context): Boolean = System.currentTimeMillis() - lastUpdate(ctx) >= FRESH_MS

    /** بيحدّث المحرك فعلاً (blocking، لازم يتنادى من thread خلفي). بيرجع true لو نجح */
    fun update(ctx: Context): Boolean = synchronized(lock) {
        val p = prefs(ctx)
        p.edit().putLong("last_try", System.currentTimeMillis()).apply()
        try {
            YoutubeDL.getInstance().init(ctx)
            YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
            p.edit().putLong("last_update", System.currentTimeMillis()).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** يحدّث بس لو المحرك قديم (أكتر من 12 ساعة) */
    fun updateIfStale(ctx: Context): Boolean = if (isStale(ctx)) update(ctx) else true

    /** هل ينفع نعمل تحديث + إعادة محاولة دلوقتي؟ (مش أكتر من مرة كل 20 دقيقة) */
    fun canRetryNow(ctx: Context): Boolean =
        System.currentTimeMillis() - prefs(ctx).getLong("last_try", 0L) >= RETRY_GAP_MS

    /** أخطاء بتدل غالباً إن الموقع غيّر نفسه والمحرك محتاج تحديث */
    fun looksLikeSiteChange(msg: String): Boolean {
        val m = msg.lowercase(Locale.US)
        return listOf(
            "unable to extract", "nsig extraction failed", "sign in to confirm",
            "http error 403", "requested format is not available", "no video formats found",
            "failed to parse json", "did not get any data blocks", "unable to download json",
            "player response", "unable to find", "is no longer available in this app version"
        ).any { it in m }
    }

    fun lastInfo(ctx: Context, ar: Boolean): String {
        val t = lastUpdate(ctx)
        if (t == 0L) return if (ar) "لسه ما اتحدّثش" else "Not updated yet"
        val f = SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date(t))
        return (if (ar) "آخر تحديث: " else "Last update: ") + f
    }

    /** تحديث دوري في الخلفية كل 12 ساعة (لما يكون فيه نت) */
    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<EngineUpdateWorker>(12, TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork("engine_update", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class EngineUpdateWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        EngineUpdater.updateIfStale(applicationContext)
        return Result.success()
    }
}
