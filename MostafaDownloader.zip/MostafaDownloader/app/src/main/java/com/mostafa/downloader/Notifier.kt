package com.mostafa.downloader

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** نطاق على مستوى التطبيق: التحميل يكمل حتى لو الشاشة اتقفلت */
object AppScope {
    val io: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
}

object Notifier {
    const val CH_PROGRESS = "downloads"
    const val CH_RESULT = "results"
    const val CH_UPDATE = "updates"
    const val ID_PROGRESS = 1001
    const val ID_UPDATE = 1003

    private fun isAr(ctx: Context) = SettingsStore(ctx).load().lang == "ar"
    private fun t(ctx: Context, a: String, e: String) = if (isAr(ctx)) a else e

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, t(ctx, "التحميلات الجارية", "Downloads in progress"), NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_RESULT, t(ctx, "نتيجة التحميل", "Download results"), NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_UPDATE, t(ctx, "تحديثات التطبيق", "App updates"), NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openApp(ctx: Context, tab: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("tab", tab)
        return PendingIntent.getActivity(ctx, tab, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun openFile(ctx: Context, uri: String, mime: String): PendingIntent {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(uri), mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, 77, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun post(ctx: Context, id: Int, n: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) return false
            if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return false
            NotificationManagerCompat.from(ctx).notify(id, n)
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun progressNotification(ctx: Context, pct: Int, detail: String = ""): Notification {
        val text = if (pct < 0) t(ctx, "جاري التحميل...", "Downloading...")
        else t(ctx, "جاري التحميل", "Downloading") + " $pct%" + (if (detail.isNotEmpty()) "  •  $detail" else "")
        return NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("SC Downloader")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, if (pct < 0) 0 else pct, pct < 0)
            .setContentIntent(openApp(ctx, 0))
            .build()
    }

    fun progress(ctx: Context, pct: Int, detail: String = "") {
        post(ctx, ID_PROGRESS, progressNotification(ctx, pct, detail))
    }

    fun test(ctx: Context) {
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_UPDATE)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("SC Downloader")
            .setContentText(t(ctx, "الإشعارات شغالة ✓", "Notifications are working ✓"))
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 0))
            .build()
        post(ctx, 1004, n)
    }

    fun cancelProgress(ctx: Context) {
        try {
            NotificationManagerCompat.from(ctx).cancel(ID_PROGRESS)
        } catch (e: Throwable) {
        }
    }

    fun done(ctx: Context, name: String, uri: String, mime: String) {
        val pi = if (uri.isNotEmpty()) openFile(ctx, uri, mime) else openApp(ctx, 0)
        val n = NotificationCompat.Builder(ctx, CH_RESULT)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(t(ctx, "تم التحميل", "Download complete"))
            .setContentText(name)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        post(ctx, 2000 + (System.currentTimeMillis() % 100000).toInt(), n)
    }

    fun transcriptDone(ctx: Context, name: String) {
        val n = NotificationCompat.Builder(ctx, CH_RESULT)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(t(ctx, "جاهز: النص والملخص", "Transcript and summary ready"))
            .setContentText(name)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 3))
            .build()
        post(ctx, 4000 + (System.currentTimeMillis() % 100000).toInt(), n)
    }

    fun failed(ctx: Context, msg: Msg) {
        val text = msg.get(isAr(ctx)).take(160)
        val n = NotificationCompat.Builder(ctx, CH_RESULT)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(t(ctx, "فشل التحميل", "Download failed"))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 0))
            .build()
        post(ctx, 3000 + (System.currentTimeMillis() % 100000).toInt(), n)
    }

    fun updateAvailable(ctx: Context, versionName: String): Boolean {
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_UPDATE)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(t(ctx, "يوجد تحديث جديد", "A new update is available"))
            .setContentText(
                t(ctx, "SC Downloader $versionName جاهز. اضغط للتحديث.", "SC Downloader $versionName is ready. Tap to update.")
            )
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 4))
            .build()
        return post(ctx, ID_UPDATE, n)
    }
}
