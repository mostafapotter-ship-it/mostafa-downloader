package com.mostafa.downloader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val title: String,
    val label: String,
    val date: String,
    val uri: String,
    val mime: String
)

class HistoryStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryItem(
                o.optString("title"), o.optString("label"), o.optString("date"),
                o.optString("uri"), o.optString("mime")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<HistoryItem>) {
        val arr = JSONArray()
        list.take(100).forEach {
            arr.put(
                JSONObject()
                    .put("title", it.title).put("label", it.label)
                    .put("date", it.date).put("uri", it.uri).put("mime", it.mime)
            )
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
