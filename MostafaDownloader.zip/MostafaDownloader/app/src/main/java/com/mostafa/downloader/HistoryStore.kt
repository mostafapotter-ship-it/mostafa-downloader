package com.mostafa.downloader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val title: String,
    val label: String,
    val date: String,
    val uri: String,
    val mime: String,
    val platform: String = "",
    val size: Long = 0L,
    val fav: Boolean = false
)

class HistoryStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> = try {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryItem(
                o.optString("title"), o.optString("label"), o.optString("date"),
                o.optString("uri"), o.optString("mime"),
                o.optString("platform", ""), o.optLong("size", 0L),
                o.optBoolean("fav", false)
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<HistoryItem>) {
        val arr = JSONArray()
        list.take(100).forEach {
            arr.put(
                JSONObject()
                    .put("title", it.title).put("label", it.label)
                    .put("date", it.date).put("uri", it.uri).put("mime", it.mime)
                    .put("platform", it.platform).put("size", it.size).put("fav", it.fav)
            )
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
