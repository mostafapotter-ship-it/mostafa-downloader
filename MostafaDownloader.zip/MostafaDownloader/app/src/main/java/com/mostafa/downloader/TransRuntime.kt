package com.mostafa.downloader

import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow

/** حالة الترجمة على مستوى التطبيق كله (مش مربوطة بالشاشة) عشان تكمل في الخلفية حتى لو التطبيق اتقفل من الأخيرة */
object TransRuntime {
    val ui = MutableStateFlow(DownloaderViewModel.TransUi())

    @Volatile
    var cancel = false

    @Volatile
    var job: Job? = null

    val running: Boolean get() = ui.value.running
}
