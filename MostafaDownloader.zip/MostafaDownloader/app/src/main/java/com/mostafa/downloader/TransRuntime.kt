package com.mostafa.downloader

import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow

/** حالة الترجمة على مستوى التطبيق كله (مش مربوطة بالشاشة) عشان تكمل في الخلفية حتى لو التطبيق اتقفل من الأخيرة */
object TransRuntime {
    val ui = MutableStateFlow(DownloaderViewModel.TransUi())

    @Volatile
    var cancel = false

    @Volatile
    var job: Job? = null

    val running: Boolean get() = ui.value.running

    // نص الفيديو والملخص
    val tr = MutableStateFlow(TranscriptUi())

    @Volatile
    var trCancel = false

    @Volatile
    var trJob: Job? = null

    val busy: Boolean get() = ui.value.running || tr.value.running
}

data class TranscriptUi(
    val running: Boolean = false,
    val stage: Msg? = null,
    val name: String = "",
    val text: String = "",
    val summary: String = "",
    val lang: String = "",
    val truncated: Boolean = false,
    val summaryError: Msg? = null,
    val error: Msg? = null
)
