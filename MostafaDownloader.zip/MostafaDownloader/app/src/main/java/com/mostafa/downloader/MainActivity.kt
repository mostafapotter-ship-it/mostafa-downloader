package com.mostafa.downloader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val vm: DownloaderViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val shared = if (intent?.action == Intent.ACTION_SEND)
            intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""

        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        DownloaderScreen(vm, shared)
                    }
                }
            }
        }
    }
}

@Composable
fun Choice(label: String, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, enabled = enabled, modifier = modifier,
            contentPadding = PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 13.sp, maxLines = 1) }
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier,
            contentPadding = PaddingValues(horizontal = 4.dp)) { Text(label, fontSize = 13.sp, maxLines = 1) }
    }
}

@Composable
fun DownloaderScreen(vm: DownloaderViewModel, initialText: String) {
    val state by vm.state.collectAsState()
    val history by vm.history.collectAsState()
    var input by remember { mutableStateOf(vm.extractUrl(initialText) ?: "") }
    var audioOnly by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(16.dp))

        Text(
            text = "MostafaDownloader",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "تيك توك • يوتيوب • إنستجرام • فيسبوك",
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("رابط الفيديو") },
            textStyle = TextStyle(textDirection = TextDirection.Ltr),
            singleLine = true,
            enabled = !state.busy
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = { input = clipboard.getText()?.text.orEmpty() },
                enabled = !state.busy
            ) { Text("لصق") }
            OutlinedButton(onClick = { input = "" }, enabled = !state.busy) { Text("مسح") }
        }

        // نوع التحميل
        Text("النوع", fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice("فيديو", !audioOnly, !state.busy, Modifier.weight(1f)) { audioOnly = false }
            Choice("MP3 320kbps HQ", audioOnly, !state.busy, Modifier.weight(1.6f)) { audioOnly = true }
        }

        // الجودة (للفيديو فقط)
        if (!audioOnly) {
            Text("الجودة", fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "الأفضل", 1080 to "1080p", 720 to "720p", 480 to "480p").forEach { (q, name) ->
                    Choice(name, quality == q, !state.busy, Modifier.weight(1f)) { quality = q }
                }
            }
        }

        Button(
            onClick = { vm.download(input, audioOnly, quality) },
            enabled = state.ready && !state.busy && input.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) { Text("تحميل", fontSize = 18.sp) }

        if (state.busy) {
            if (state.progress > 0f) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                Text("${(state.progress * 100).toInt()}%")
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }

        Text(
            text = state.message,
            textAlign = TextAlign.Center,
            color = if (state.isError) MaterialTheme.colorScheme.error
            else MaterialTheme.colorScheme.onSurface
        )

        TextButton(onClick = { vm.updateEngine() }, enabled = state.ready && !state.busy) {
            Text("تحديث محرك التحميل")
        }

        // سجل التحميلات
        HorizontalDivider()
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("سجل التحميلات (${history.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (history.isNotEmpty()) {
                TextButton(onClick = { vm.clearHistory() }) { Text("مسح السجل") }
            }
        }
        if (history.isEmpty()) {
            Text("لا توجد تحميلات بعد", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        history.forEach { item ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        try {
                            val i = Intent(Intent.ACTION_VIEW)
                                .setDataAndType(Uri.parse(item.uri), item.mime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            context.startActivity(i)
                        } catch (e: Exception) {
                            Toast.makeText(context, "تعذر فتح الملف", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .padding(vertical = 6.dp)
            ) {
                Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    "${item.label}  •  ${item.date}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            HorizontalDivider()
        }
        Spacer(Modifier.height(24.dp))
    }
}
