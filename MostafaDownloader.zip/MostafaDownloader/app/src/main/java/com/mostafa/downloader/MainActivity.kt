package com.mostafa.downloader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF0E1120)
private val CardC = Color(0xFF171B30)
private val Stroke = Color(0xFF2A3050)
private val Purple = Color(0xFF7C5CFF)
private val Blue = Color(0xFF3D8BFF)
private val Cyan = Color(0xFF00E5FF)
private val Muted = Color(0xFF9AA3C7)
private val ErrorC = Color(0xFFFF6B6B)
private val SuccessC = Color(0xFF4ADE80)
private val BrandBrush = Brush.horizontalGradient(listOf(Purple, Blue))

class MainActivity : ComponentActivity() {

    private val vm: DownloaderViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val shared = if (intent?.action == Intent.ACTION_SEND)
            intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    background = Bg,
                    surface = CardC,
                    onSurface = Color.White,
                    onBackground = Color.White,
                    error = ErrorC
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                        DownloaderScreen(vm, shared)
                    }
                }
            }
        }
    }
}

/** لوجو التطبيق: سهم تحميل داخل مربع متدرج */
@Composable
fun AppLogo(logoSize: Dp) {
    Canvas(Modifier.size(logoSize)) {
        val s = this.size.width / 96f
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Purple, Blue),
                start = Offset.Zero,
                end = Offset(this.size.width, this.size.height)
            ),
            cornerRadius = CornerRadius(24f * s, 24f * s)
        )
        val arrow = Path().apply {
            moveTo(42f * s, 20f * s)
            lineTo(54f * s, 20f * s)
            lineTo(54f * s, 48f * s)
            lineTo(68f * s, 48f * s)
            lineTo(48f * s, 70f * s)
            lineTo(28f * s, 48f * s)
            lineTo(42f * s, 48f * s)
            close()
        }
        drawPath(arrow, Color.White)
        drawRoundRect(
            color = Cyan,
            topLeft = Offset(26f * s, 76f * s),
            size = Size(44f * s, 6f * s),
            cornerRadius = CornerRadius(3f * s, 3f * s)
        )
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, enabled: Boolean, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Bg)
            .border(1.dp, Stroke, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) BrandBrush else SolidColor(Color.Transparent))
                    .clickable(enabled = enabled) { onSelect(i) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (sel) Color.White else Muted,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun GradientButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(BrandBrush, alpha = if (enabled) 1f else 0.35f)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun DownloaderScreen(vm: DownloaderViewModel, initialText: String) {
    val state by vm.state.collectAsState()
    val history by vm.history.collectAsState()
    var input by remember { mutableStateOf(vm.extractUrl(initialText) ?: "") }
    var audioOnly by remember { mutableStateOf(false) }
    var quality by remember { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val cardShape = RoundedCornerShape(22.dp)

    val qualityValues = listOf(0, 1080, 720, 480)
    val qualityLabels = listOf("الأفضل", "1080p", "720p", "480p")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(32.dp))

        // الهيدر: اللوجو + الاسم
        Image(
            painter = painterResource(R.drawable.ic_logo),
            contentDescription = "MostafaDownloader logo",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(124.dp)
                .clip(RoundedCornerShape(30.dp))
                .border(2.dp, BrandBrush, RoundedCornerShape(30.dp))
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "MostafaDownloader",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "تيك توك  •  يوتيوب  •  إنستجرام  •  فيسبوك",
            fontSize = 13.sp,
            color = Muted,
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(24.dp))

        // كارت التحميل
        Column(
            Modifier
                .fillMaxWidth()
                .clip(cardShape)
                .background(CardC)
                .border(1.dp, Stroke, cardShape)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("رابط الفيديو") },
                textStyle = TextStyle(textDirection = TextDirection.Ltr, fontSize = 14.sp),
                singleLine = true,
                enabled = !state.busy,
                shape = RoundedCornerShape(14.dp),
                trailingIcon = {
                    if (input.isBlank()) {
                        TextButton(
                            onClick = { input = clipboard.getText()?.text.orEmpty() },
                            enabled = !state.busy
                        ) { Text("لصق", color = Cyan, fontWeight = FontWeight.Bold) }
                    } else {
                        TextButton(onClick = { input = "" }, enabled = !state.busy) {
                            Text("مسح", color = Muted)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple,
                    unfocusedBorderColor = Stroke,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedLabelColor = Purple,
                    unfocusedLabelColor = Muted,
                    cursorColor = Purple
                )
            )

            Text("النوع", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Segmented(
                options = listOf("🎬  فيديو", "🎵  MP3 320kbps HQ"),
                selected = if (audioOnly) 1 else 0,
                enabled = !state.busy
            ) { audioOnly = it == 1 }

            if (!audioOnly) {
                Text("الجودة", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Segmented(
                    options = qualityLabels,
                    selected = qualityValues.indexOf(quality).coerceAtLeast(0),
                    enabled = !state.busy
                ) { quality = qualityValues[it] }
            }

            GradientButton(
                text = "تحميل",
                enabled = state.ready && !state.busy && input.isNotBlank()
            ) { vm.download(input, audioOnly, quality) }

            if (state.busy) {
                if (state.progress > 0f) {
                    LinearProgressIndicator(
                        progress = { state.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = Stroke
                    )
                    Text(
                        "${(state.progress * 100).toInt()}%",
                        color = Cyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = Cyan,
                        trackColor = Stroke
                    )
                }
            }

            Text(
                text = state.message,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                fontSize = 13.sp,
                color = when {
                    state.isError -> ErrorC
                    !state.busy && state.progress >= 1f -> SuccessC
                    else -> Muted
                }
            )
        }

        TextButton(onClick = { vm.updateEngine() }, enabled = state.ready && !state.busy) {
            Text("⟳  تحديث محرك التحميل", color = Muted, fontSize = 13.sp)
        }

        Spacer(Modifier.height(8.dp))

        // سجل التحميلات
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "سجل التحميلات (${history.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.White
            )
            if (history.isNotEmpty()) {
                TextButton(onClick = { vm.clearHistory() }) { Text("مسح السجل", color = Muted) }
            }
        }
        Spacer(Modifier.height(6.dp))

        if (history.isEmpty()) {
            Text(
                "لا توجد تحميلات بعد",
                color = Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }

        history.forEach { item ->
            val itemShape = RoundedCornerShape(16.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .clip(itemShape)
                    .background(CardC)
                    .border(1.dp, Stroke, itemShape)
                    .clickable {
                        try {
                            val i = Intent(Intent.ACTION_VIEW)
                                .setDataAndType(Uri.parse(item.uri), item.mime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            context.startActivity(i)
                        } catch (e: Exception) {
                            Toast.makeText(context, "تعذر فتح الملف", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandBrush),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (item.mime.startsWith("audio")) "🎵" else "🎬", fontSize = 18.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(2.dp))
                    Text("${item.label}  •  ${item.date}", fontSize = 11.sp, color = Muted)
                }
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}
