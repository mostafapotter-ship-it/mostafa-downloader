package com.mostafa.downloader

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {

    private val vm: DownloaderViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val shared = if (intent?.action == Intent.ACTION_SEND)
            intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""

        setContent { AppRoot(vm, shared) }
    }
}

@Composable
fun AppRoot(vm: DownloaderViewModel, shared: String) {
    val s by vm.settings.collectAsState()
    val dark = when (s.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val colors = if (dark) DarkColors else LightColors
    val lang = remember(s.lang) { Lang(s.lang == "ar") }
    var tab by rememberSaveable { mutableStateOf(0) }

    BackHandler(enabled = tab != 0) { tab = 0 }

    val scheme = if (dark) {
        darkColorScheme(
            primary = Purple, background = colors.bg, surface = colors.card,
            onSurface = colors.text, onBackground = colors.text, error = ErrorC
        )
    } else {
        lightColorScheme(
            primary = Purple, background = colors.bg, surface = colors.card,
            onSurface = colors.text, onBackground = colors.text, error = ErrorC
        )
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalColors provides colors,
            LocalLang provides lang,
            LocalLayoutDirection provides (if (lang.ar) LayoutDirection.Rtl else LayoutDirection.Ltr)
        ) {
            val view = LocalView.current
            SideEffect {
                val window = (view.context as Activity).window
                window.statusBarColor = colors.bg.toArgb()
                window.navigationBarColor = colors.card.toArgb()
                val ctrl = WindowCompat.getInsetsController(window, view)
                ctrl.isAppearanceLightStatusBars = !dark
                ctrl.isAppearanceLightNavigationBars = !dark
            }
            Column(Modifier.fillMaxSize().background(colors.bg)) {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> HomeScreen(vm, shared, onOpenSettings = { tab = 2 }, onOpenWhatsApp = { tab = 1 })
                        1 -> WhatsAppScreen(vm)
                        else -> SettingsScreen(vm)
                    }
                }
                BottomBar(tab) { tab = it }
            }
        }
    }
}
