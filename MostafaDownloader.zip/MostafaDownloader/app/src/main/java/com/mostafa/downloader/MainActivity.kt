package com.mostafa.downloader

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private val vm: DownloaderViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val openTab = mutableStateOf(-1)
    private val sharedText = mutableStateOf("")
    private val focusTick = mutableStateOf(0)

    private fun sharedFrom(i: Intent?): String =
        if (i?.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT).orEmpty() else ""

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openTab.value = intent.getIntExtra("tab", -1)
        val sh = sharedFrom(intent)
        if (sh.isNotEmpty()) sharedText.value = sh
    }

    // قراءة الحافظة مسموحة بس لما التطبيق يكون في الواجهة وعليه التركيز
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) focusTick.value++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        sharedText.value = sharedFrom(intent)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        Notifier.ensureChannels(this)
        UpdateScheduler.schedule(this)

        Accent.set(Accent.byId(vm.settings.value.accent))
        openTab.value = intent?.getIntExtra("tab", -1) ?: -1
        setContent { AppRoot(vm, sharedText, focusTick, openTab) }
    }
}

@Composable
fun AppRoot(
    vm: DownloaderViewModel,
    shared: MutableState<String>,
    focusTick: MutableState<Int>,
    openTab: MutableState<Int>
) {
    val s by vm.settings.collectAsState()
    val dark = when (s.theme) {
        "dark", "amoled" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val colors = when {
        s.theme == "amoled" -> AmoledColors
        dark -> DarkColors
        else -> LightColors
    }
    val lang = remember(s.lang) { Lang(s.lang == "ar") }
    var tab by rememberSaveable { mutableStateOf(0) }
    LaunchedEffect(openTab.value) {
        if (openTab.value >= 0) {
            tab = openTab.value
            openTab.value = -1
        }
    }

    val sharedNow = shared.value
    LaunchedEffect(sharedNow) { if (sharedNow.isNotEmpty()) tab = 0 }

    // الشاشة الافتتاحية: مرة واحدة عند فتح التطبيق (ومن غير تأخير لو اتفتح من مشاركة رابط)
    var showSplash by rememberSaveable { mutableStateOf(sharedNow.isEmpty()) }
    var loginSite by rememberSaveable { mutableStateOf<String?>(null) }
    var cookieTick by rememberSaveable { mutableStateOf(0) }
    var importSite by rememberSaveable { mutableStateOf<String?>(null) }

    BackHandler(enabled = tab != 0) { tab = 0 }
    BackHandler(enabled = loginSite != null) { loginSite = null }
    BackHandler(enabled = importSite != null) { importSite = null }

    val scheme = if (dark) {
        darkColorScheme(
            primary = Purple, background = colors.bg, surface = colors.card,
            onSurface = colors.text, onBackground = colors.text, error = ErrorC
        )
    } else {
        lightColorScheme(
            primary = Purple, background = colors.bg, surface = colors.card,
            onSurface = colors.text, onBackground = colors.text, error = ErrorC
        )
    }

    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalColors provides colors,
            LocalLang provides lang,
            LocalLayoutDirection provides (if (lang.ar) LayoutDirection.Rtl else LayoutDirection.Ltr)
        ) {
            val view = LocalView.current
            SideEffect {
                val window = (view.context as Activity).window
                window.statusBarColor = colors.bg.toArgb()
                window.navigationBarColor = colors.card.toArgb()
                val ctrl = WindowCompat.getInsetsController(window, view)
                ctrl.isAppearanceLightStatusBars = !dark
                ctrl.isAppearanceLightNavigationBars = !dark
            }
            val ls = loginSite
            val ims = importSite
            if (showSplash) {
                SplashScreen { showSplash = false }
            } else if (!s.onboarded) {
                Onboarding { vm.setOnboarded(true) }
            } else if (ls != null) {
                LoginScreen(ls) { ok ->
                    if (ok) cookieTick++
                    loginSite = null
                }
            } else if (ims != null) {
                CookieImportScreen(ims) { ok ->
                    if (ok) cookieTick++
                    importSite = null
                }
            } else {
                Column(Modifier.fillMaxSize().background(colors.bg)) {
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            0 -> HomeScreen(
                                vm, sharedNow,
                                focusTick = focusTick.value,
                                onSharedConsumed = { shared.value = "" },
                                onOpenSettings = { tab = 4 },
                                onOpenWhatsApp = { tab = 1 }
                            )
                            1 -> WhatsAppScreen(vm)
                            2 -> StoriesScreen(
                                vm, cookieTick,
                                onLogin = { loginSite = it },
                                onImport = { importSite = it }
                            )
                            3 -> TranslateScreen(vm, onOpenSettings = { tab = 4 })
                            else -> SettingsScreen(vm)
                        }
                    }
                    BottomBar(tab) { tab = it }
                }
            }
        }
    }
}
