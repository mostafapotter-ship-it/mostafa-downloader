package com.mostafa.downloader

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

/**
 * محاولة احتياطية لاستوريهات إنستجرام: بتستعمل متصفح مخفي (WebView) مسجّل فيه دخولك
 * وتسأل واجهة إنستجرام نفسها عن الاستوري، بدل ما تعتمد على كوكيز yt-dlp.
 */
object IgStory {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

    private fun decodeJs(raw: String?): String {
        if (raw == null || raw == "null") return ""
        return try {
            val v = JSONTokener(raw).nextValue()
            if (v is String) v else ""
        } catch (e: Exception) {
            ""
        }
    }

    private suspend fun evalJs(w: WebView?, js: String): String? = suspendCancellableCoroutine { cont ->
        if (w == null) {
            cont.resume(null)
        } else {
            w.evaluateJavascript(js) { v ->
                if (cont.isActive) cont.resume(v)
            }
        }
    }

    private fun script(username: String, override: String): String = """
        (function(){
          window.__ig = null;
          var H = {'X-IG-App-ID':'936619743392459','X-ASBD-ID':'129477','X-IG-WWW-Claim':'0','X-Requested-With':'XMLHttpRequest','Accept':'*/*'};
          function get(u){ return fetch(u, {headers:H, credentials:'include'}).then(function(r){ return r.text().then(function(t){ return {s:r.status, t:t}; }); }); }
          var override = 'OVERRIDE';
          var start = override ? Promise.resolve(override) : get('/api/v1/users/web_profile_info/?username=USERNAME').then(function(p){
            if (p.s !== 200) { throw new Error('profile HTTP ' + p.s + ' ' + p.t.slice(0,160)); }
            return JSON.parse(p.t).data.user.id;
          });
          start.then(function(id){ return get('/api/v1/feed/reels_media/?reel_ids=' + encodeURIComponent(id)); })
               .then(function(q){ window.__ig = JSON.stringify({status:q.s, body:q.t}); })
               .catch(function(e){ window.__ig = JSON.stringify({error:String(e)}); });
          return 'started';
        })()
    """.trimIndent().replace("USERNAME", username).replace("OVERRIDE", override)

    private suspend fun callApi(ctx: Context, username: String, override: String): String {
        var wv: WebView? = null
        try {
            withContext(Dispatchers.Main) {
                val w = WebView(ctx.applicationContext)
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.userAgentString = UA
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
                w.webViewClient = WebViewClient()
                w.loadUrl("https://www.instagram.com/")
                wv = w
            }
            var ready = false
            repeat(40) {
                if (!ready) {
                    delay(500)
                    val u = withContext(Dispatchers.Main) { wv?.url }
                    if (u != null && u.startsWith("https://www.instagram.com")) ready = true
                }
            }
            delay(1500)
            withContext(Dispatchers.Main) { evalJs(wv, script(username, override)) }

            val deadline = System.currentTimeMillis() + 30000
            while (System.currentTimeMillis() < deadline) {
                delay(700)
                val r = decodeJs(withContext(Dispatchers.Main) { evalJs(wv, "window.__ig") })
                if (r.isNotEmpty()) return r
            }
            throw IllegalStateException("ERROR: Instagram request timed out")
        } finally {
            withContext(Dispatchers.Main) {
                try {
                    wv?.destroy()
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun findItems(root: JSONObject): JSONArray? {
        val reels = root.optJSONObject("reels")
        if (reels != null) {
            val keys = reels.keys()
            if (keys.hasNext()) {
                val a = reels.optJSONObject(keys.next())?.optJSONArray("items")
                if (a != null) return a
            }
        }
        return root.optJSONArray("reels_media")?.optJSONObject(0)?.optJSONArray("items")
    }

    private fun fetchFile(u: String, dest: File) {
        val conn = URL(u).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", UA)
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("media HTTP $code")
            conn.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
    }

    suspend fun download(ctx: Context, url: String, dir: File) {
        val m = Regex("instagram\\.com/stories/([^/?#]+)/?(\\d+)?").find(url)
            ?: throw IllegalStateException("ERROR: Instagram story link not recognized")
        val who = m.groupValues[1]
        val storyId = m.groupValues[2]
        val highlight = who == "highlights" && storyId.isNotEmpty()
        val override = if (highlight) "highlight:$storyId" else ""
        if (!highlight && !who.matches(Regex("[A-Za-z0-9._]+"))) {
            throw IllegalStateException("ERROR: Instagram username not recognized")
        }

        val res = JSONObject(callApi(ctx, if (highlight) "" else who, override))
        if (res.has("error")) {
            throw IllegalStateException("ERROR: Instagram fallback: " + res.optString("error").take(300))
        }
        val status = res.optInt("status")
        val body = res.optString("body")
        if (status != 200) {
            throw IllegalStateException("ERROR: Instagram API HTTP $status ${body.take(200)}")
        }
        val items = findItems(JSONObject(body))
            ?: throw IllegalStateException("ERROR: Instagram: no active stories found for this account (they may have expired)")

        val list = ArrayList<Triple<String, String, String>>()
        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            val pk = item.optString("pk")
            if (!highlight && storyId.isNotEmpty() && pk != storyId && !item.optString("id").startsWith(storyId)) continue
            val v = item.optJSONArray("video_versions")
            if (v != null && v.length() > 0) {
                list.add(Triple(v.getJSONObject(0).getString("url"), "mp4", pk))
            } else {
                val c = item.optJSONObject("image_versions2")?.optJSONArray("candidates")
                if (c != null && c.length() > 0) list.add(Triple(c.getJSONObject(0).getString("url"), "jpg", pk))
            }
        }
        if (list.isEmpty()) {
            throw IllegalStateException(
                "ERROR: Instagram: story $storyId not found among ${items.length()} active stories (it may have expired)"
            )
        }
        list.take(20).forEach { (u, ext, pk) ->
            fetchFile(u, File(dir, "instagram_story_${who}_$pk.$ext"))
        }
    }
}
