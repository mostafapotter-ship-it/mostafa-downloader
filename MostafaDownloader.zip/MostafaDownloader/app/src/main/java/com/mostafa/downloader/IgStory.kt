package com.mostafa.downloader

import android.content.Context
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.resume

/**
 * استوريهات إنستجرام عن طريق متصفح مخفي (WebView) مسجّل فيه دخولك:
 * 1) بيفتح صفحة الاستوري زي أي مشاهدة عادية ويلتقط الردود اللي الصفحة نفسها بتطلبها.
 * 2) لو الصفحة ما رجّعتش بيانات، بيجرّب سؤال واجهة إنستجرام مباشرة.
 */
object IgStory {
    private const val UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val HOOK_JS = """
        (function(){
          if (window.__igHooked) { return; }
          window.__igHooked = true;
          window.__igcap = [];
          function keep(t){ try { if (t && (t.indexOf('video_versions') > -1 || t.indexOf('image_versions2') > -1)) { window.__igcap.push(t); } } catch(e){} }
          var of = window.fetch;
          if (of) {
            window.fetch = function(){
              var p = of.apply(this, arguments);
              try { p.then(function(r){ try { r.clone().text().then(keep); } catch(e){} }); } catch(e){}
              return p;
            };
          }
          var os = XMLHttpRequest.prototype.send;
          XMLHttpRequest.prototype.send = function(){
            try { this.addEventListener('load', function(){ try { keep(this.responseText); } catch(e){} }); } catch(e){}
            return os.apply(this, arguments);
          };
        })();
    """.trimIndent()

    private val CLICK_JS = """
        (function(){
          var bs = Array.prototype.slice.call(document.querySelectorAll('button,div[role=button]'));
          for (var i = 0; i < bs.length; i++) {
            var t = (bs[i].innerText || '').trim();
            if (/view story/i.test(t)) { bs[i].click(); return 'clicked'; }
          }
          return 'none';
        })()
    """.trimIndent()

    private class Captured(val items: List<Triple<String, String, String>>, val diag: String, val count: Int)

    private fun decodeJs(raw: String?): String {
        if (raw == null || raw == "null") return ""
        return try {
            val v = JSONTokener(raw).nextValue()
            if (v is String) v else ""
        } catch (e: Exception) {
            ""
        }
    }

    private suspend fun evalJs(w: WebView?, js: String): String? = suspendCancellableCoroutine { cont ->
        if (w == null) {
            cont.resume(null)
        } else {
            w.evaluateJavascript(js) { v ->
                if (cont.isActive) cont.resume(v)
            }
        }
    }

    private fun collect(node: Any?, out: MutableList<JSONObject>) {
        when (node) {
            is JSONObject -> {
                if ((node.has("video_versions") || node.has("image_versions2")) && (node.has("pk") || node.has("id"))) {
                    out.add(node)
                }
                val keys = node.keys()
                while (keys.hasNext()) collect(node.opt(keys.next()), out)
            }
            is JSONArray -> for (i in 0 until node.length()) collect(node.opt(i), out)
        }
    }

    /** يقرا رد الصفحة حتى لو فيه بادئة غريبة أو أكتر من JSON في أسطر */
    private fun parseLoose(text: String, out: MutableList<JSONObject>) {
        val candidates = ArrayList<String>()
        candidates.add(text)
        text.split('\n').forEach { candidates.add(it) }
        for (c0 in candidates) {
            var c = c0.trim()
            if (c.startsWith("for (;;);")) c = c.removePrefix("for (;;);").trim()
            val i = c.indexOfFirst { it == '{' || it == '[' }
            if (i < 0) continue
            try {
                collect(JSONTokener(c.substring(i)).nextValue(), out)
                if (out.isNotEmpty()) return
            } catch (e: Exception) {
            }
        }
    }

    private fun toMedia(
        nodes: List<JSONObject>,
        storyId: String,
        highlight: Boolean
    ): List<Triple<String, String, String>> {
        val any = ArrayList<Triple<String, String, String>>()
        val matched = ArrayList<Triple<String, String, String>>()
        val seen = HashSet<String>()
        for (item in nodes) {
            val id = item.optString("id")
            val pk = item.optString("pk").ifEmpty { id.substringBefore("_") }
            if (pk.isEmpty() || !seen.add(pk)) continue
            val v = item.optJSONArray("video_versions")
            val entry: Triple<String, String, String>? =
                if (v != null && v.length() > 0) {
                    Triple(v.getJSONObject(0).getString("url"), "mp4", pk)
                } else {
                    val c = item.optJSONObject("image_versions2")?.optJSONArray("candidates")
                    if (c != null && c.length() > 0) Triple(c.getJSONObject(0).getString("url"), "jpg", pk) else null
                }
            if (entry == null) continue
            any.add(entry)
            if (storyId.isNotEmpty() && (pk == storyId || id.contains(storyId))) matched.add(entry)
        }
        if (highlight || storyId.isEmpty()) return any
        if (matched.isNotEmpty()) return matched
        return if (any.size == 1) any else emptyList()
    }

    // ---------- 1) فتح الاستوري في متصفح مخفي والتقاط ردود الصفحة ----------
    private suspend fun viewerCapture(ctx: Context, url: String, storyId: String, highlight: Boolean): Captured {
        var wv: WebView? = null
        val hooked = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        try {
            withContext(Dispatchers.Main) {
                val w = WebView(ctx.applicationContext)
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.userAgentString = UA
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
                if (hooked) {
                    WebViewCompat.addDocumentStartJavaScript(w, HOOK_JS, setOf("https://www.instagram.com"))
                }
                w.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, u: String?, favicon: Bitmap?) {
                        if (!hooked) view?.evaluateJavascript(HOOK_JS, null)
                    }
                }
                w.loadUrl(url)
                wv = w
            }

            var lastCount = -1
            var stable = 0
            var info = ""
            val deadline = System.currentTimeMillis() + 40000
            while (System.currentTimeMillis() < deadline) {
                delay(1500)
                withContext(Dispatchers.Main) { evalJs(wv, CLICK_JS) }
                val cnt = withContext(Dispatchers.Main) {
                    evalJs(wv, "window.__igcap ? window.__igcap.length : -1")
                }?.trim()?.toIntOrNull() ?: -1
                if (cnt > 0) {
                    val all = decodeJs(withContext(Dispatchers.Main) { evalJs(wv, "JSON.stringify(window.__igcap)") })
                    val nodes = ArrayList<JSONObject>()
                    var first = ""
                    try {
                        val arr = JSONArray(all)
                        if (arr.length() > 0) first = arr.optString(0).take(100).replace("\n", " ")
                        for (i in 0 until arr.length()) parseLoose(arr.optString(i), nodes)
                    } catch (e: Exception) {
                    }
                    val media = toMedia(nodes, storyId, highlight)
                    if (media.isNotEmpty()) return Captured(media, "ok", cnt)
                    info = "nodes=${nodes.size}, cap0=$first"
                    stable = if (cnt == lastCount) stable + 1 else 0
                    lastCount = cnt
                    if (stable >= 4) break
                }
            }
            val txt = decodeJs(
                withContext(Dispatchers.Main) {
                    evalJs(wv, "(document.body && document.body.innerText || '').slice(0,140)")
                }
            ).replace("\n", " ")
            val cur = withContext(Dispatchers.Main) { wv?.url }
            return Captured(
                emptyList(),
                "url=${cur?.take(90)}, captured=$lastCount, hook=$hooked, $info, text=$txt",
                lastCount.coerceAtLeast(0)
            )
        } finally {
            withContext(Dispatchers.Main) {
                try {
                    wv?.destroy()
                } catch (e: Exception) {
                }
            }
        }
    }

    // ---------- 2) سؤال واجهة إنستجرام مباشرة ----------
    private fun script(username: String, override: String): String = """
        (function(){
          window.__ig = null;
          var H = {'X-IG-App-ID':'936619743392459','X-ASBD-ID':'129477','X-IG-WWW-Claim':'0','X-Requested-With':'XMLHttpRequest','Accept':'*/*'};
          function get(u){ return fetch(u, {headers:H, credentials:'include'}).then(function(r){ return r.text().then(function(t){ return {s:r.status, t:t}; }); }); }
          var override = 'OVERRIDE';
          var start = override ? Promise.resolve(override) : get('/api/v1/users/web_profile_info/?username=USERNAME').then(function(p){
            if (p.s !== 200) { throw new Error('profile HTTP ' + p.s + (p.t.trim().charAt(0) === '{' ? ' ' + p.t.slice(0,160) : '')); }
            return JSON.parse(p.t).data.user.id;
          });
          start.then(function(id){ return get('/api/v1/feed/reels_media/?reel_ids=' + encodeURIComponent(id)).then(function(q){ q.uid = id; return q; }); })
               .then(function(q){ window.__ig = JSON.stringify({status:q.s, uid:q.uid, body:(q.s === 200 ? q.t : (q.t.trim().charAt(0) === '{' ? q.t.slice(0,200) : ''))}); })
               .catch(function(e){ window.__ig = JSON.stringify({error:String(e)}); });
          return 'started';
        })()
    """.trimIndent().replace("USERNAME", username).replace("OVERRIDE", override)

    private suspend fun callApi(ctx: Context, username: String, override: String): String {
        var wv: WebView? = null
        try {
            withContext(Dispatchers.Main) {
                val w = WebView(ctx.applicationContext)
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.userAgentString = UA
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
                w.webViewClient = WebViewClient()
                w.loadUrl("https://www.instagram.com/")
                wv = w
            }
            var ready = false
            repeat(40) {
                if (!ready) {
                    delay(500)
                    val u = withContext(Dispatchers.Main) { wv?.url }
                    if (u != null && u.startsWith("https://www.instagram.com")) ready = true
                }
            }
            delay(1500)
            withContext(Dispatchers.Main) { evalJs(wv, script(username, override)) }

            val deadline = System.currentTimeMillis() + 30000
            while (System.currentTimeMillis() < deadline) {
                delay(700)
                val r = decodeJs(withContext(Dispatchers.Main) { evalJs(wv, "window.__ig") })
                if (r.isNotEmpty()) return r
            }
            throw IllegalStateException("request timed out")
        } finally {
            withContext(Dispatchers.Main) {
                try {
                    wv?.destroy()
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun findItems(root: JSONObject): JSONArray? {
        val reels = root.optJSONObject("reels")
        if (reels != null) {
            val keys = reels.keys()
            if (keys.hasNext()) {
                val a = reels.optJSONObject(keys.next())?.optJSONArray("items")
                if (a != null) return a
            }
        }
        return root.optJSONArray("reels_media")?.optJSONObject(0)?.optJSONArray("items")
    }

    private suspend fun viaApi(
        ctx: Context,
        who: String,
        storyId: String,
        highlight: Boolean
    ): List<Triple<String, String, String>> {
        val prefs = ctx.getSharedPreferences("ig_cache", Context.MODE_PRIVATE)
        val cachedUid = if (highlight) "" else (prefs.getString("uid_$who", "") ?: "")
        val override = if (highlight) "highlight:$storyId" else cachedUid
        if (!highlight && !who.matches(Regex("[A-Za-z0-9._]+"))) {
            throw IllegalStateException("username not recognized")
        }
        val res = JSONObject(callApi(ctx, if (highlight || cachedUid.isNotEmpty()) "" else who, override))
        if (res.has("error")) throw IllegalStateException(res.optString("error").take(300))
        val uid = res.optString("uid")
        val status = res.optInt("status")
        val body = res.optString("body")
        if (status != 200) throw IllegalStateException("API HTTP $status ${body.take(200)}")
        if (!highlight && uid.isNotEmpty() && uid != cachedUid) {
            prefs.edit().putString("uid_$who", uid).apply()
        }
        val items = findItems(JSONObject(body))
            ?: throw IllegalStateException("no active stories found (they may have expired)")
        val nodes = ArrayList<JSONObject>()
        for (i in 0 until items.length()) nodes.add(items.getJSONObject(i))
        val media = toMedia(nodes, storyId, highlight)
        if (media.isEmpty()) {
            throw IllegalStateException("story $storyId not found among ${items.length()} active stories (it may have expired)")
        }
        return media
    }

    private fun fetchFile(u: String, dest: File) {
        val conn = URL(u).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", UA)
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("media HTTP $code")
            conn.inputStream.use { input -> dest.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
    }

    private fun save(media: List<Triple<String, String, String>>, who: String, dir: File) {
        media.take(20).forEach { (u, ext, pk) ->
            fetchFile(u, File(dir, "instagram_story_${who}_$pk.$ext"))
        }
    }

    suspend fun download(ctx: Context, url: String, dir: File) {
        val m = Regex("instagram\\.com/stories/([^/?#]+)/?(\\d+)?").find(url)
            ?: throw IllegalStateException("ERROR: Instagram story link not recognized")
        val who = m.groupValues[1]
        val storyId = m.groupValues[2]
        val highlight = who == "highlights" && storyId.isNotEmpty()

        val notes = ArrayList<String>()
        var viewerCount = 0
        try {
            val r = viewerCapture(ctx, url, storyId, highlight)
            if (r.items.isNotEmpty()) {
                save(r.items, who, dir)
                return
            }
            viewerCount = r.count
            notes.add("viewer: ${r.diag}")
        } catch (e: Exception) {
            notes.add("viewer: ${e.message ?: e.javaClass.simpleName}")
        }

        val blocked = viewerCount > 0 || notes.any { it.contains("wait", true) || it.contains("try again", true) }
        if (!blocked) {
            try {
                save(viaApi(ctx, who, storyId, highlight), who, dir)
                return
            } catch (e: Exception) {
                notes.add("api: ${(e.message ?: e.javaClass.simpleName).take(220)}")
            }
        }
        throw IllegalStateException("ERROR: Instagram story failed. " + notes.joinToString(" | "))
    }
}
