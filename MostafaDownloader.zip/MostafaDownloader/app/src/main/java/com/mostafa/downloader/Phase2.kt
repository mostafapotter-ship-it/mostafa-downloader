package com.mostafa.downloader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ============================== السجل: فلاتر + عنصر ==============================

/** فلاتر السجل: 0 = الكل، 1 = فيديو، 2 = صوت */
fun matchesHistoryFilter(item: HistoryItem, filter: Int): Boolean = when (filter) {
    1 -> item.mime.startsWith("video")
    2 -> item.mime.startsWith("audio")
    else -> true
}

@Composable
fun HistoryFilterChips(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            val shape = RoundedCornerShape(50)
            Box(
                Modifier
                    .clip(shape)
                    .then(
                        if (sel) Modifier.background(BrandBrush, shape)
                        else Modifier.background(c.card, shape).border(1.dp, c.stroke, shape)
                    )
                    .clickable { onSelect(i) }
                    .padding(horizontal = 13.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (sel) Color.White else c.muted,
                    fontSize = 12.sp,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

private object ThumbCache {
    val cache = LruCache<String, Bitmap>(64)
}

private fun scaleDown(src: Bitmap, max: Int): Bitmap {
    val m = maxOf(src.width, src.height)
    if (m <= max) return src
    val f = max.toFloat() / m
    return Bitmap.createScaledBitmap(src, (src.width * f).toInt().coerceAtLeast(1), (src.height * f).toInt().coerceAtLeast(1), true)
}

private fun loadThumb(ctx: android.content.Context, item: HistoryItem): Bitmap? {
    ThumbCache.cache.get(item.uri)?.let { return it }
    val uri = Uri.parse(item.uri)
    val bmp: Bitmap? = try {
        when {
            item.mime.startsWith("image") -> {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 512 || bounds.outHeight / sample > 512) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            }
            item.mime.startsWith("video") -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val f = r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: r.getFrameAtTime(0)
                    f?.let { scaleDown(it, 320) }
                } finally {
                    try { r.release() } catch (_: Exception) {}
                }
            }
            else -> null
        }
    } catch (e: Exception) {
        null
    }
    if (bmp != null) ThumbCache.cache.put(item.uri, bmp)
    return bmp
}

/** صورة مصغّرة للملف؛ لو مفيش (صوت/ملف اتحذف) بنعرض أيقونة المنصة على خلفية بلونها */
@Composable
fun HistoryThumb(item: HistoryItem, size: Dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, item.uri) {
        value = withContext(Dispatchers.IO) { loadThumb(ctx, item)?.asImageBitmap() }
    }
    val plat = Platforms.firstOrNull { it.id == item.platform }
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .size(size)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(plat?.color ?: 0xFF1A2150).copy(alpha = 0.85f),
                        Color(0xFF0D1228)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b, contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size)
            )
        } else if (item.mime.startsWith("audio")) {
            Text("🎵", fontSize = 24.sp)
        } else if (plat != null) {
            Image(
                painter = painterResource(plat.res), contentDescription = null,
                modifier = Modifier.size(size * 0.5f)
            )
        } else {
            Text(if (item.mime.startsWith("image")) "🖼" else "🎬", fontSize = 24.sp)
        }
    }
}

@Composable
fun HistoryItemRow(
    item: HistoryItem,
    divider: Boolean,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onFav: () -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    var menu by remember { mutableStateOf(false) }
    // في التصميم: الصف LTR (صورة يسار، أزرار يمين) حتى في الواجهة العربية
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onPlay() }
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                HistoryThumb(item, 56.dp)
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = c.text, fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    val sizeTxt = if (item.size > 0) fmtSize(item.size) else ""
                    Text(
                        listOf(sizeTxt, item.date.substringBefore(' ')).filter { it.isNotEmpty() }.joinToString("  •  "),
                        fontSize = 12.sp, color = c.muted, maxLines = 1
                    )
                }
                if (item.fav) {
                    Icon(
                        painter = painterResource(R.drawable.ic_heart), contentDescription = null,
                        tint = Color(0xFFFF4D8D), modifier = Modifier.size(16.dp)
                    )
                }
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1B2450))
                        .border(1.dp, c.stroke, CircleShape)
                        .clickable { onPlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_play), contentDescription = null,
                        tint = Color.White, modifier = Modifier.size(18.dp)
                    )
                }
                Box {
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).clickable { menu = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_more_vert), contentDescription = null,
                            tint = c.muted, modifier = Modifier.size(22.dp)
                        )
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = {
                                Text(if (item.fav) l.t("إزالة من المفضلة", "Remove from favorites")
                                else l.t("إضافة للمفضلة", "Add to favorites"))
                            },
                            onClick = { menu = false; onFav() }
                        )
                        DropdownMenuItem(
                            text = { Text(l.t("مشاركة", "Share")) },
                            onClick = { menu = false; onShare() }
                        )
                        DropdownMenuItem(
                            text = { Text(l.t("حذف", "Delete"), color = ErrorC) },
                            onClick = { menu = false; onDelete() }
                        )
                    }
                }
            }
            if (divider) Box(Modifier.fillMaxWidth().height(1.dp).background(c.stroke.copy(alpha = 0.6f)))
        }
    }
}

// ============================== الإعدادات: مكونات ==============================

@Composable
fun SettingsHeader(versionName: String) {
    val c = LocalColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(130.dp)
                    .background(
                        Brush.radialGradient(listOf(Purple.copy(alpha = 0.35f), Color.Transparent)),
                        CircleShape
                    )
            )
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(84.dp)
                    .clip(RoundedCornerShape(22.dp))
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = c.text)) { append("Mostafa ") }
                withStyle(SpanStyle(color = Cyan)) { append("Downloader") }
            },
            fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
            style = androidx.compose.ui.text.TextStyle(textDirection = androidx.compose.ui.text.style.TextDirection.Ltr)
        )
        Spacer(Modifier.height(2.dp))
        Text("v$versionName", color = c.muted, fontSize = 13.sp)
    }
}

@Composable
fun SettingsGroupTitle(text: String) {
    val c = LocalColors.current
    Text(
        text,
        color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 4.dp)
    )
}

/** حاوية مجموعة صفوف بإطار موحّد */
@Composable
fun SettingsGroup(content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape),
        content = content
    )
}

@Composable
private fun RowIcon(icon: String, iconRes: Int? = null) {
    if (iconRes != null) {
        Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
            Icon(
                painter = painterResource(iconRes), contentDescription = null,
                tint = Cyan, modifier = Modifier.size(24.dp)
            )
        }
        return
    }
    Box(
        Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(Purple.copy(alpha = 0.30f), Cyan.copy(alpha = 0.18f)))),
        contentAlignment = Alignment.Center
    ) { Text(icon, fontSize = 17.sp) }
}

@Composable
private fun RowDivider() {
    val c = LocalColors.current
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 64.dp)
            .height(1.dp)
            .background(c.stroke.copy(alpha = 0.6f))
    )
}

/** صف إعداد: أيقونة + نص + (سهم أو أي عنصر في الآخر) */
@Composable
fun SettingsRow(
    icon: String,
    title: String,
    subtitle: String? = null,
    titleColor: Color? = null,
    showArrow: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
    divider: Boolean = true,
    iconRes: Int? = null,
    onClick: (() -> Unit)? = null
) {
    val c = LocalColors.current
    val l = LocalLang.current
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RowIcon(icon, iconRes)
            Column(Modifier.weight(1f)) {
                Text(title, color = titleColor ?: c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, color = c.muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            if (trailing != null) trailing()
            else if (showArrow && onClick != null) Text(if (l.ar) "‹" else "›", color = c.muted, fontSize = 22.sp)
        }
        if (divider) RowDivider()
    }
}

@Composable
fun SettingsSwitchRow(
    icon: String,
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    divider: Boolean = true,
    iconRes: Int? = null,
    onChange: (Boolean) -> Unit
) {
    SettingsRow(
        icon = icon, title = title, subtitle = subtitle, divider = divider, iconRes = iconRes,
        trailing = {
            Switch(
                checked = checked, onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Purple,
                    uncheckedThumbColor = Color.White,
                    uncheckedTrackColor = LocalColors.current.stroke,
                    uncheckedBorderColor = Color.Transparent
                )
            )
        },
        onClick = { onChange(!checked) }
    )
}

/** صف بيتفتح ويعرض محتواه تحته (بيستخدم نفس الكروت القديمة من غير ما نفقد أي وظيفة) */
@Composable
fun SettingsExpandRow(
    icon: String,
    title: String,
    subtitle: String? = null,
    badge: String? = null,
    divider: Boolean = true,
    iconRes: Int? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = LocalColors.current
    var open by rememberSaveable(title) { mutableStateOf(false) }
    Column {
        SettingsRow(
            icon = icon, title = title, subtitle = subtitle, iconRes = iconRes,
            divider = divider && !open,
            trailing = {
                if (badge != null) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(BrandBrush)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) { Text(badge, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(6.dp))
                }
                Text(if (open) "▲" else "▼", color = c.muted, fontSize = 12.sp)
            },
            onClick = { open = !open }
        )
        if (open) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
            if (divider) {
                Spacer(Modifier.height(8.dp))
                RowDivider()
            }
        }
    }
}

// ============================== شاشة تحميل منصة: كارت المميزات ==============================

@Composable
fun AppFeaturesCard() {
    val c = LocalColors.current
    val l = LocalLang.current
    val shape = RoundedCornerShape(22.dp)
    val gold = Color(0xFFFFC83D)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF141E4A), c.card)))
            .border(1.dp, Purple.copy(alpha = 0.45f), shape)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("⭐", fontSize = 20.sp)
                Text(l.t("ميزات التطبيق", "App features"), color = gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            listOf(
                l.t("تحميل فيديوهات وصوتيات", "Download videos and audio"),
                l.t("دعم جميع المنصات", "Supports all platforms"),
                l.t("قص الفيديوهات", "Trim videos"),
                l.t("جودة عالية", "High quality"),
                l.t("سريع وآمن", "Fast and safe")
            ).forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier.size(20.dp).clip(CircleShape).background(SuccessC),
                        contentAlignment = Alignment.Center
                    ) { Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    Text(f, color = c.text, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        Box(contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(110.dp).background(
                    Brush.radialGradient(listOf(Purple.copy(alpha = 0.35f), Color.Transparent)), CircleShape
                )
            )
            Image(
                painter = painterResource(R.drawable.ic_clapper), contentDescription = null,
                modifier = Modifier.size(84.dp)
            )
            Text("✦", color = gold, fontSize = 18.sp, modifier = Modifier.align(Alignment.TopStart))
            Text("✦", color = Cyan, fontSize = 12.sp, modifier = Modifier.align(Alignment.TopEnd))
        }
    }
}

// ============================== Splash: صف المنصات ==============================

@Composable
fun SplashPlatformRow(alpha: Float) {
    // سحابة أيقونات مايلة زي التصميم: صفين (fb ig tt) و(x yt wa sc)
    val rows = listOf(listOf("fb", "ig", "tt"), listOf("x", "yt", "wa", "sc"))
    Column(
        Modifier.alpha(alpha).graphicsLayer { rotationZ = -9f },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        rows.forEach { ids ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                ids.forEach { id ->
                    val p = Platforms.first { it.id == id }
                    Image(
                        painter = painterResource(p.res), contentDescription = null,
                        modifier = Modifier.size(54.dp)
                    )
                }
            }
        }
    }
}

// ============================== شريط عنوان + بطاقة البروفايل + القائمة الجانبية ==============================

@Composable
fun ScreenTitleBar(title: String, trailingIcon: Int? = null) {
    val c = LocalColors.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.size(40.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = c.text)
            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                if (trailingIcon != null) {
                    Icon(
                        painter = painterResource(trailingIcon), contentDescription = null,
                        tint = c.text, modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsProfileCard(versionName: String) {
    val c = LocalColors.current
    val l = LocalLang.current
    val shape = RoundedCornerShape(22.dp)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(c.card)
                .border(1.dp, c.stroke, shape)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(2.5.dp, Brush.sweepGradient(listOf(Cyan, Purple, Cyan)), CircleShape)
                    .padding(4.dp)
                    .clip(CircleShape)
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_logo), contentDescription = null,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
            Column {
                Text("Mostafa Downloader", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(
                    l.t("إصدار التطبيق", "App version") + ": v$versionName",
                    color = c.muted, fontSize = 12.sp
                )
            }
        }
    }
}

private const val REPO_URL = "https://github.com/mostafapotter-ship-it/mostafa-downloader"

/** القائمة الجانبية (Drawer): بتغطي الشاشة بخلفية معتمة، واللوحة من جهة البداية */
@Composable
fun AppDrawer(onClose: () -> Unit, onNav: (Int) -> Unit) {
    val l = LocalLang.current
    val ctx = LocalContext.current
    val none = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pink = Color(0xFFFF4D8D)
    val items = listOf(
        Triple(R.drawable.ic_nav_home, l.t("الرئيسية", "Home"), Cyan),
        Triple(R.drawable.ic_nav_history, l.t("تحميلاتي", "My downloads"), Cyan),
        Triple(R.drawable.ic_heart, l.t("المفضلة", "Favorites"), pink),
        Triple(R.drawable.ic_nav_settings, l.t("الإعدادات", "Settings"), Color(0xFF4DA3FF)),
        Triple(R.drawable.ic_share, l.t("مشاركة التطبيق", "Share the app"), Color.White),
        Triple(R.drawable.ic_star, l.t("قيّم التطبيق", "Rate the app"), Color(0xFFFFC83D)),
        Triple(R.drawable.ic_info, l.t("حول التطبيق", "About"), Color(0xFF3DA9FF)),
        Triple(R.drawable.ic_exit, l.t("خروج", "Exit"), ErrorC)
    )
    val actions: List<() -> Unit> = listOf(
        { onNav(0) }, { onNav(1) }, { onNav(5) }, { onNav(4) },
        {
            onClose()
            try {
                val send = android.content.Intent(android.content.Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(android.content.Intent.EXTRA_TEXT, "Mostafa Downloader\n$REPO_URL")
                ctx.startActivity(android.content.Intent.createChooser(send, l.t("مشاركة التطبيق", "Share the app")))
            } catch (e: Exception) {
            }
        },
        {
            onClose()
            try {
                ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(REPO_URL)))
            } catch (e: Exception) {
            }
        },
        { onNav(4) },
        { (ctx as? android.app.Activity)?.finishAffinity() }
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable(interactionSource = none, indication = null) { onClose() }
    ) {
        Column(
            Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight()
                .fillMaxWidth(0.86f)
                .background(Brush.verticalGradient(listOf(Color(0xFF0E1740), Color(0xFF070B1E))))
                .clickable(interactionSource = none, indication = null) { }
                .padding(horizontal = 18.dp, vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.size(40.dp).clip(CircleShape).clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_close), contentDescription = null,
                        tint = Color.White, modifier = Modifier.size(24.dp)
                    )
                }
            }
            Box(contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(150.dp).background(
                        Brush.radialGradient(listOf(Cyan.copy(alpha = 0.35f), Color.Transparent)), CircleShape
                    )
                )
                Box(
                    Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .border(3.dp, Brush.sweepGradient(listOf(Cyan, Purple, Cyan)), CircleShape)
                        .padding(4.dp)
                        .clip(CircleShape)
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_logo), contentDescription = null,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
            }
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White)) { append("Mostafa") }
                    withStyle(SpanStyle(color = Cyan)) { append("Downloader") }
                },
                fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                style = androidx.compose.ui.text.TextStyle(textDirection = androidx.compose.ui.text.style.TextDirection.Ltr)
            )
            Text(l.t("تحميل سريع .. بكل سهولة", "Fast & easy downloads"), color = Color.White, fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
            items.forEachIndexed { i, (icon, label, tint) ->
                val shape = RoundedCornerShape(14.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(shape)
                        .background(Color(0xFF111B45))
                        .border(1.dp, Color(0xFF263A7A).copy(alpha = 0.8f), shape)
                        .clickable { actions[i]() }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        painter = painterResource(icon), contentDescription = null,
                        tint = tint, modifier = Modifier.size(22.dp)
                    )
                    Text(
                        label, color = if (i == items.lastIndex) ErrorC else Color.White,
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
