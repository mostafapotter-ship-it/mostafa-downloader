package com.mostafa.downloader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ============================== السجل: فلاتر + عنصر ==============================

/** فلاتر السجل: 0 = الكل، 1 = فيديو، 2 = صوت */
fun matchesHistoryFilter(item: HistoryItem, filter: Int): Boolean = when (filter) {
    1 -> item.mime.startsWith("video")
    2 -> item.mime.startsWith("audio")
    else -> true
}

@Composable
fun HistoryFilterChips(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            val shape = RoundedCornerShape(50)
            Box(
                Modifier
                    .clip(shape)
                    .then(
                        if (sel) Modifier.background(BrandBrush, shape)
                        else Modifier.background(c.card, shape).border(1.dp, c.stroke, shape)
                    )
                    .clickable { onSelect(i) }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (sel) Color.White else c.muted,
                    fontSize = 13.sp,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

private object ThumbCache {
    val cache = LruCache<String, Bitmap>(64)
}

private fun scaleDown(src: Bitmap, max: Int): Bitmap {
    val m = maxOf(src.width, src.height)
    if (m <= max) return src
    val f = max.toFloat() / m
    return Bitmap.createScaledBitmap(src, (src.width * f).toInt().coerceAtLeast(1), (src.height * f).toInt().coerceAtLeast(1), true)
}

private fun loadThumb(ctx: android.content.Context, item: HistoryItem): Bitmap? {
    ThumbCache.cache.get(item.uri)?.let { return it }
    val uri = Uri.parse(item.uri)
    val bmp: Bitmap? = try {
        when {
            item.mime.startsWith("image") -> {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 512 || bounds.outHeight / sample > 512) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            }
            item.mime.startsWith("video") -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    val f = r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: r.getFrameAtTime(0)
                    f?.let { scaleDown(it, 320) }
                } finally {
                    try { r.release() } catch (_: Exception) {}
                }
            }
            else -> null
        }
    } catch (e: Exception) {
        null
    }
    if (bmp != null) ThumbCache.cache.put(item.uri, bmp)
    return bmp
}

/** صورة مصغّرة للملف؛ لو مفيش (صوت/ملف اتحذف) بنعرض أيقونة المنصة على خلفية بلونها */
@Composable
fun HistoryThumb(item: HistoryItem, size: Dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, item.uri) {
        value = withContext(Dispatchers.IO) { loadThumb(ctx, item)?.asImageBitmap() }
    }
    val plat = Platforms.firstOrNull { it.id == item.platform }
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .size(size)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(plat?.color ?: 0xFF1A2150).copy(alpha = 0.85f),
                        Color(0xFF0D1228)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b, contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size)
            )
        } else if (item.mime.startsWith("audio")) {
            Text("🎵", fontSize = 24.sp)
        } else if (plat != null) {
            Image(
                painter = painterResource(plat.res), contentDescription = null,
                modifier = Modifier.size(size * 0.5f)
            )
        } else {
            Text(if (item.mime.startsWith("image")) "🖼" else "🎬", fontSize = 24.sp)
        }
        // شارة نوع الملف
        if (b != null && item.mime.startsWith("video")) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) { Text("▶", color = Color.White, fontSize = 9.sp) }
        }
    }
}

@Composable
fun HistoryItemRow(
    item: HistoryItem,
    labelStr: String,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val c = LocalColors.current
    val l = LocalLang.current
    val shape = RoundedCornerShape(18.dp)
    var menu by remember { mutableStateOf(false) }
    val plat = Platforms.firstOrNull { it.id == item.platform }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape)
            .clickable { onPlay() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HistoryThumb(item, 64.dp)
        Column(Modifier.weight(1f)) {
            Text(
                item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                color = c.text, fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
            Spacer(Modifier.height(3.dp))
            val sizeTxt = if (item.size > 0) fmtSize(item.size) else ""
            Text(
                listOf(sizeTxt, item.date).filter { it.isNotEmpty() }.joinToString("  •  "),
                fontSize = 11.sp, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                listOfNotNull(plat?.name, labelStr.takeIf { it.isNotBlank() }).joinToString("  •  "),
                fontSize = 11.sp, color = Cyan, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(BrandBrush)
                .clickable { onPlay() },
            contentAlignment = Alignment.Center
        ) { Text("▶", color = Color.White, fontSize = 15.sp) }
        Box {
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .clickable { menu = true },
                contentAlignment = Alignment.Center
            ) { Text("⋮", color = c.muted, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(l.t("مشاركة", "Share")) },
                    onClick = { menu = false; onShare() }
                )
                DropdownMenuItem(
                    text = { Text(l.t("حذف", "Delete"), color = ErrorC) },
                    onClick = { menu = false; onDelete() }
                )
            }
        }
    }
}

// ============================== الإعدادات: مكونات ==============================

@Composable
fun SettingsHeader(versionName: String) {
    val c = LocalColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(130.dp)
                    .background(
                        Brush.radialGradient(listOf(Purple.copy(alpha = 0.35f), Color.Transparent)),
                        CircleShape
                    )
            )
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(84.dp)
                    .clip(RoundedCornerShape(22.dp))
            )
        }
        Spacer(Modifier.height(8.dp))
        Row {
            Text("Mostafa ", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("Downloader", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(2.dp))
        Text("v$versionName", color = c.muted, fontSize = 13.sp)
    }
}

@Composable
fun SettingsGroupTitle(text: String) {
    val c = LocalColors.current
    Text(
        text,
        color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 4.dp)
    )
}

/** حاوية مجموعة صفوف بإطار موحّد */
@Composable
fun SettingsGroup(content: @Composable ColumnScope.() -> Unit) {
    val c = LocalColors.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.dp, c.stroke, shape),
        content = content
    )
}

@Composable
private fun RowIcon(icon: String) {
    Box(
        Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(Purple.copy(alpha = 0.30f), Cyan.copy(alpha = 0.18f)))),
        contentAlignment = Alignment.Center
    ) { Text(icon, fontSize = 17.sp) }
}

@Composable
private fun RowDivider() {
    val c = LocalColors.current
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 64.dp)
            .height(1.dp)
            .background(c.stroke.copy(alpha = 0.6f))
    )
}

/** صف إعداد: أيقونة + نص + (سهم أو أي عنصر في الآخر) */
@Composable
fun SettingsRow(
    icon: String,
    title: String,
    subtitle: String? = null,
    titleColor: Color? = null,
    showArrow: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
    divider: Boolean = true,
    onClick: (() -> Unit)? = null
) {
    val c = LocalColors.current
    val l = LocalLang.current
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RowIcon(icon)
            Column(Modifier.weight(1f)) {
                Text(title, color = titleColor ?: c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, color = c.muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            if (trailing != null) trailing()
            else if (showArrow && onClick != null) Text(if (l.ar) "‹" else "›", color = c.muted, fontSize = 22.sp)
        }
        if (divider) RowDivider()
    }
}

@Composable
fun SettingsSwitchRow(
    icon: String,
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    divider: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    SettingsRow(
        icon = icon, title = title, subtitle = subtitle, divider = divider,
        trailing = {
            Switch(
                checked = checked, onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Purple,
                    uncheckedThumbColor = Color.White,
                    uncheckedTrackColor = LocalColors.current.stroke,
                    uncheckedBorderColor = Color.Transparent
                )
            )
        },
        onClick = { onChange(!checked) }
    )
}

/** صف بيتفتح ويعرض محتواه تحته (بيستخدم نفس الكروت القديمة من غير ما نفقد أي وظيفة) */
@Composable
fun SettingsExpandRow(
    icon: String,
    title: String,
    subtitle: String? = null,
    badge: String? = null,
    divider: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = LocalColors.current
    var open by rememberSaveable(title) { mutableStateOf(false) }
    Column {
        SettingsRow(
            icon = icon, title = title, subtitle = subtitle,
            divider = divider && !open,
            trailing = {
                if (badge != null) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(BrandBrush)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) { Text(badge, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(6.dp))
                }
                Text(if (open) "▲" else "▼", color = c.muted, fontSize = 12.sp)
            },
            onClick = { open = !open }
        )
        if (open) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
            if (divider) {
                Spacer(Modifier.height(8.dp))
                RowDivider()
            }
        }
    }
}

// ============================== شاشة تحميل منصة: كارت المميزات ==============================

@Composable
fun AppFeaturesCard() {
    val c = LocalColors.current
    val l = LocalLang.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.card)
            .border(1.dp, Purple.copy(alpha = 0.35f), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Text(l.t("مميزات التطبيق ⭐", "App features ⭐"), color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        listOf(
            l.t("تحميل بجودة عالية (حتى 4K)", "High quality downloads (up to 4K)"),
            l.t("سريع وآمن وبدون إعلانات", "Fast, safe and ad-free"),
            l.t("ترجمة تلقائية وحرق الترجمة في الفيديو", "Auto translation and burned-in subtitles"),
            l.t("يدعم كل المنصات الأساسية", "Supports all the major platforms")
        ).forEach { f ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.size(20.dp).clip(CircleShape).background(SuccessC.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { Text("✓", color = SuccessC, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                Text(f, color = c.muted, fontSize = 13.sp)
            }
        }
    }
}

// ============================== Splash: صف المنصات ==============================

@Composable
fun SplashPlatformRow(alpha: Float) {
    Row(
        Modifier.alpha(alpha),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Platforms.forEach { p ->
            Box(
                Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(p.color).copy(alpha = 0.9f)),
                contentAlignment = Alignment.Center
            ) {
                Image(painter = painterResource(p.res), contentDescription = null, modifier = Modifier.size(20.dp))
            }
        }
    }
}
