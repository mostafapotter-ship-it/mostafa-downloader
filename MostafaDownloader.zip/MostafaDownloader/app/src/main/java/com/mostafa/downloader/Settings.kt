package com.mostafa.downloader

import android.content.Context
import java.util.Locale

/** رسالة ثنائية اللغة */
data class Msg(val ar: String, val en: String) {
    fun get(isAr: Boolean): String = if (isAr) ar else en
}

data class AppSettings(
    val lang: String,
    val theme: String,
    val waUri: String = "",
    val wabUri: String = "",
    val accent: String = "violet",
    val autoShare: Boolean = true,
    val wifiOnly: Boolean = false
)

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): AppSettings = AppSettings(
        lang = p.getString("lang", null) ?: (if (Locale.getDefault().language == "ar") "ar" else "en"),
        theme = p.getString("theme", "dark") ?: "dark",
        waUri = p.getString("wa", "") ?: "",
        wabUri = p.getString("wab", "") ?: "",
        accent = p.getString("accent", "violet") ?: "violet",
        autoShare = p.getBoolean("auto_share", true),
        wifiOnly = p.getBoolean("wifi_only", false)
    )

    fun save(s: AppSettings) {
        p.edit()
            .putString("lang", s.lang)
            .putString("theme", s.theme)
            .putString("wa", s.waUri)
            .putString("wab", s.wabUri)
            .putString("accent", s.accent)
            .putBoolean("auto_share", s.autoShare)
            .putBoolean("wifi_only", s.wifiOnly)
            .apply()
    }
}
