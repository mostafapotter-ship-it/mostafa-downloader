package com.mostafa.downloader

import android.content.Context
import java.util.Locale

/** رسالة ثنائية اللغة */
data class Msg(val ar: String, val en: String) {
    fun get(isAr: Boolean): String = if (isAr) ar else en
}

data class AppSettings(
    val lang: String,
    val theme: String,
    val waUri: String = "",
    val wabUri: String = "",
    val accent: String = "violet",
    val autoShare: Boolean = true,
    val wifiOnly: Boolean = false,
    val fastEngine: Boolean = true,
    val clipSuggest: Boolean = true,
    val groqKey: String = "",
    /** مكان الحفظ المخصص (SAF tree URI)؛ فاضي = Downloads/MostafaDownloader */
    val saveUri: String = "",
    val platformFolders: Boolean = false,
    val nameTemplate: String = "{title}",
    val onboarded: Boolean = false
)

class SettingsStore(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): AppSettings = AppSettings(
        lang = p.getString("lang", null) ?: (if (Locale.getDefault().language == "ar") "ar" else "en"),
        theme = p.getString("theme", "dark") ?: "dark",
        waUri = p.getString("wa", "") ?: "",
        wabUri = p.getString("wab", "") ?: "",
        accent = p.getString("accent", "violet") ?: "violet",
        autoShare = p.getBoolean("auto_share", true),
        wifiOnly = p.getBoolean("wifi_only", false),
        fastEngine = p.getBoolean("fast_engine", true),
        clipSuggest = p.getBoolean("clip_suggest", true),
        groqKey = p.getString("groq_key", "") ?: "",
        saveUri = p.getString("save_uri", "") ?: "",
        platformFolders = p.getBoolean("platform_folders", false),
        nameTemplate = p.getString("name_tpl", "{title}") ?: "{title}",
        // مستخدم قديم (عنده سجل تحميلات) مايشوفش شاشة الترحيب
        onboarded = if (p.contains("onboarded")) p.getBoolean("onboarded", false)
        else (ctx.getSharedPreferences("history", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]") != "[]"
    )

    fun save(s: AppSettings) {
        p.edit()
            .putString("lang", s.lang)
            .putString("theme", s.theme)
            .putString("wa", s.waUri)
            .putString("wab", s.wabUri)
            .putString("accent", s.accent)
            .putBoolean("auto_share", s.autoShare)
            .putBoolean("wifi_only", s.wifiOnly)
            .putBoolean("fast_engine", s.fastEngine)
            .putBoolean("clip_suggest", s.clipSuggest)
            .putString("groq_key", s.groqKey)
            .putString("save_uri", s.saveUri)
            .putBoolean("platform_folders", s.platformFolders)
            .putString("name_tpl", s.nameTemplate)
            .putBoolean("onboarded", s.onboarded)
            .apply()
    }
}
