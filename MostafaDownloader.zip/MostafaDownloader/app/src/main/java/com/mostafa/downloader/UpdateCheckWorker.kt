package com.mostafa.downloader

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

/** يفحص وجود تحديث في الخلفية (كل عدة ساعات) ويبعت إشعار من غير ما تفتح التطبيق */
class UpdateCheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        try {
            val r = Updater.fetchLatest()
            if (r != null && r.versionCode > BuildConfig.VERSION_CODE) {
                val prefs = applicationContext.getSharedPreferences("notif", Context.MODE_PRIVATE)
                if (prefs.getInt("notified", 0) < r.versionCode) {
                    Notifier.updateAvailable(applicationContext, r.name)
                    prefs.edit().putInt("notified", r.versionCode).apply()
                }
            }
        } catch (e: Exception) {
        }
        return Result.success()
    }
}
