package com.mostafa.downloader

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** يفحص وجود تحديث في الخلفية (كل عدة ساعات) ويبعت إشعار من غير ما تفتح التطبيق */
class UpdateCheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        check(applicationContext, force = false)
        return Result.success()
    }

    companion object {
        private const val DAY = 24 * 60 * 60 * 1000L

        /** بيفحص ويبعت الإشعار، وبيسجّل النتيجة عشان تظهر في الإعدادات */
        fun check(ctx: Context, force: Boolean): String {
            val prefs = ctx.getSharedPreferences("notif", Context.MODE_PRIVATE)
            fun log(s: String): String {
                prefs.edit().putLong("last_check", System.currentTimeMillis()).putString("last_result", s).apply()
                return s
            }
            return try {
                if (!force && !prefs.getBoolean("update_notifs", true)) return log("off")
                val r = Updater.fetchLatest() ?: return log("no release / network")
                if (r.versionCode <= BuildConfig.VERSION_CODE) return log("up-to-date (${BuildConfig.VERSION_CODE})")
                val now = System.currentTimeMillis()
                val should = force || prefs.getInt("notified", 0) < r.versionCode ||
                    now - prefs.getLong("notified_at", 0L) > DAY
                if (!should) return log("update ${r.name} — already notified")
                if (Notifier.updateAvailable(ctx, r.name)) {
                    prefs.edit().putInt("notified", r.versionCode).putLong("notified_at", now).apply()
                    log("notified: ${r.name}")
                } else {
                    // ما نسجّلش إنه اتبلّغ، عشان نحاول تاني
                    log("update ${r.name} found but notification was blocked (permission / settings)")
                }
            } catch (e: Exception) {
                log("error: ${e.message}")
            }
        }

        fun lastInfo(ctx: Context, ar: Boolean): String {
            val p = ctx.getSharedPreferences("notif", Context.MODE_PRIVATE)
            val t = p.getLong("last_check", 0L)
            if (t == 0L) return if (ar) "لسه مفيش فحص حصل في الخلفية." else "No background check has run yet."
            val f = SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date(t))
            val res = p.getString("last_result", "") ?: ""
            return (if (ar) "آخر فحص: " else "Last check: ") + "$f — $res"
        }
    }
}

/** منبّه دوري (أوثق من WorkManager لوحده على أجهزة أوبو/ريلمي/شاومي) + إعادة الجدولة بعد إعادة التشغيل */
class UpdateAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        UpdateScheduler.armAlarm(ctx)
        WorkManager.getInstance(ctx).enqueueUniqueWork(
            "update_check_now",
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<UpdateCheckWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
        )
    }
}

object UpdateScheduler {
    private const val INTERVAL_HOURS = 3L

    fun schedule(ctx: Context) {
        val request = PeriodicWorkRequestBuilder<UpdateCheckWorker>(INTERVAL_HOURS, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork("update_check", ExistingPeriodicWorkPolicy.UPDATE, request)
        armAlarm(ctx)
    }

    fun armAlarm(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 4242, Intent(ctx, UpdateAlarmReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + TimeUnit.HOURS.toMillis(INTERVAL_HOURS),
                pi
            )
        } catch (e: Exception) {
        }
    }
}
