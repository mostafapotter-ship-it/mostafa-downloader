package com.mostafa.downloader

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

data class DlOptions(
    val mode: Int = 0,
    val quality: Int = 0,
    val audioFmt: String = "mp3-320",
    val imageFmt: String = "jpg"
)

data class UiState(
    val ready: Boolean = false,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val message: Msg = Msg("جاري تجهيز المحرك...", "Preparing the engine..."),
    val isError: Boolean = false,
    val detail: String = ""
)

data class UpdateUi(
    val checking: Boolean = false,
    val available: Updater.Release? = null,
    val downloading: Boolean = false,
    val progress: Float = 0f,
    val message: Msg? = null
)

class DownloaderViewModel(app: Application) : AndroidViewModel(app) {

    // ---------- الإعدادات ----------
    private val settingsStore = SettingsStore(app)
    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun saveSettings(s: AppSettings) {
        _settings.value = s
        settingsStore.save(s)
    }

    fun setLang(lang: String) = saveSettings(_settings.value.copy(lang = lang))
    fun setTheme(theme: String) = saveSettings(_settings.value.copy(theme = theme))
    fun setAccent(accent: String) = saveSettings(_settings.value.copy(accent = accent))
    fun setWaUri(variant: Int, uri: String) {
        val s = _settings.value
        saveSettings(if (variant == 0) s.copy(waUri = uri) else s.copy(wabUri = uri))
    }

    // ---------- التحميل ----------
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val store = HistoryStore(app)
    private val _history = MutableStateFlow(store.load())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    private val _engineMsg = MutableStateFlow<Msg?>(null)
    val engineMsg: StateFlow<Msg?> = _engineMsg.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                _state.update {
                    it.copy(ready = true, message = Msg("جاهز — الصق الرابط وابدأ", "Ready — paste a link to start"))
                }
                autoUpdateEngine()
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        message = Msg("فشل تجهيز المحرك: ${e.message}", "Engine setup failed: ${e.message}"),
                        isError = true
                    )
                }
            }
        }
    }

    fun extractUrl(text: String): String? = Regex("https?://\\S+").find(text)?.value

    /** تحديث المحرك تلقائياً عند فتح التطبيق (مرة كل 12 ساعة) من غير تدخل المستخدم */
    private fun autoUpdateEngine() {
        val app = getApplication<Application>()
        val prefs = app.getSharedPreferences("engine", Context.MODE_PRIVATE)
        val last = prefs.getLong("last_update", 0L)
        if (System.currentTimeMillis() - last < 12L * 3600L * 1000L) return
        AppScope.io.launch {
            _engineMsg.value = Msg("جاري تحديث المحرك تلقائياً...", "Updating the engine automatically...")
            try {
                YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.NIGHTLY)
                prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
                _engineMsg.value = Msg("تم تحديث المحرك تلقائياً", "Engine updated automatically")
            } catch (e: Exception) {
                _engineMsg.value = Msg("تعذر التحديث التلقائي للمحرك", "Automatic engine update failed")
            }
        }
    }

    private val sizeRe = Regex("of\\s+~?\\s*([0-9.]+)\\s*([KMGT]?i?B)")
    private val speedRe = Regex("at\\s+([0-9.]+)\\s*([KMGT]?i?B)/s")
    private val etaRe = Regex("ETA\\s+([0-9:]+)")

    private fun toBytes(v: Double, unit: String): Double = when (unit.uppercase(Locale.US)) {
        "KIB" -> v * 1024.0
        "MIB" -> v * 1048576.0
        "GIB" -> v * 1073741824.0
        "KB" -> v * 1000.0
        "MB" -> v * 1000000.0
        "GB" -> v * 1000000000.0
        else -> v
    }

    private fun fmtBytes(b: Double): String = when {
        b >= 1073741824.0 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1048576.0 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1024.0 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
        else -> "${b.toInt()} B"
    }

    /** يطلّع من سطر yt-dlp: الحجم المنزّل / الإجمالي • السرعة • الوقت المتبقي */
    private fun progressDetail(line: String?, pct: Float): String? {
        if (line.isNullOrEmpty()) return null
        val sm = sizeRe.find(line) ?: return null
        val totalValue = sm.groupValues[1].toDoubleOrNull() ?: return null
        val total = toBytes(totalValue, sm.groupValues[2])
        val parts = ArrayList<String>()
        parts.add(fmtBytes(total * pct / 100.0) + " / " + fmtBytes(total))
        speedRe.find(line)?.let { m ->
            val v = m.groupValues[1].toDoubleOrNull()
            if (v != null) parts.add(fmtBytes(toBytes(v, m.groupValues[2])) + "/s")
        }
        etaRe.find(line)?.let { parts.add("ETA " + it.groupValues[1]) }
        return parts.joinToString("  •  ")
    }

    fun extractUrls(text: String): List<String> =
        Regex("https?://\\S+").findAll(text)
            .map { it.value.trimEnd(',', ';', ')') }
            .distinct().toList()

    /** للتوافق: فيديو/صوت بسيط */
    fun download(rawInput: String, audioOnly: Boolean, quality: Int) =
        download(rawInput, DlOptions(mode = if (audioOnly) 1 else 0, quality = quality))

    /** يحمّل رابط أو أكتر (طابور) بالخيارات المحددة */
    fun download(rawInput: String, opts: DlOptions) {
        val s = _state.value
        if (!s.ready || s.busy) return
        val urls = extractUrls(rawInput).take(20)
        if (urls.isEmpty()) {
            _state.update { it.copy(message = Msg("الرابط غير صحيح", "Invalid link"), isError = true) }
            return
        }
        val ctx = getApplication<Application>()
        Notifier.ensureChannels(ctx)
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (e: Exception) {
        }
        _state.value = UiState(ready = true, busy = true, message = Msg("جاري التحميل...", "Downloading..."))
        AppScope.io.launch {
            var ok = 0
            urls.forEachIndexed { i, u ->
                if (urls.size > 1) {
                    val n = "(${i + 1}/${urls.size}) "
                    _state.value = UiState(
                        ready = true, busy = true,
                        message = Msg(n + "جاري التحميل...", n + "Downloading...")
                    )
                }
                if (runOne(ctx, u, opts)) ok++
            }
            if (urls.size > 1) {
                _state.value = UiState(
                    ready = true,
                    progress = 1f,
                    isError = ok == 0,
                    message = Msg("تم تحميل $ok من ${urls.size}", "Downloaded $ok of ${urls.size}")
                )
            }
            try {
                ctx.stopService(Intent(ctx, DownloadService::class.java))
            } catch (e: Exception) {
            }
        }
    }

    private suspend fun runOne(ctx: Application, url: String, opts: DlOptions): Boolean {
            val tmp = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
            val site = CookieStore.siteOfUrl(url)
            var lastPct = -1
            try {
                val req = YoutubeDLRequest(url)
                val outName = if ("/stories/" in url) "%(uploader|story)s_%(id)s.%(ext)s" else "%(title).80s.%(ext)s"
                req.addOption("-o", "${tmp.absolutePath}/$outName")
                if ("/highlights/" !in url) req.addOption("--no-playlist")
                // تسريع: تحميل أجزاء الفيديو بالتوازي + إعادة المحاولة عند ضعف الشبكة
                req.addOption("-N", "4")
                req.addOption("--retries", "10")
                req.addOption("--fragment-retries", "10")
                req.addOption("--socket-timeout", "20")
                if (site != null && CookieStore.isLoggedIn(ctx, site)) {
                    req.addOption("--cookies", CookieStore.file(ctx, site).absolutePath)
                }
                when (opts.mode) {
                    1 -> {
                        req.addOption("-f", "bestaudio/best")
                        req.addOption("-x")
                        when (opts.audioFmt) {
                            "mp3-128" -> {
                                req.addOption("--audio-format", "mp3")
                                req.addOption("--audio-quality", "128K")
                            }
                            "m4a" -> req.addOption("--audio-format", "m4a")
                            "wav" -> req.addOption("--audio-format", "wav")
                            else -> {
                                req.addOption("--audio-format", "mp3")
                                req.addOption("--audio-quality", "320K")
                            }
                        }
                    }
                    2 -> {
                        req.addOption("--skip-download")
                        req.addOption("--write-thumbnail")
                        req.addOption("--convert-thumbnails", opts.imageFmt)
                    }
                    else -> {
                        val h = if (opts.quality > 0) "[height<=${opts.quality}]" else ""
                        req.addOption("-f", "bv*$h[ext=mp4]+ba[ext=m4a]/bv*$h+ba/b$h/b")
                        req.addOption("--merge-output-format", "mp4")
                    }
                }
                val igDirect = site == "ig" && "/stories/" in url && CookieStore.isLoggedIn(ctx, "ig")
                if (igDirect) {
                    _state.update {
                        it.copy(message = Msg("جاري تحميل استوري إنستجرام...", "Fetching the Instagram story..."))
                    }
                    IgStory.download(ctx, url, tmp)
                } else {
                try {
                    YoutubeDL.getInstance().execute(req) { progress, _, line ->
                        val p = progress.coerceIn(0f, 100f)
                        val detail = progressDetail(line, p)
                        _state.update { it.copy(progress = p / 100f, detail = detail ?: it.detail) }
                        val pct = p.toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            Notifier.progress(ctx, pct, detail ?: "")
                        }
                    }
                } catch (e: Exception) {
                    val em = e.message ?: ""
                    if (site == "fb" && CookieStore.isLoggedIn(ctx, "fb") && em.contains("Unsupported URL", true)) {
                        val resolved = Regex("Unsupported URL: (\\S+)").find(em)?.groupValues?.get(1)
                        _state.update {
                            it.copy(message = Msg("جاري محاولة فيسبوك البديلة...", "Trying the Facebook fallback..."))
                        }
                        FbStory.download(ctx, listOfNotNull(resolved, url).distinct(), tmp)
                    } else if (site == "ig" && CookieStore.isLoggedIn(ctx, "ig") && "/stories/" in url &&
                        (em.contains("log in", true) || em.contains("login", true) ||
                            em.contains("unable to extract user info", true) ||
                            em.contains("empty media response", true))
                    ) {
                        _state.update {
                            it.copy(message = Msg("جاري محاولة إنستجرام البديلة...", "Trying the Instagram fallback..."))
                        }
                        IgStory.download(ctx, url, tmp)
                    } else if ("snapchat.com" in url.lowercase() && "/spotlight/" in url && opts.mode != 1) {
                        _state.update {
                            it.copy(message = Msg("جاري محاولة سناب شات البديلة...", "Trying the Snapchat fallback..."))
                        }
                        try {
                            SnapSpotlight.download(url, tmp, opts.mode)
                        } catch (e2: Exception) {
                            throw IllegalStateException((e2.message ?: "Snapchat fallback failed") + "\n" + em.take(160))
                        }
                    } else {
                        throw e
                    }
                }
                }
                val files = tmp.listFiles()?.filter { it.isFile && it.length() > 0 }.orEmpty()
                if (files.isEmpty()) throw IllegalStateException("No output file")

                val label = when (opts.mode) {
                    1 -> when (opts.audioFmt) {
                        "mp3-128" -> "MP3 128kbps"
                        "m4a" -> "M4A"
                        "wav" -> "WAV"
                        else -> "MP3 320kbps"
                    }
                    2 -> opts.imageFmt.uppercase(Locale.US)
                    else -> if (opts.quality == 0) "BEST" else "${opts.quality}p"
                }
                var firstName = ""
                var firstUri = ""
                var firstMime = ""
                files.forEach { f ->
                    val (uri, mime) = saveToDownloads(ctx, f)
                    if (firstUri.isEmpty()) {
                        firstName = f.nameWithoutExtension
                        firstUri = uri
                        firstMime = mime
                    }
                    addHistory(
                        HistoryItem(
                            f.nameWithoutExtension, label,
                            SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date()),
                            uri, mime
                        )
                    )
                }
                _state.value = UiState(
                    ready = true,
                    progress = 1f,
                    message = Msg(
                        "تم الحفظ في Downloads/MostafaDownloader",
                        "Saved to Downloads/MostafaDownloader"
                    )
                )
                Notifier.done(ctx, firstName, firstUri, firstMime)
                return true
            } catch (e: Exception) {
                val m = cleanError(e.message)
                val loggedIn = CookieStore.isLoggedIn(ctx, site)
                val loginish = m.contains("login", true) || m.contains("cookies", true) ||
                    m.contains("unable to extract user info", true) ||
                    m.contains("instagram:story", true) || m.contains("empty media response", true)
                val msg = when {
                    m.contains("HTTP 429") -> Msg(
                        "إنستجرام بيحدّ الطلبات مؤقتاً (429). استنى فترة وجرّب تاني.\n$m",
                        "Instagram is temporarily rate-limiting requests (429). Wait a while and try again.\n$m"
                    )
                    site != null && !loggedIn && loginish -> Msg(
                        "لازم تسجّل دخول الأول من تبويب الاستوريهات.",
                        "Please sign in first from the Stories tab."
                    )
                    site != null && loggedIn && loginish -> Msg(
                        "فشل التحميل رغم تسجيل الدخول. سجّل خروج ودخول تاني من تبويب الاستوريهات، أو حدّث محرك التحميل من الإعدادات.\n$m",
                        "Download failed even though you're signed in. Sign out and in again from the Stories tab, or update the engine in Settings.\n$m"
                    )
                    else -> Msg("فشل التحميل: $m", "Download failed: $m")
                }
                _state.value = UiState(ready = true, message = msg, isError = true)
                Notifier.failed(ctx, msg)
                return false
            } finally {
                tmp.deleteRecursively()
                Notifier.cancelProgress(ctx)
            }
    }

    private fun cleanError(raw: String?): String {
        val m = raw ?: return ""
        val i = m.lastIndexOf("ERROR:")
        return (if (i >= 0) m.substring(i) else m).trim().take(600)
    }

    private fun addHistory(item: HistoryItem) {
        _history.value = (listOf(item) + _history.value).take(100)
        store.save(_history.value)
    }

    fun clearHistory() {
        _history.value = emptyList()
        store.save(emptyList())
    }

    fun updateEngine() {
        if (!_state.value.ready || _state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true) }
            _engineMsg.value = Msg("جاري تحديث المحرك...", "Updating the engine...")
            try {
                YoutubeDL.getInstance().updateYoutubeDL(getApplication(), YoutubeDL.UpdateChannel.NIGHTLY)
                _engineMsg.value = Msg("تم تحديث المحرك", "Engine updated")
            } catch (e: Exception) {
                _engineMsg.value = Msg("فشل التحديث: ${e.message}", "Update failed: ${e.message}")
            }
            _state.update { it.copy(busy = false) }
        }
    }

    private suspend fun saveToDownloads(ctx: Context, file: File): Pair<String, String> {
        val mime = when (file.extension.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "wav" -> "audio/wav"
            "opus" -> "audio/ogg"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/MostafaDownloader"
                )
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            return uri.toString() to mime
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "MostafaDownloader"
            ).apply { mkdirs() }
            val dest = File(dir, file.name)
            file.copyTo(dest, overwrite = true)
            val uri = suspendCancellableCoroutine<String> { cont ->
                MediaScannerConnection.scanFile(
                    ctx, arrayOf(dest.absolutePath), arrayOf(mime)
                ) { _, u -> cont.resume(u?.toString() ?: "") }
            }
            return uri to mime
        }
    }

    // ---------- تحديث التطبيق ----------
    private val _update = MutableStateFlow(UpdateUi())
    val update: StateFlow<UpdateUi> = _update.asStateFlow()
    private var pendingApk: File? = null

    fun checkUpdate(manual: Boolean) {
        if (_update.value.checking) return
        viewModelScope.launch(Dispatchers.IO) {
            _update.update { it.copy(checking = true, message = null) }
            try {
                val r = Updater.fetchLatest()
                if (r != null && r.versionCode > BuildConfig.VERSION_CODE) {
                    if (_update.value.available?.versionCode != r.versionCode) pendingApk = null
                    _update.update { it.copy(checking = false, available = r) }
                } else {
                    _update.update {
                        it.copy(
                            checking = false,
                            available = null,
                            message = if (!manual) null else if (r == null)
                                Msg("لا توجد إصدارات منشورة بعد", "No published releases yet")
                            else Msg("أنت على آخر إصدار", "You are on the latest version")
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        checking = false,
                        message = if (manual) Msg("تعذر التحقق من التحديثات", "Couldn't check for updates") else null
                    )
                }
            }
        }
    }

    fun installUpdate() {
        val r = _update.value.available ?: return
        if (_update.value.downloading) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apk: File = pendingApk?.takeIf { it.exists() } ?: run {
                    _update.update {
                        it.copy(
                            downloading = true, progress = 0f,
                            message = Msg("جاري تجهيز التحديث...", "Preparing the update...")
                        )
                    }
                    Updater.prepare(
                        ctx, r,
                        { p -> _update.update { it.copy(progress = p) } },
                        { delta ->
                            _update.update {
                                it.copy(
                                    progress = 0f,
                                    message = if (delta) Msg(
                                        "جاري تنزيل التحديث (التغييرات فقط)...",
                                        "Downloading the update (changes only)..."
                                    ) else Msg(
                                        "جاري تنزيل التحديث الكامل...",
                                        "Downloading the full update..."
                                    )
                                )
                            }
                        }
                    )
                }
                pendingApk = apk
                _update.update { it.copy(downloading = false) }
                if (Updater.canInstall(ctx)) {
                    Updater.install(ctx, apk)
                    _update.update {
                        it.copy(message = Msg("اضغط \"تثبيت\" في الشاشة اللي ظهرت", "Tap \"Install\" on the screen that appeared"))
                    }
                } else {
                    Updater.openInstallSettings(ctx)
                    _update.update {
                        it.copy(
                            message = Msg(
                                "اسمح بالتثبيت من التطبيق ده، وارجع اضغط تحديث تاني",
                                "Allow installs from this app, come back and tap Update again"
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        downloading = false,
                        message = Msg("فشل تنزيل التحديث: ${e.message}", "Update download failed: ${e.message}")
                    )
                }
            }
        }
    }

    // ---------- حالات واتساب ----------
    private val _statuses = MutableStateFlow<List<StatusItem>>(emptyList())
    val statuses: StateFlow<List<StatusItem>> = _statuses.asStateFlow()
    private val _waLoading = MutableStateFlow(false)
    val waLoading: StateFlow<Boolean> = _waLoading.asStateFlow()
    private val _waError = MutableStateFlow<Msg?>(null)
    val waError: StateFlow<Msg?> = _waError.asStateFlow()

    fun loadStatuses(variant: Int) {
        val uri = if (variant == 0) _settings.value.waUri else _settings.value.wabUri
        if (uri.isBlank()) {
            _statuses.value = emptyList()
            _waError.value = null
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _waLoading.value = true
            try {
                val list = listStatuses(getApplication(), uri)
                _statuses.value = list
                _waError.value = if (list.isEmpty()) Msg(
                    "مفيش حالات هنا. افتح الحالة في واتساب الأول وبعدين اضغط تحديث.",
                    "No statuses found. View a status in WhatsApp first, then tap Refresh."
                ) else null
            } catch (e: Exception) {
                _statuses.value = emptyList()
                _waError.value = Msg(
                    "تعذر قراءة المجلد، اختار المجلد تاني.",
                    "Couldn't read the folder, please choose it again."
                )
            }
            _waLoading.value = false
        }
    }

    fun saveStatus(item: StatusItem, onDone: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = try {
                saveStatusToGallery(getApplication(), item)
            } catch (e: Exception) {
                false
            }
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    init {
        checkUpdate(false)
    }
}
