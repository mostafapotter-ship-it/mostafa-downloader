package com.mostafa.downloader

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

data class DlOptions(
    val mode: Int = 0,
    val quality: Int = 0,
    val audioFmt: String = "mp3-320",
    val imageFmt: String = "jpg",
    /** جودة محددة من المعاينة (format_id)؛ فاضي = حسب quality */
    val formatId: String = "",
    val muxed: Boolean = false,
    /** قص جزء: بداية/نهاية (فاضي = من الأول / لحد الآخر) */
    val clipStart: String = "",
    val clipEnd: String = "",
    val clipPrecise: Boolean = false,
    /** ترجمة تلقائية للكلام: 0 بدون • 1 حرق الترجمة في الصورة • 2 مسار ترجمة + ملف SRT */
    val aiTrans: Int = 0,
    /** ضغط الفيديو لحجم صغير للمشاركة */
    val compress: Boolean = false
) {
    val hasClip: Boolean
        get() = mode != 2 &&
            (clipStart.isNotBlank() || clipEnd.isNotBlank())
}

const val ST_WAIT = 0
const val ST_RUN = 1
const val ST_DONE = 2
const val ST_FAIL = 3
const val ST_CANCEL = 4

/** عنصر في طابور التحميل */
data class QItem(
    val id: Long,
    val url: String,
    val opts: DlOptions,
    val status: Int = ST_WAIT,
    val progress: Float = 0f,
    val detail: String = "",
    val error: Msg? = null
)

data class UiState(
    val ready: Boolean = false,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val message: Msg = Msg("جاري تجهيز المحرك...", "Preparing the engine..."),
    val isError: Boolean = false,
    val detail: String = ""
)

data class UpdateUi(
    val checking: Boolean = false,
    val available: Updater.Release? = null,
    val downloading: Boolean = false,
    val progress: Float = 0f,
    val message: Msg? = null
)

class DownloaderViewModel(app: Application) : AndroidViewModel(app) {

    // ---------- الإعدادات ----------
    private val settingsStore = SettingsStore(app)
    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun saveSettings(s: AppSettings) {
        _settings.value = s
        settingsStore.save(s)
    }

    fun setLang(lang: String) = saveSettings(_settings.value.copy(lang = lang))
    fun setTheme(theme: String) = saveSettings(_settings.value.copy(theme = theme))
    fun setAccent(accent: String) = saveSettings(_settings.value.copy(accent = accent))
    fun setAutoShare(v: Boolean) = saveSettings(_settings.value.copy(autoShare = v))
    fun setWifiOnly(v: Boolean) = saveSettings(_settings.value.copy(wifiOnly = v))
    fun setFastEngine(v: Boolean) = saveSettings(_settings.value.copy(fastEngine = v))
    fun setClipSuggest(v: Boolean) = saveSettings(_settings.value.copy(clipSuggest = v))
    fun setGroqKey(v: String) = saveSettings(_settings.value.copy(groqKey = v))
    fun setSaveUri(v: String) = saveSettings(_settings.value.copy(saveUri = v))
    fun setOnboarded(v: Boolean) = saveSettings(_settings.value.copy(onboarded = v))

    // ---------- الإحصائيات ----------
    private val statsStore = StatsStore(app)
    private val _stats = MutableStateFlow(statsStore.load())
    val stats: StateFlow<StatsData> = _stats.asStateFlow()
    fun resetStats() { _stats.value = statsStore.reset() }

    private val _aiTest = MutableStateFlow<String?>(null)
    val aiTest: StateFlow<String?> = _aiTest.asStateFlow()
    fun runAiTest() {
        _aiTest.value = "..."
        viewModelScope.launch(Dispatchers.IO) {
            _aiTest.value = try {
                AiTrans.selfTest(getApplication<Application>(), _settings.value.groqKey)
            } catch (e: Exception) {
                "❌ ${e.message}"
            }
        }
    }

    /** true لو الاتصال الحالي واي فاي أو إيثرنت */
    private fun onWifi(): Boolean {
        return try {
            val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> !cm.isActiveNetworkMetered
                else -> false
            }
        } catch (e: Exception) {
            true
        }
    }
    fun setWaUri(variant: Int, uri: String) {
        val s = _settings.value
        saveSettings(if (variant == 0) s.copy(waUri = uri) else s.copy(wabUri = uri))
    }

    // ---------- التحميل ----------
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val store = HistoryStore(app)
    private val _history = MutableStateFlow(store.load())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    // ---------- معاينة الرابط ----------
    private val _preview = MutableStateFlow(PreviewState())
    val preview: StateFlow<PreviewState> = _preview.asStateFlow()
    private var previewJob: Job? = null
    private val previewCache = object : LinkedHashMap<String, Pair<Long, PreviewInfo>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, PreviewInfo>>?): Boolean = size > 20
    }

    fun clearPreview() {
        previewJob?.cancel()
        try {
            YoutubeDL.getInstance().destroyProcessById("preview")
        } catch (e: Exception) {
        }
        _preview.value = PreviewState()
    }

    /** يجيب العنوان والصورة والمدة والجودات (بأحجامها) واللغات المتاحة من غير ما ينزّل الفيديو */
    fun loadPreview(raw: String) {
        if (!_state.value.ready) return
        val url = extractUrl(raw) ?: run {
            _preview.value = PreviewState(error = Msg("الرابط غير صحيح", "Invalid link"))
            return
        }
        previewJob?.cancel()
        try {
            YoutubeDL.getInstance().destroyProcessById("preview")
        } catch (e: Exception) {
        }
        // لو الرابط اتعاين من شوية: نعرضه فوراً من الذاكرة
        synchronized(previewCache) { previewCache[url] }?.let { (t, cached) ->
            if (System.currentTimeMillis() - t < 30 * 60 * 1000L) {
                _preview.value = PreviewState(url = url, data = cached)
                return
            }
        }
        _preview.value = PreviewState(loading = true, url = url)
        val ctx = getApplication<Application>()
        previewJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val req = YoutubeDLRequest(url)
                req.addOption("-J")
                req.addOption("--no-playlist")
                req.addOption("--no-warnings")
                req.addOption("--socket-timeout", "8")
                req.addOption("--force-ipv4")
                // تسريع المعاينة: من غير جلب قوائم HLS والترجمات المترجمة (مش محتاجينها هنا)
                req.addOption("--extractor-args", "youtube:skip=hls,translated_subs")
                req.addOption("--extractor-retries", "1")
                req.addOption("--retries", "2")
                val site = CookieStore.siteOfUrl(url)
                if (site != null && CookieStore.isLoggedIn(ctx, site)) {
                    req.addOption("--cookies", CookieStore.file(ctx, site).absolutePath)
                }
                val resp = YoutubeDL.getInstance().execute(req, "preview", null)
                val info = PreviewParser.parse(resp.out, url)
                if (!isActive) return@launch
                synchronized(previewCache) { previewCache[url] = System.currentTimeMillis() to info }
                _preview.value = PreviewState(url = url, data = info)
            } catch (e: Exception) {
                if (!isActive) return@launch
                val m = cleanError(e.message).ifEmpty { e.message ?: "" }
                _preview.value = PreviewState(
                    url = url,
                    error = Msg(
                        "المعاينة مش متاحة للرابط ده — تقدر تحمّله مباشرة.\n" + m.take(160),
                        "Preview isn't available for this link — you can still download it.\n" + m.take(160)
                    )
                )
            }
        }
    }

    // ---------- تحميل قائمة / حساب كامل ----------
    private val _list = MutableStateFlow(ListUi())
    val list: StateFlow<ListUi> = _list.asStateFlow()
    private var listJob: Job? = null

    fun isListLink(url: String): Boolean = PlaylistParser.isListLink(url)

    fun clearList() {
        listJob?.cancel()
        try {
            YoutubeDL.getInstance().destroyProcessById("list")
        } catch (e: Exception) {
        }
        _list.value = ListUi()
    }

    /** يجيب روابط فيديوهات القائمة/الحساب (بدون تحميل) */
    fun loadList(raw: String) {
        if (!_state.value.ready) return
        val url = extractUrl(raw) ?: return
        listJob?.cancel()
        try {
            YoutubeDL.getInstance().destroyProcessById("list")
        } catch (e: Exception) {
        }
        _list.value = ListUi(loading = true, url = url)
        val ctx = getApplication<Application>()
        listJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val req = YoutubeDLRequest(PlaylistParser.normalize(url))
                req.addOption("-J")
                req.addOption("--flat-playlist")
                req.addOption("--playlist-end", LIST_MAX.toString())
                req.addOption("--no-warnings")
                req.addOption("--socket-timeout", "10")
                req.addOption("--force-ipv4")
                val site = CookieStore.siteOfUrl(url)
                if (site != null && CookieStore.isLoggedIn(ctx, site)) {
                    req.addOption("--cookies", CookieStore.file(ctx, site).absolutePath)
                }
                val resp = YoutubeDL.getInstance().execute(req, "list", null)
                val r = PlaylistParser.parse(resp.out)
                if (!isActive) return@launch
                _list.value = if (r.urls.isEmpty()) {
                    ListUi(
                        url = url,
                        error = Msg("مفيش فيديوهات اتلقت في الرابط ده (ممكن يحتاج تسجيل دخول)", "No videos found in this link (it may need sign-in)")
                    )
                } else {
                    ListUi(url = url, title = r.title, urls = r.urls)
                }
            } catch (e: Exception) {
                if (!isActive) return@launch
                val m = cleanError(e.message).ifEmpty { e.message ?: "" }
                _list.value = ListUi(
                    url = url,
                    error = Msg("مقدرتش أجيب القائمة.\n" + m.take(160), "Couldn't load the list.\n" + m.take(160))
                )
            }
        }
    }

    /** يضيف أول [count] فيديو من القائمة المحمّلة للطابور بنفس الخيارات */
    fun downloadList(count: Int, opts: DlOptions) {
        val urls = _list.value.urls.take(count)
        if (urls.isEmpty()) return
        download(urls.joinToString("\n"), opts, limit = LIST_MAX)
    }

    /** يتحقق من أوقات القص ومن توافق الخيارات. بيرجع رسالة خطأ أو null */
    private fun validateOptions(o: DlOptions): Msg? {
        if (o.hasClip) {
            val s = if (o.clipStart.isBlank()) 0.0 else ClipTime.parse(o.clipStart)
            val e = if (o.clipEnd.isBlank()) null else (ClipTime.parse(o.clipEnd) ?: -1.0)
            if (s == null || (e != null && e < 0)) {
                return Msg(
                    "وقت القص غير صحيح — اكتبه بالشكل 1:30 أو 0:01:30",
                    "Invalid trim time — use a format like 1:30 or 0:01:30"
                )
            }
            if (e != null && e - s < 1.0) {
                return Msg("نهاية القص لازم تكون بعد البداية", "The trim end must be after the start")
            }
        }
        if (o.mode == 0 && o.aiTrans > 0 && _settings.value.groqKey.isBlank()) {
            return Msg(
                "ضيف مفتاح Groq المجاني من الإعدادات الأول عشان الترجمة التلقائية تشتغل",
                "Add your free Groq API key in Settings first to use auto-translation"
            )
        }
        return null
    }

    // ---------- الطابور ----------
    private val queueStore = QueueStore(app)
    private val _queue = MutableStateFlow(queueStore.load())
    val queue: StateFlow<List<QItem>> = _queue.asStateFlow()
    private val qLock = Any()
    private var workerActive = false
    private val nextId = java.util.concurrent.atomic.AtomicLong((_queue.value.maxOfOrNull { it.id } ?: 0L) + 1)
    private val cancelledIds: MutableSet<Long> = java.util.Collections.synchronizedSet(HashSet<Long>())
    @Volatile private var engineUpdating = false
    @Volatile private var aria2Ready = false

    private fun updItem(id: Long, f: (QItem) -> QItem) {
        _queue.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    init {
        // نحفظ الطابور كل ما يتغير (إضافة/حالة/إلغاء) — من غير ما نحفظ مع كل نسبة تقدم
        viewModelScope.launch(Dispatchers.IO) {
            // نمسح مجلدات التحميل المؤقتة اللي مالهاش عنصر في الطابور
            try {
                val keep = _queue.value.filter { it.status != ST_DONE }.map { it.id.toString() }.toSet()
                File(app.cacheDir, "dl").listFiles()?.forEach { if (it.name !in keep) it.deleteRecursively() }
            } catch (e: Exception) {
            }
            _queue.map { l -> l.map { it.id to it.status } }
                .distinctUntilChanged()
                .collect { queueStore.save(_queue.value) }
        }
    }

    private val _engineMsg = MutableStateFlow<Msg?>(null)
    val engineMsg: StateFlow<Msg?> = _engineMsg.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                try {
                    aria2Ready = initAria2(app)
                } catch (e: Throwable) {
                    aria2Ready = false // نكمل بالتحميل العادي
                }
                _state.update {
                    it.copy(ready = true, message = Msg("جاهز — الصق الرابط وابدأ", "Ready — paste a link to start"))
                }
                // نستنى التحديث التلقائي للمحرك (بحد أقصى دقيقة) وبعدين نكمل الطابور المحفوظ
                withTimeoutOrNull(60_000L) { autoUpdateEngine()?.join() }
                resumeQueue()
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        message = Msg("فشل تجهيز المحرك: ${e.message}", "Engine setup failed: ${e.message}"),
                        isError = true
                    )
                }
            }
        }
    }

    fun extractUrl(text: String): String? = Regex("https?://\\S+").find(text)?.value

    /** تحديث المحرك تلقائياً عند فتح التطبيق (لو عدّى 12 ساعة) من غير تدخل المستخدم */
    private fun autoUpdateEngine(): Job? {
        val app = getApplication<Application>()
        if (!EngineUpdater.isStale(app)) return null
        engineUpdating = true
        return AppScope.io.launch {
            _engineMsg.value = Msg("جاري تحديث المحرك تلقائياً...", "Updating the engine automatically...")
            val ok = EngineUpdater.update(app)
            _engineMsg.value = if (ok) Msg("المحرك محدّث ✓", "Engine is up to date ✓")
            else Msg("تعذر التحديث التلقائي للمحرك", "Automatic engine update failed")
            engineUpdating = false
        }
    }

    /** aria2c اختياري عن طريق reflection: لو مش متاح بنكمل بالتحميل العادي */
    private fun initAria2(app: Application): Boolean = try {
        val c = Class.forName("com.yausername.aria2c.Aria2c")
        val inst = c.getMethod("getInstance").invoke(null)
        c.getMethod("init", Context::class.java).invoke(inst, app)
        true
    } catch (e: Throwable) {
        false
    }

    private val aria2Re = Regex(
        "\\[#\\w+\\s+([0-9.]+)\\s*([KMGT]?i?B)/([0-9.]+)\\s*([KMGT]?i?B)\\((\\d+)%\\)" +
            "(?:.*?DL:([0-9.]+)\\s*([KMGT]?i?B))?(?:.*?ETA:([0-9hms]+))?"
    )

    /** يقرأ سطر تقدّم aria2c ويرجع النسبة + التفاصيل (الحجم • السرعة • الوقت المتبقي) */
    private fun aria2Progress(line: String?): Pair<Float, String>? {
        if (line.isNullOrEmpty()) return null
        val m = aria2Re.find(line) ?: return null
        val g = m.groupValues
        val done = toBytes(g[1].toDoubleOrNull() ?: return null, g[2])
        val total = toBytes(g[3].toDoubleOrNull() ?: return null, g[4])
        val pct = g[5].toFloatOrNull() ?: return null
        val parts = ArrayList<String>()
        parts.add(fmtBytes(done) + " / " + fmtBytes(total))
        if (g[6].isNotEmpty()) {
            val v = g[6].toDoubleOrNull()
            if (v != null) parts.add(fmtBytes(toBytes(v, g[7])) + "/s")
        }
        if (g[8].isNotEmpty()) parts.add("ETA " + g[8])
        return pct to parts.joinToString("  •  ")
    }

    private val sizeRe = Regex("of\\s+~?\\s*([0-9.]+)\\s*([KMGT]?i?B)")
    private val speedRe = Regex("at\\s+([0-9.]+)\\s*([KMGT]?i?B)/s")
    private val etaRe = Regex("ETA\\s+([0-9:]+)")

    private fun toBytes(v: Double, unit: String): Double = when (unit.uppercase(Locale.US)) {
        "KIB" -> v * 1024.0
        "MIB" -> v * 1048576.0
        "GIB" -> v * 1073741824.0
        "KB" -> v * 1000.0
        "MB" -> v * 1000000.0
        "GB" -> v * 1000000000.0
        else -> v
    }

    private fun fmtBytes(b: Double): String = when {
        b >= 1073741824.0 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1048576.0 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1024.0 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
        else -> "${b.toInt()} B"
    }

    /** يطلّع من سطر yt-dlp: الحجم المنزّل / الإجمالي • السرعة • الوقت المتبقي */
    private fun progressDetail(line: String?, pct: Float): String? {
        if (line.isNullOrEmpty()) return null
        val sm = sizeRe.find(line) ?: return null
        val totalValue = sm.groupValues[1].toDoubleOrNull() ?: return null
        val total = toBytes(totalValue, sm.groupValues[2])
        val parts = ArrayList<String>()
        parts.add(fmtBytes(total * pct / 100.0) + " / " + fmtBytes(total))
        speedRe.find(line)?.let { m ->
            val v = m.groupValues[1].toDoubleOrNull()
            if (v != null) parts.add(fmtBytes(toBytes(v, m.groupValues[2])) + "/s")
        }
        etaRe.find(line)?.let { parts.add("ETA " + it.groupValues[1]) }
        return parts.joinToString("  •  ")
    }

    fun extractUrls(text: String): List<String> =
        Regex("https?://\\S+").findAll(text)
            .map { it.value.trimEnd(',', ';', ')') }
            .distinct().toList()

    /** للتوافق: فيديو/صوت بسيط */
    fun download(rawInput: String, audioOnly: Boolean, quality: Int) =
        download(rawInput, DlOptions(mode = if (audioOnly) 1 else 0, quality = quality))

    /** يضيف رابط أو أكتر للطابور بالخيارات المحددة */
    fun download(rawInput: String, opts: DlOptions, limit: Int = 20) {
        val s = _state.value
        if (!s.ready) return
        if (engineUpdating) {
            _state.update {
                it.copy(message = Msg("استنى لحد ما يخلص تحديث المحرك", "Wait until the engine update finishes"), isError = true)
            }
            return
        }
        val urls = extractUrls(rawInput).take(limit)
        if (urls.isEmpty()) {
            _state.update { it.copy(message = Msg("الرابط غير صحيح", "Invalid link"), isError = true) }
            return
        }
        if (_settings.value.wifiOnly && !onWifi()) {
            _state.update {
                it.copy(
                    message = Msg(
                        "التحميل على الواي فاي بس مفعّل — اتصل بواي فاي أو أوقف الإعداد من الإعدادات",
                        "Wi-Fi only is on — connect to Wi-Fi or turn it off in Settings"
                    ),
                    isError = true
                )
            }
            return
        }
        validateOptions(opts)?.let { err ->
            _state.update { it.copy(message = err, isError = true) }
            return
        }
        val items = synchronized(qLock) {
            val active = _queue.value.filter { it.status == ST_WAIT || it.status == ST_RUN }.map { it.url }.toSet()
            val fresh = urls.filter { it !in active }.map { QItem(nextId.getAndIncrement(), it, opts) }
            if (fresh.isNotEmpty()) {
                // نحتفظ بآخر 30 عنصر منتهي بس عشان القائمة ما تكبرش
                val keep = _queue.value.filter { it.status == ST_WAIT || it.status == ST_RUN }
                val done = _queue.value.filter { it.status >= ST_DONE }.takeLast(30)
                _queue.value = (done + keep + fresh).sortedBy { it.id }
            }
            fresh
        }
        if (items.isEmpty()) {
            _state.update {
                it.copy(message = Msg("الرابط ده موجود في الطابور بالفعل", "This link is already in the queue"), isError = true)
            }
            return
        }
        if (!_state.value.busy) {
            _state.update { it.copy(message = Msg("جاري التحميل...", "Downloading..."), isError = false) }
        }
        ensureWorker()
    }

    private fun ensureWorker() {
        synchronized(qLock) {
            if (workerActive) return
            workerActive = true
        }
        val ctx = getApplication<Application>()
        Notifier.ensureChannels(ctx)
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (e: Exception) {
        }
        AppScope.io.launch {
            try {
                while (true) {
                    val next = synchronized(qLock) {
                        val n = _queue.value.firstOrNull { it.status == ST_WAIT }
                        if (n == null) {
                            workerActive = false
                        } else {
                            _queue.value = _queue.value.map {
                                if (it.id == n.id) it.copy(status = ST_RUN, progress = 0f, detail = "", error = null) else it
                            }
                        }
                        n
                    } ?: break
                    _state.value = UiState(ready = true, busy = true, message = Msg("جاري التحميل...", "Downloading..."))
                    runOne(ctx, next)
                }
                if (!TransRuntime.busy) {
                    try {
                        ctx.stopService(Intent(ctx, DownloadService::class.java))
                    } catch (e: Exception) {
                    }
                }
            } catch (t: Throwable) {
                synchronized(qLock) { workerActive = false }
            }
        }
    }

    /** يكمل العناصر المنتظرة (بعد فتح التطبيق أو بعد ما تتصل بواي فاي) */
    fun resumeQueue() {
        if (!_state.value.ready || engineUpdating) return
        if (_queue.value.none { it.status == ST_WAIT }) return
        if (_settings.value.wifiOnly && !onWifi()) {
            _state.update {
                it.copy(
                    message = Msg(
                        "في تحميلات مستنية — اتصل بواي فاي وداس استكمال",
                        "Downloads are waiting — connect to Wi-Fi and tap Resume"
                    ),
                    isError = false
                )
            }
            return
        }
        _state.update {
            it.copy(message = Msg("جاري استكمال التحميلات المحفوظة...", "Resuming saved downloads..."), isError = false)
        }
        ensureWorker()
    }

    /** إلغاء عنصر: لو منتظر بيتشال، ولو شغال بنقتل عملية التحميل */
    fun cancelItem(id: Long) {
        var wasRunning = false
        synchronized(qLock) {
            _queue.value = _queue.value.map {
                if (it.id != id) it
                else when (it.status) {
                    ST_WAIT -> it.copy(status = ST_CANCEL)
                    ST_RUN -> { wasRunning = true; it }
                    else -> it
                }
            }
        }
        if (wasRunning) {
            cancelledIds.add(id)
            try {
                YoutubeDL.getInstance().destroyProcessById("q$id")
            } catch (e: Exception) {
            }
        }
    }

    fun cancelCurrent() {
        _queue.value.firstOrNull { it.status == ST_RUN }?.let { cancelItem(it.id) }
    }

    fun cancelAll() {
        _queue.value.filter { it.status == ST_WAIT || it.status == ST_RUN }.forEach { cancelItem(it.id) }
    }

    fun retryItem(id: Long) {
        if (!_state.value.ready || engineUpdating) return
        synchronized(qLock) {
            _queue.value = _queue.value.map {
                if (it.id == id && (it.status == ST_FAIL || it.status == ST_CANCEL))
                    it.copy(status = ST_WAIT, progress = 0f, detail = "", error = null)
                else it
            }
        }
        ensureWorker()
    }

    fun removeItem(id: Long) {
        synchronized(qLock) {
            _queue.value = _queue.value.filter { !(it.id == id && it.status >= ST_DONE) }
        }
    }

    fun clearFinished() {
        synchronized(qLock) {
            _queue.value = _queue.value.filter { it.status < ST_DONE }
        }
    }

    private suspend fun runOne(ctx: Application, item: QItem): Boolean {
            val url = item.url
            val opts = item.opts
            // مجلد مؤقت لكل عنصر ومبيتمسحش في البداية، عشان لو التطبيق اتقفل نكمل من الجزء المحمّل
            val tmp = File(ctx.cacheDir, "dl/${item.id}").apply { mkdirs() }
            val site = CookieStore.siteOfUrl(url)
            var lastPct = -1
            val tStart = System.currentTimeMillis()
            var tFirst = 0L
            try {
                val req = YoutubeDLRequest(url)
                val outName = if ("/stories/" in url) "%(uploader|story)s_%(id)s.%(ext)s" else "%(title).80s.%(ext)s"
                req.addOption("-o", "${tmp.absolutePath}/$outName")
                if ("/highlights/" !in url) req.addOption("--no-playlist")
                // تسريع: تحميل أجزاء الفيديو بالتوازي + إعادة المحاولة عند ضعف الشبكة
                req.addOption("-N", "4")
                req.addOption("--retries", "10")
                req.addOption("--fragment-retries", "10")
                req.addOption("--socket-timeout", "10")
                // يمنع التأخير (~20 ثانية) لما الـ IPv6 يعلّق قبل ما يرجع لـ IPv4
                req.addOption("--force-ipv4")
                // الملفات المباشرة: aria2c بـ 16 اتصال (التقسيم والتحميل المتوازي)
                val useAria = aria2Ready && _settings.value.fastEngine
                if (useAria) {
                    req.addOption("--downloader", "libaria2c.so")
                    req.addOption(
                        "--external-downloader-args",
                        "aria2c:--summary-interval=1 --file-allocation=none --http-accept-gzip=true " +
                            "--async-dns=false --disable-ipv6=true --connect-timeout=10 " +
                            "-x16 -j16 -s16 -k1M"
                    )
                }
                if (site != null && CookieStore.isLoggedIn(ctx, site)) {
                    req.addOption("--cookies", CookieStore.file(ctx, site).absolutePath)
                }
                when (opts.mode) {
                    1 -> {
                        req.addOption("-f", "bestaudio/best")
                        req.addOption("-x")
                        when (opts.audioFmt) {
                            "mp3-128" -> {
                                req.addOption("--audio-format", "mp3")
                                req.addOption("--audio-quality", "128K")
                            }
                            "m4a" -> req.addOption("--audio-format", "m4a")
                            "wav" -> req.addOption("--audio-format", "wav")
                            else -> {
                                req.addOption("--audio-format", "mp3")
                                req.addOption("--audio-quality", "320K")
                            }
                        }
                    }
                    2 -> {
                        req.addOption("--skip-download")
                        req.addOption("--write-thumbnail")
                        req.addOption("--convert-thumbnails", opts.imageFmt)
                    }
                    else -> {
                        if (opts.formatId.isNotEmpty()) {
                            // جودة محددة من المعاينة (لو الصيغة منفصلة عن الصوت بنضيف أفضل صوت)
                            val f = opts.formatId
                            req.addOption(
                                "-f",
                                if (opts.muxed) "$f/b" else "$f+ba[ext=m4a]/$f+ba/$f/b"
                            )
                        } else {
                            val h = if (opts.quality > 0) "[height<=${opts.quality}]" else ""
                            // لو مفيش جودة أقل من أو تساوي المطلوبة، ناخد أقل جودة متاحة (مش أعلى واحدة)
                            val fallback = if (opts.quality > 0) "w" else "b"
                            req.addOption("-f", "bv*$h[ext=mp4]+ba[ext=m4a]/bv*$h+ba/b$h/$fallback")
                        }
                        req.addOption("--merge-output-format", "mp4")
                    }
                }

                // --- قص جزء من الفيديو (بيتحمّل الجزء ده بس عن طريق ffmpeg) ---
                val clipS = if (opts.clipStart.isBlank()) 0.0 else ClipTime.parse(opts.clipStart)
                val clipE = if (opts.clipEnd.isBlank()) null else ClipTime.parse(opts.clipEnd)
                if (opts.hasClip && clipS != null) {
                    req.addOption(
                        "--download-sections",
                        "*${ClipTime.fmt(clipS)}-${if (clipE != null) ClipTime.fmt(clipE) else "inf"}"
                    )
                    if (opts.clipPrecise) req.addOption("--force-keyframes-at-cuts")
                }
                val igDirect = site == "ig" && "/stories/" in url && CookieStore.isLoggedIn(ctx, "ig")
                if (igDirect) {
                    _state.update {
                        it.copy(message = Msg("جاري تحميل استوري إنستجرام...", "Fetching the Instagram story..."))
                    }
                    IgStory.download(ctx, url, tmp)
                } else {
                try {
                    val onProg: (Float, Long, String?) -> Unit = { progress, _, line ->
                        if (tFirst == 0L) tFirst = System.currentTimeMillis()
                        val a2 = aria2Progress(line)
                        val p = (a2?.first ?: progress).coerceIn(0f, 100f)
                        val detail = a2?.second ?: progressDetail(line, p)
                        _state.update { it.copy(progress = p / 100f, detail = detail ?: it.detail) }
                        updItem(item.id) { it.copy(progress = p / 100f, detail = detail ?: it.detail) }
                        val pct = p.toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            Notifier.progress(ctx, pct, detail ?: "")
                        }
                    }
                    try {
                        YoutubeDL.getInstance().execute(req, "q${item.id}", onProg)
                    } catch (e: Exception) {
                        // لو aria2c فشل لأي سبب نعيد المحاولة بالمحرك العادي
                        val m = e.message ?: ""
                        val aria2Problem = useAria && item.id !in cancelledIds && (m.contains("aria2", true) ||
                            m.contains("external downloader", true) || m.contains("exited with", true))
                        if (aria2Problem) {
                            tmp.listFiles()?.forEach { it.delete() }
                            lastPct = -1
                            req.addOption("--downloader", "native")
                            YoutubeDL.getInstance().execute(req, "q${item.id}", onProg)
                        } else if (item.id !in cancelledIds && EngineUpdater.looksLikeSiteChange(m) &&
                            EngineUpdater.canRetryNow(ctx)
                        ) {
                            // الموقع غالباً غيّر نفسه: نحدّث المحرك ونعيد المحاولة مرة واحدة تلقائياً
                            val msg = Msg("جاري تحديث المحرك وإعادة المحاولة...", "Updating the engine and retrying...")
                            _state.update { it.copy(message = msg) }
                            updItem(item.id) { it.copy(detail = msg.get(_settings.value.lang == "ar")) }
                            if (!EngineUpdater.update(ctx)) throw e
                            tmp.listFiles()?.forEach { it.delete() }
                            lastPct = -1
                            YoutubeDL.getInstance().execute(req, "q${item.id}", onProg)
                        } else {
                            throw e
                        }
                    }
                } catch (e: Exception) {
                    val em = e.message ?: ""
                    if (site == "fb" && CookieStore.isLoggedIn(ctx, "fb") && em.contains("Unsupported URL", true)) {
                        val resolved = Regex("Unsupported URL: (\\S+)").find(em)?.groupValues?.get(1)
                        _state.update {
                            it.copy(message = Msg("جاري محاولة فيسبوك البديلة...", "Trying the Facebook fallback..."))
                        }
                        FbStory.download(ctx, listOfNotNull(resolved, url).distinct(), tmp)
                    } else if (site == "ig" && CookieStore.isLoggedIn(ctx, "ig") && "/stories/" in url &&
                        (em.contains("log in", true) || em.contains("login", true) ||
                            em.contains("unable to extract user info", true) ||
                            em.contains("empty media response", true))
                    ) {
                        _state.update {
                            it.copy(message = Msg("جاري محاولة إنستجرام البديلة...", "Trying the Instagram fallback..."))
                        }
                        IgStory.download(ctx, url, tmp)
                    } else if ("snapchat.com" in url.lowercase() && opts.mode != 1) {
                        _state.update {
                            it.copy(message = Msg("جاري محاولة سناب شات البديلة...", "Trying the Snapchat fallback..."))
                        }
                        val resolved = Regex("Unsupported URL: (\\S+)").find(em)?.groupValues?.get(1)
                        val cands = listOfNotNull(resolved, url).distinct()
                        try {
                            val spot = cands.firstOrNull { "/spotlight/" in it }
                            if (spot != null) {
                                try {
                                    SnapSpotlight.download(spot, tmp, opts.mode)
                                } catch (e3: Exception) {
                                    SnapStory.download(ctx, cands, tmp)
                                }
                            } else {
                                SnapStory.download(ctx, cands, tmp)
                            }
                        } catch (e2: Exception) {
                            throw IllegalStateException((e2.message ?: "Snapchat fallback failed") + "\n" + em.take(160))
                        }
                    } else {
                        throw e
                    }
                }
                }
                if (item.id in cancelledIds) throw IllegalStateException("cancelled")
                // --- ترجمة تلقائية للكلام ودمجها في الفيديو ---
                var aiNote: Msg? = null
                var aiDone = false
                if (opts.mode == 0 && opts.aiTrans > 0) {
                    val vid = tmp.listFiles()
                        ?.filter { it.isFile && it.length() > 0 && it.extension.lowercase(Locale.US) in setOf("mp4", "m4v", "mov", "mkv", "webm") }
                        ?.maxByOrNull { it.length() }
                    if (vid != null) {
                        try {
                            val r = AiTrans.run(
                                ctx, vid, _settings.value.groqKey.trim(), opts.aiTrans == 2, opts.aiTrans == 1,
                                fetchAudio = { dir ->
                                    try {
                                        val ar = YoutubeDLRequest(url)
                                        ar.addOption("-o", "${dir.absolutePath}/audio.%(ext)s")
                                        ar.addOption("--no-playlist")
                                        ar.addOption("--force-ipv4")
                                        ar.addOption("-f", "bestaudio/best")
                                        ar.addOption("-x")
                                        ar.addOption("--audio-format", "mp3")
                                        ar.addOption("--audio-quality", "32K")
                                        if (site != null && CookieStore.isLoggedIn(ctx, site)) {
                                            ar.addOption("--cookies", CookieStore.file(ctx, site).absolutePath)
                                        }
                                        if (opts.hasClip && clipS != null) {
                                            ar.addOption(
                                                "--download-sections",
                                                "*${ClipTime.fmt(clipS)}-${if (clipE != null) ClipTime.fmt(clipE) else "inf"}"
                                            )
                                        }
                                        YoutubeDL.getInstance().execute(ar, "ai${item.id}", null)
                                        dir.listFiles()?.firstOrNull { it.extension.equals("mp3", true) }
                                    } catch (e: Exception) {
                                        null
                                    }
                                },
                                onStage = { m ->
                                    val txt = m.get(_settings.value.lang == "ar")
                                    _state.update { it.copy(message = m, progress = 0.97f, detail = "") }
                                    updItem(item.id) { it.copy(progress = 0.97f, detail = txt) }
                                    Notifier.progress(ctx, 99, txt)
                                },
                                cancelled = { item.id in cancelledIds }
                            )
                            aiNote = r.note
                            aiDone = true
                        } catch (e: Exception) {
                            if (item.id in cancelledIds || e is kotlinx.coroutines.CancellationException) throw e
                            val reason = (e as? AiTransException)?.msg
                                ?: Msg(e.message ?: "error", e.message ?: "error")
                            aiNote = Msg(
                                "⚠ الفيديو اتحمّل بس الترجمة التلقائية فشلت: ${reason.ar}",
                                "⚠ The video was saved but auto-translation failed: ${reason.en}"
                            )
                        }
                    }
                }
                // --- ضغط الفيديو لحجم صغير (اختياري) ---
                var compressNote: Msg? = null
                if (opts.mode == 0 && opts.compress) {
                    val vid = tmp.listFiles()
                        ?.filter { it.isFile && it.length() > 0 && it.extension.lowercase(Locale.US) in setOf("mp4", "m4v", "mov", "mkv", "webm") }
                        ?.maxByOrNull { it.length() }
                    if (vid != null) {
                        val r = try {
                            VideoCompress.run(ctx, vid, opts.aiTrans == 2 && aiDone) { p ->
                                val txt = if (_settings.value.lang == "ar") "بضغط الفيديو… $p%" else "Compressing video… $p%"
                                updItem(item.id) { it.copy(progress = 0.97f, detail = txt) }
                                Notifier.progress(ctx, 99, txt)
                            }
                        } catch (e: Exception) {
                            null
                        }
                        compressNote = if (r != null) Msg(
                            "📦 اتضغط الفيديو ووفّر ${r.second}% من الحجم",
                            "📦 Video compressed, saved ${r.second}% of the size"
                        ) else Msg(
                            "ℹ الفيديو اتحفظ بحجمه الأصلي (الضغط ما وفّرش حجم)",
                            "ℹ Saved at original size (compression didn't reduce it)"
                        )
                    }
                }
                val files = tmp.listFiles()?.filter { it.isFile && it.length() > 0 }.orEmpty()
                if (files.isEmpty()) {
                    throw IllegalStateException("No output file")
                }

                val label = when (opts.mode) {
                    1 -> when (opts.audioFmt) {
                        "mp3-128" -> "MP3 128kbps"
                        "m4a" -> "M4A"
                        "wav" -> "WAV"
                        else -> "MP3 320kbps"
                    }
                    2 -> opts.imageFmt.uppercase(Locale.US)
                    else -> when {
                        opts.quality == 0 -> "BEST"
                        else -> "${opts.quality}p"
                    }
                }.let { base ->
                    var lb = base
                    if (opts.hasClip) lb += " ✂"
                    if (opts.mode == 0) {
                        if (aiDone) lb += " +AI"
                    }
                    lb
                }
                var firstName = ""
                var firstUri = ""
                var firstMime = ""
                var firstWhere = ""
                val platId = platformOf(url)
                val platName = Platforms.firstOrNull { it.id == platId }?.name ?: "Other"
                val cfg = _settings.value
                val sub = platName
                val qLabel = label.replace("✂", "").trim()
                files.forEach { f ->
                    val base = f.nameWithoutExtension
                    val res = saveToDownloads(ctx, f, base + "." + f.extension, sub)
                    if (firstUri.isEmpty()) {
                        firstName = f.nameWithoutExtension
                        firstUri = res.uri
                        firstMime = res.mime
                        firstWhere = res.where
                    }
                    addHistory(
                        HistoryItem(
                            f.nameWithoutExtension, label,
                            SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date()),
                            res.uri, res.mime, platId ?: "other", f.length()
                        )
                    )
                }
                _stats.value = statsStore.record(platId ?: "other", files.sumOf { it.length() })
                updItem(item.id) { it.copy(status = ST_DONE, progress = 1f, detail = "", error = null) }
                // تشخيص السرعة: وقت التجهيز قبل أول بايت + وقت التحميل + المتوسط
                val tEnd = System.currentTimeMillis()
                val prep = if (tFirst > 0) (tFirst - tStart) / 1000.0 else 0.0
                val dl = ((tEnd - (if (tFirst > 0) tFirst else tStart)) / 1000.0).coerceAtLeast(0.1)
                val bytes = files.sumOf { it.length() }
                val avg = fmtBytes(bytes / dl) + "/s"
                val stats = if (tFirst > 0)
                    String.format(Locale.US, "%.0fs prep • %.0fs download • avg %s", prep, dl, avg)
                else String.format(Locale.US, "%.0fs total", (tEnd - tStart) / 1000.0)
                _state.value = UiState(
                    ready = true,
                    progress = 1f,
                    message = Msg(
                        "تم الحفظ في $firstWhere\n$stats" + (aiNote?.let { "\n" + it.ar } ?: "") + (compressNote?.let { "\n" + it.ar } ?: ""),
                        "Saved to $firstWhere\n$stats" + (aiNote?.let { "\n" + it.en } ?: "") + (compressNote?.let { "\n" + it.en } ?: "")
                    )
                )
                Notifier.done(ctx, firstName, firstUri, firstMime)
                return true
            } catch (e: Exception) {
                if (item.id in cancelledIds) {
                    updItem(item.id) { it.copy(status = ST_CANCEL, detail = "") }
                    _state.value = UiState(ready = true, message = Msg("تم إلغاء التحميل", "Download cancelled"))
                    return false
                }
                val m = cleanError(e.message)
                val loggedIn = CookieStore.isLoggedIn(ctx, site)
                val loginish = m.contains("login", true) || m.contains("cookies", true) ||
                    m.contains("unable to extract user info", true) ||
                    m.contains("instagram:story", true) || m.contains("empty media response", true)
                val msg = when {
                    m.contains("HTTP 429") -> Msg(
                        "إنستجرام بيحدّ الطلبات مؤقتاً (429). استنى فترة وجرّب تاني.\n$m",
                        "Instagram is temporarily rate-limiting requests (429). Wait a while and try again.\n$m"
                    )
                    site != null && !loggedIn && loginish -> Msg(
                        "لازم تسجّل دخول الأول من تبويب الاستوريهات.",
                        "Please sign in first from the Stories tab."
                    )
                    site != null && loggedIn && loginish -> Msg(
                        "فشل التحميل رغم تسجيل الدخول. سجّل خروج ودخول تاني من تبويب الاستوريهات، أو حدّث محرك التحميل من الإعدادات.\n$m",
                        "Download failed even though you're signed in. Sign out and in again from the Stories tab, or update the engine in Settings.\n$m"
                    )
                    else -> Msg("فشل التحميل: $m", "Download failed: $m")
                }
                updItem(item.id) { it.copy(status = ST_FAIL, detail = "", error = msg) }
                _state.value = UiState(ready = true, message = msg, isError = true)
                Notifier.failed(ctx, msg)
                return false
            } finally {
                cancelledIds.remove(item.id)
                tmp.deleteRecursively()
                Notifier.cancelProgress(ctx)
            }
    }

    private fun cleanError(raw: String?): String {
        val m = raw ?: return ""
        val i = m.lastIndexOf("ERROR:")
        return (if (i >= 0) m.substring(i) else m).trim().take(600)
    }

    private fun addHistory(item: HistoryItem) {
        _history.value = (listOf(item) + _history.value).take(100)
        store.save(_history.value)
    }

    /** يحذف عنصر من السجل، ولو deleteFile = true يحذف الملف نفسه من التحميلات */
    fun deleteHistory(item: HistoryItem, deleteFile: Boolean) {
        if (deleteFile) {
            try {
                getApplication<Application>().contentResolver.delete(Uri.parse(item.uri), null, null)
            } catch (e: Exception) {
            }
        }
        _history.value = _history.value.filter { it.uri != item.uri || it.date != item.date }
        store.save(_history.value)
    }

    fun clearHistory() {
        _history.value = emptyList()
        store.save(emptyList())
    }

    fun updateEngine() {
        if (!_state.value.ready || _state.value.busy || engineUpdating) return
        engineUpdating = true
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true) }
            _engineMsg.value = Msg("جاري تحديث المحرك...", "Updating the engine...")
            val ok = EngineUpdater.update(getApplication())
            _engineMsg.value = if (ok) Msg("تم تحديث المحرك", "Engine updated")
            else Msg("فشل تحديث المحرك، تأكد من الاتصال بالإنترنت", "Engine update failed, check your connection")
            engineUpdating = false
            _state.update { it.copy(busy = false) }
        }
    }

    private suspend fun saveToDownloads(ctx: Context, file: File, displayName: String, sub: String?): SaveRes {
        val mime = when (file.extension.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "wav" -> "audio/wav"
            "opus" -> "audio/ogg"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "srt" -> "application/x-subrip"
            "vtt" -> "text/vtt"
            "txt" -> "text/plain"
            else -> "application/octet-stream"
        }
        // مكان حفظ مخصص اختاره المستخدم (لو فشل لأي سبب نرجع للمكان الافتراضي)
        val tree = _settings.value.saveUri
        if (tree.isNotBlank()) {
            try {
                val uri = SaveTree.save(ctx, tree, sub, file, mime, displayName)
                return SaveRes(uri, mime, SaveTree.describe(tree) + (sub?.let { "/$it" } ?: ""))
            } catch (e: Exception) {
            }
        }
        val rel = "MostafaDownloader" + (sub?.let { "/$it" } ?: "")
        val where = "Downloads/$rel"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + rel)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            return SaveRes(uri.toString(), mime, where)
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), rel
            ).apply { mkdirs() }
            var dest = File(dir, displayName)
            var n = 1
            while (dest.exists()) {
                dest = File(dir, displayName.substringBeforeLast('.') + " ($n)." + displayName.substringAfterLast('.', ""))
                n++
            }
            file.copyTo(dest, overwrite = false)
            val uri = suspendCancellableCoroutine<String> { cont ->
                MediaScannerConnection.scanFile(
                    ctx, arrayOf(dest.absolutePath), arrayOf(mime)
                ) { _, u -> cont.resume(u?.toString() ?: "") }
            }
            return SaveRes(uri, mime, where)
        }
    }

    // ---------- تحديث التطبيق ----------
    private val _update = MutableStateFlow(UpdateUi())
    val update: StateFlow<UpdateUi> = _update.asStateFlow()
    private var pendingApk: File? = null

    fun checkUpdate(manual: Boolean) {
        if (_update.value.checking) return
        viewModelScope.launch(Dispatchers.IO) {
            _update.update { it.copy(checking = true, message = null) }
            try {
                val r = Updater.fetchLatest()
                if (r != null && r.versionCode > BuildConfig.VERSION_CODE) {
                    if (_update.value.available?.versionCode != r.versionCode) pendingApk = null
                    _update.update { it.copy(checking = false, available = r) }
                } else {
                    _update.update {
                        it.copy(
                            checking = false,
                            available = null,
                            message = if (!manual) null else if (r == null)
                                Msg("لا توجد إصدارات منشورة بعد", "No published releases yet")
                            else Msg("أنت على آخر إصدار", "You are on the latest version")
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        checking = false,
                        message = if (manual) Msg("تعذر التحقق من التحديثات", "Couldn't check for updates") else null
                    )
                }
            }
        }
    }

    /** للمطوّر: بينزّل آخر نسخة تجريبية (test) ويفتح التثبيت */
    fun updateToTest() {
        if (_update.value.checking || _update.value.downloading) return
        viewModelScope.launch(Dispatchers.IO) {
            _update.update { it.copy(checking = true, message = Msg("بدوّر على آخر نسخة تجريبية...", "Looking for the latest test build...")) }
            try {
                val r = Updater.fetchLatestTest()
                if (r == null) {
                    _update.update { it.copy(checking = false, message = Msg("مفيش نسخة تجريبية منشورة", "No test build is published")) }
                } else if (r.versionCode <= BuildConfig.VERSION_CODE) {
                    _update.update {
                        it.copy(
                            checking = false,
                            message = Msg(
                                "أنت على آخر نسخة تجريبية (v1.0.${r.versionCode})",
                                "You're on the latest test build (v1.0.${r.versionCode})"
                            )
                        )
                    }
                } else {
                    pendingApk = null
                    _update.update { it.copy(checking = false, available = r) }
                    installUpdate()
                }
            } catch (e: Exception) {
                _update.update { it.copy(checking = false, message = Msg("تعذر التحقق من النسخة التجريبية", "Couldn't check for the test build")) }
            }
        }
    }

    fun installUpdate() {
        val r = _update.value.available ?: return
        if (_update.value.downloading) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apk: File = pendingApk?.takeIf { it.exists() } ?: run {
                    _update.update {
                        it.copy(
                            downloading = true, progress = 0f,
                            message = Msg("جاري تجهيز التحديث...", "Preparing the update...")
                        )
                    }
                    Updater.prepare(
                        ctx, r,
                        { p -> _update.update { it.copy(progress = p) } },
                        { delta ->
                            _update.update {
                                it.copy(
                                    progress = 0f,
                                    message = if (delta) Msg(
                                        "جاري تنزيل التحديث (التغييرات فقط)...",
                                        "Downloading the update (changes only)..."
                                    ) else Msg(
                                        "جاري تنزيل التحديث الكامل...",
                                        "Downloading the full update..."
                                    )
                                )
                            }
                        }
                    )
                }
                pendingApk = apk
                _update.update { it.copy(downloading = false) }
                if (Updater.canInstall(ctx)) {
                    Updater.install(ctx, apk)
                    _update.update {
                        it.copy(message = Msg("اضغط \"تثبيت\" في الشاشة اللي ظهرت", "Tap \"Install\" on the screen that appeared"))
                    }
                } else {
                    Updater.openInstallSettings(ctx)
                    _update.update {
                        it.copy(
                            message = Msg(
                                "اسمح بالتثبيت من التطبيق ده، وارجع اضغط تحديث تاني",
                                "Allow installs from this app, come back and tap Update again"
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        downloading = false,
                        message = Msg("فشل تنزيل التحديث: ${e.message}", "Update download failed: ${e.message}")
                    )
                }
            }
        }
    }

    // ---------- حالات واتساب ----------
    private val _statuses = MutableStateFlow<List<StatusItem>>(emptyList())
    val statuses: StateFlow<List<StatusItem>> = _statuses.asStateFlow()
    private val _waLoading = MutableStateFlow(false)
    val waLoading: StateFlow<Boolean> = _waLoading.asStateFlow()
    private val _waError = MutableStateFlow<Msg?>(null)
    val waError: StateFlow<Msg?> = _waError.asStateFlow()

    private var waJob: Job? = null

    /** silent = تحديث تلقائي في الخلفية من غير شريط تحميل */
    fun loadStatuses(variant: Int, silent: Boolean = false) {
        val uri = if (variant == 0) _settings.value.waUri else _settings.value.wabUri
        if (uri.isBlank()) {
            _statuses.value = emptyList()
            _waError.value = null
            return
        }
        if (waJob?.isActive == true) return
        waJob = viewModelScope.launch(Dispatchers.IO) {
            if (!silent) _waLoading.value = true
            try {
                val list = listStatuses(getApplication(), uri)
                _statuses.value = list
                _waError.value = if (list.isEmpty()) Msg(
                    "مفيش حالات هنا لسه. افتح تبويب الحالات في واتساب وهتظهر هنا لوحدها.",
                    "No statuses here yet. Open the Status tab in WhatsApp and they'll appear here automatically."
                ) else null
            } catch (e: Exception) {
                _statuses.value = emptyList()
                _waError.value = Msg(
                    "تعذر قراءة المجلد، اختار المجلد تاني.",
                    "Couldn't read the folder, please choose it again."
                )
            }
            if (!silent) _waLoading.value = false
        }
    }

    fun saveStatus(item: StatusItem, onDone: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = try {
                saveStatusToGallery(getApplication(), item)
            } catch (e: Exception) {
                false
            }
            if (ok) _stats.value = statsStore.record("wa", item.size)
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    // ====================== ترجمة فيديو من الموبايل (ترجمة محروقة) ======================
    data class TransUi(
        val running: Boolean = false,
        val stage: Msg? = null,
        val name: String = "",
        val doneUri: String = "",
        val doneMime: String = "",
        val doneWhere: String = "",
        val note: Msg? = null,
        val error: Msg? = null
    )

    private val _trans = TransRuntime.ui
    val trans: StateFlow<TransUi> = _trans.asStateFlow()
    fun clearTrans() {
        if (!_trans.value.running) _trans.value = TransUi()
    }

    fun cancelTranslate() {
        TransRuntime.cancel = true
        TransRuntime.job?.cancel()
    }

    fun translateLocal(uri: android.net.Uri) {
        if (_trans.value.running) return
        val ctx = getApplication<Application>()
        val key = _settings.value.groqKey.trim()
        if (key.isEmpty()) {
            _trans.value = TransUi(
                error = Msg("ضيف مفتاح Groq المجاني من الإعدادات الأول.", "Add your free Groq key in Settings first.")
            )
            return
        }
        // تنضيف مجلدات مؤقتة قديمة (أكتر من يوم) فضلت من ترجمة اتقطعت
        for (name in listOf("local_tr", "ai_work")) {
            File(ctx.filesDir, name).listFiles()?.forEach {
                if (System.currentTimeMillis() - it.lastModified() > 24 * 60 * 60 * 1000L) it.deleteRecursively()
            }
        }
        TransRuntime.cancel = false
        _trans.value = TransUi(running = true, stage = Msg("جاري تجهيز الفيديو...", "Preparing the video..."))
        Notifier.ensureChannels(ctx)
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (e: Exception) {
        }
        // بيشتغل في نطاق التطبيق (مش الشاشة) + قفل تشغيل جزئي عشان يكمّل والشاشة مقفولة أو التطبيق في الخلفية
        TransRuntime.job = AppScope.io.launch {
            val wl = try {
                ctx.getSystemService(android.os.PowerManager::class.java)
                    ?.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "mostafa:translate")
                    ?.also { it.acquire(3 * 60 * 60 * 1000L) }
            } catch (e: Exception) {
                null
            }
            // بنستخدم filesDir (مش cacheDir) عشان منظّفات الكاش في بعض الموبايلات ما تمسحش الملفات في نص الترجمة
            val dir = File(ctx.filesDir, "local_tr/${System.nanoTime()}").apply { mkdirs() }
            try {
                // 1) نسخ الفيديو المختار لمجلد مؤقت
                var display = "video"
                ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) display = c.getString(0) ?: display }
                val base = display.substringBeforeLast('.').ifBlank { "video" }
                    .replace(Regex("[\\\\/:*?\"<>|]"), "_").take(80)
                val ext = display.substringAfterLast('.', "").lowercase(Locale.US)
                    .takeIf { it in setOf("mp4", "m4v", "mov", "mkv", "webm", "3gp") } ?: "mp4"
                val vid = File(dir, "$base.$ext")
                val input = ctx.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Cannot open the selected video")
                input.use { i -> vid.outputStream().use { o -> i.copyTo(o) } }
                if (vid.length() == 0L) throw IllegalStateException("The selected video is empty")

                // 2) تعرّف على الكلام ← ترجمة ← حرق الترجمة على الصورة
                val r = AiTrans.run(
                    ctx, vid, key, false, true, null,
                    onStage = { m ->
                        _trans.update { it.copy(stage = m) }
                        Notifier.progress(ctx, 99, m.get(_settings.value.lang == "ar"))
                    },
                    cancelled = { TransRuntime.cancel }
                )

                // 3) حفظ النتيجة في مجلد "Translated"
                val out = dir.listFiles()
                    ?.filter { it.isFile && it.length() > 0 && it.extension.lowercase(Locale.US) in setOf("mp4", "m4v", "mov", "mkv", "webm", "3gp") }
                    ?.maxByOrNull { it.length() }
                    ?: throw IllegalStateException("No output video")
                val res = saveToDownloads(ctx, out, base + "_translated." + out.extension, "Translated")
                addHistory(
                    HistoryItem(
                        base + "_translated", "🌐 ترجمة",
                        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date()),
                        res.uri, res.mime, "other", out.length()
                    )
                )
                _trans.value = TransUi(
                    name = base, doneUri = res.uri, doneMime = res.mime, doneWhere = res.where, note = r.note
                )
                Notifier.done(ctx, base + "_translated", res.uri, res.mime)
            } catch (e: Exception) {
                if (TransRuntime.cancel || e is kotlinx.coroutines.CancellationException) {
                    _trans.value = TransUi(error = Msg("تم إلغاء الترجمة", "Translation cancelled"))
                } else {
                    val reason = (e as? AiTransException)?.msg ?: Msg(e.message ?: "error", e.message ?: "error")
                    _trans.value = TransUi(
                        error = Msg("فشلت الترجمة: ${reason.ar}", "Translation failed: ${reason.en}")
                    )
                    Notifier.failed(ctx, _trans.value.error!!)
                }
            } finally {
                dir.deleteRecursively()
                try {
                    if (wl?.isHeld == true) wl.release()
                } catch (e: Exception) {
                }
                Notifier.cancelProgress(ctx)
                // نقفل الخدمة بس لو مفيش تحميلات شغالة
                val dlBusy = synchronized(qLock) { workerActive }
                if (!dlBusy) {
                    try {
                        ctx.stopService(Intent(ctx, DownloadService::class.java))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    // ====================== نص الفيديو وملخصه ======================
    val transcript: StateFlow<TranscriptUi> = TransRuntime.tr.asStateFlow()

    fun clearTranscript() {
        if (!TransRuntime.tr.value.running) TransRuntime.tr.value = TranscriptUi()
    }

    fun cancelTranscript() {
        TransRuntime.trCancel = true
        TransRuntime.trJob?.cancel()
    }

    fun transcribeLocal(uri: android.net.Uri) {
        if (TransRuntime.tr.value.running) return
        val ctx = getApplication<Application>()
        val key = _settings.value.groqKey.trim()
        if (key.isEmpty()) {
            TransRuntime.tr.value = TranscriptUi(
                error = Msg("ضيف مفتاح Groq المجاني من الإعدادات الأول.", "Add your free Groq key in Settings first.")
            )
            return
        }
        TransRuntime.trCancel = false
        TransRuntime.tr.value = TranscriptUi(running = true, stage = Msg("جاري تجهيز الفيديو...", "Preparing the video..."))
        Notifier.ensureChannels(ctx)
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (e: Exception) {
        }
        TransRuntime.trJob = AppScope.io.launch {
            val wl = try {
                ctx.getSystemService(android.os.PowerManager::class.java)
                    ?.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "mostafa:transcript")
                    ?.also { it.acquire(3 * 60 * 60 * 1000L) }
            } catch (e: Exception) {
                null
            }
            val dir = File(ctx.cacheDir, "local_tr/${System.nanoTime()}").apply { mkdirs() }
            try {
                var display = "video"
                ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) display = c.getString(0) ?: display }
                val base = display.substringBeforeLast('.').ifBlank { "video" }
                    .replace(Regex("[\\\\/:*?\"<>|]"), "_").take(80)
                val ext = display.substringAfterLast('.', "").lowercase(Locale.US)
                    .takeIf { it in setOf("mp4", "m4v", "mov", "mkv", "webm", "3gp", "mp3", "m4a", "wav", "aac", "ogg", "opus") } ?: "mp4"
                val src = File(dir, "$base.$ext")
                val input = ctx.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Cannot open the selected file")
                input.use { i -> src.outputStream().use { o -> i.copyTo(o) } }
                if (src.length() == 0L) throw IllegalStateException("The selected file is empty")

                val r = AiTrans.transcript(
                    ctx, src, key, _settings.value.lang == "ar",
                    onStage = { m ->
                        TransRuntime.tr.update { it.copy(stage = m) }
                        Notifier.progress(ctx, 99, m.get(_settings.value.lang == "ar"))
                    },
                    cancelled = { TransRuntime.trCancel }
                )
                TransRuntime.tr.value = TranscriptUi(
                    name = base, text = r.text, summary = r.summary, lang = r.lang, truncated = r.truncated,
                    summaryError = r.summaryError
                )
                Notifier.transcriptDone(ctx, base)
            } catch (e: Exception) {
                if (TransRuntime.trCancel || e is kotlinx.coroutines.CancellationException) {
                    TransRuntime.tr.value = TranscriptUi(error = Msg("تم الإلغاء", "Cancelled"))
                } else {
                    val reason = (e as? AiTransException)?.msg ?: Msg(e.message ?: "error", e.message ?: "error")
                    TransRuntime.tr.value = TranscriptUi(
                        error = Msg("فشل استخراج النص: ${reason.ar}", "Transcription failed: ${reason.en}")
                    )
                    Notifier.failed(ctx, TransRuntime.tr.value.error!!)
                }
            } finally {
                dir.deleteRecursively()
                try {
                    if (wl?.isHeld == true) wl.release()
                } catch (e: Exception) {
                }
                Notifier.cancelProgress(ctx)
                val dlBusy = synchronized(qLock) { workerActive }
                if (!dlBusy && !TransRuntime.ui.value.running) {
                    try {
                        ctx.stopService(Intent(ctx, DownloadService::class.java))
                    } catch (e: Exception) {
                    }
                }
            }
        }
    }

    /** يحفظ الملخص والنص كملف txt في مجلد "Transcripts" */
    fun saveTranscript(onDone: (String?) -> Unit) {
        val t = TransRuntime.tr.value
        if (t.text.isEmpty()) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val tmp = File(ctx.cacheDir, "tr_save_${System.nanoTime()}").apply { mkdirs() }
                val f = File(tmp, "${t.name}_transcript.txt")
                f.writeText(
                    (if (t.summary.isNotBlank()) "الملخص / Summary\n\n${t.summary}\n\n------------------\n\n" else "") +
                        "النص / Transcript\n\n${t.text}\n",
                    Charsets.UTF_8
                )
                val res = saveToDownloads(ctx, f, f.name, "Transcripts")
                tmp.deleteRecursively()
                onDone(res.where)
            } catch (e: Exception) {
                onDone(null)
            }
        }
    }

    init {
        checkUpdate(false)
    }
}
