package com.mostafa.downloader

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

data class DlOptions(
    val mode: Int = 0,
    val quality: Int = 0,
    val audioFmt: String = "mp3-320",
    val imageFmt: String = "jpg"
)

const val ST_WAIT = 0
const val ST_RUN = 1
const val ST_DONE = 2
const val ST_FAIL = 3
const val ST_CANCEL = 4

/** عنصر في طابور التحميل */
data class QItem(
    val id: Long,
    val url: String,
    val opts: DlOptions,
    val status: Int = ST_WAIT,
    val progress: Float = 0f,
    val detail: String = "",
    val error: Msg? = null
)

data class UiState(
    val ready: Boolean = false,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val message: Msg = Msg("جاري تجهيز المحرك...", "Preparing the engine..."),
    val isError: Boolean = false,
    val detail: String = ""
)

data class UpdateUi(
    val checking: Boolean = false,
    val available: Updater.Release? = null,
    val downloading: Boolean = false,
    val progress: Float = 0f,
    val message: Msg? = null
)

class DownloaderViewModel(app: Application) : AndroidViewModel(app) {

    // ---------- الإعدادات ----------
    private val settingsStore = SettingsStore(app)
    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun saveSettings(s: AppSettings) {
        _settings.value = s
        settingsStore.save(s)
    }

    fun setLang(lang: String) = saveSettings(_settings.value.copy(lang = lang))
    fun setTheme(theme: String) = saveSettings(_settings.value.copy(theme = theme))
    fun setAccent(accent: String) = saveSettings(_settings.value.copy(accent = accent))
    fun setAutoShare(v: Boolean) = saveSettings(_settings.value.copy(autoShare = v))
    fun setWifiOnly(v: Boolean) = saveSettings(_settings.value.copy(wifiOnly = v))
    fun setFastEngine(v: Boolean) = saveSettings(_settings.value.copy(fastEngine = v))
    fun setClipSuggest(v: Boolean) = saveSettings(_settings.value.copy(clipSuggest = v))

    /** true لو الاتصال الحالي واي فاي أو إيثرنت */
    private fun onWifi(): Boolean {
        return try {
            val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> !cm.isActiveNetworkMetered
                else -> false
            }
        } catch (e: Exception) {
            true
        }
    }
    fun setWaUri(variant: Int, uri: String) {
        val s = _settings.value
        saveSettings(if (variant == 0) s.copy(waUri = uri) else s.copy(wabUri = uri))
    }

    // ---------- التحميل ----------
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val store = HistoryStore(app)
    private val _history = MutableStateFlow(store.load())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    // ---------- الطابور ----------
    private val queueStore = QueueStore(app)
    private val _queue = MutableStateFlow(queueStore.load())
    val queue: StateFlow<List<QItem>> = _queue.asStateFlow()
    private val qLock = Any()
    private var workerActive = false
    private val nextId = java.util.concurrent.atomic.AtomicLong((_queue.value.maxOfOrNull { it.id } ?: 0L) + 1)
    private val cancelledIds: MutableSet<Long> = java.util.Collections.synchronizedSet(HashSet<Long>())
    @Volatile private var engineUpdating = false
    @Volatile private var aria2Ready = false

    private fun updItem(id: Long, f: (QItem) -> QItem) {
        _queue.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    init {
        // نحفظ الطابور كل ما يتغير (إضافة/حالة/إلغاء) — من غير ما نحفظ مع كل نسبة تقدم
        viewModelScope.launch(Dispatchers.IO) {
            // نمسح مجلدات التحميل المؤقتة اللي مالهاش عنصر في الطابور
            try {
                val keep = _queue.value.filter { it.status != ST_DONE }.map { it.id.toString() }.toSet()
                File(app.cacheDir, "dl").listFiles()?.forEach { if (it.name !in keep) it.deleteRecursively() }
            } catch (e: Exception) {
            }
            _queue.map { l -> l.map { it.id to it.status } }
                .distinctUntilChanged()
                .collect { queueStore.save(_queue.value) }
        }
    }

    private val _engineMsg = MutableStateFlow<Msg?>(null)
    val engineMsg: StateFlow<Msg?> = _engineMsg.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                try {
                    aria2Ready = initAria2(app)
                } catch (e: Throwable) {
                    aria2Ready = false // نكمل بالتحميل العادي
                }
                _state.update {
                    it.copy(ready = true, message = Msg("جاهز — الصق الرابط وابدأ", "Ready — paste a link to start"))
                }
                // نستنى التحديث التلقائي للمحرك (بحد أقصى دقيقة) وبعدين نكمل الطابور المحفوظ
                withTimeoutOrNull(60_000L) { autoUpdateEngine()?.join() }
                resumeQueue()
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        message = Msg("فشل تجهيز المحرك: ${e.message}", "Engine setup failed: ${e.message}"),
                        isError = true
                    )
                }
            }
        }
    }

    fun extractUrl(text: String): String? = Regex("https?://\\S+").find(text)?.value

    /** تحديث المحرك تلقائياً عند فتح التطبيق (مرة كل 12 ساعة) من غير تدخل المستخدم */
    private fun autoUpdateEngine(): Job? {
        val app = getApplication<Application>()
        val prefs = app.getSharedPreferences("engine", Context.MODE_PRIVATE)
        val last = prefs.getLong("last_update", 0L)
        if (System.currentTimeMillis() - last < 12L * 3600L * 1000L) return null
        engineUpdating = true
        return AppScope.io.launch {
            _engineMsg.value = Msg("جاري تحديث المحرك تلقائياً...", "Updating the engine automatically...")
            try {
                YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.NIGHTLY)
                prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
                _engineMsg.value = Msg("تم تحديث المحرك تلقائياً", "Engine updated automatically")
            } catch (e: Exception) {
                _engineMsg.value = Msg("تعذر التحديث التلقائي للمحرك", "Automatic engine update failed")
            } finally {
                engineUpdating = false
            }
        }
    }


    /** aria2c اختياري عن طريق reflection: لو مش متاح بنكمل بالتحميل العادي */
    private fun initAria2(app: Application): Boolean = try {
        val c = Class.forName("com.yausername.aria2c.Aria2c")
        val inst = c.getMethod("getInstance").invoke(null)
        c.getMethod("init", Context::class.java).invoke(inst, app)
        true
    } catch (e: Throwable) {
        false
    }

    private val aria2Re = Regex(
        "\\[#\\w+\\s+([0-9.]+)\\s*([KMGT]?i?B)/([0-9.]+)\\s*([KMGT]?i?B)\\((\\d+)%\\)" +
            "(?:.*?DL:([0-9.]+)\\s*([KMGT]?i?B))?(?:.*?ETA:([0-9hms]+))?"
    )

    /** يقرأ سطر تقدّم aria2c ويرجع النسبة + التفاصيل (الحجم • السرعة • الوقت المتبقي) */
    private fun aria2Progress(line: String?): Pair<Float, String>? {
        if (line.isNullOrEmpty()) return null
        val m = aria2Re.find(line) ?: return null
        val g = m.groupValues
        val done = toBytes(g[1].toDoubleOrNull() ?: return null, g[2])
        val total = toBytes(g[3].toDoubleOrNull() ?: return null, g[4])
        val pct = g[5].toFloatOrNull() ?: return null
        val parts = ArrayList<String>()
        parts.add(fmtBytes(done) + " / " + fmtBytes(total))
        if (g[6].isNotEmpty()) {
            val v = g[6].toDoubleOrNull()
            if (v != null) parts.add(fmtBytes(toBytes(v, g[7])) + "/s")
        }
        if (g[8].isNotEmpty()) parts.add("ETA " + g[8])
        return pct to parts.joinToString("  •  ")
    }

    private val sizeRe = Regex("of\\s+~?\\s*([0-9.]+)\\s*([KMGT]?i?B)")
    private val speedRe = Regex("at\\s+([0-9.]+)\\s*([KMGT]?i?B)/s")
    private val etaRe = Regex("ETA\\s+([0-9:]+)")

    private fun toBytes(v: Double, unit: String): Double = when (unit.uppercase(Locale.US)) {
        "KIB" -> v * 1024.0
        "MIB" -> v * 1048576.0
        "GIB" -> v * 1073741824.0
        "KB" -> v * 1000.0
        "MB" -> v * 1000000.0
        "GB" -> v * 1000000000.0
        else -> v
    }

    private fun fmtBytes(b: Double): String = when {
        b >= 1073741824.0 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
        b >= 1048576.0 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1024.0 -> String.format(Locale.US, "%.0f KB", b / 1024.0)
        else -> "${b.toInt()} B"
    }

    /** يطلّع من سطر yt-dlp: الحجم المنزّل / الإجمالي • السرعة • الوقت المتبقي */
    private fun progressDetail(line: String?, pct: Float): String? {
        if (line.isNullOrEmpty()) return null
        val sm = sizeRe.find(line) ?: return null
        val totalValue = sm.groupValues[1].toDoubleOrNull() ?: return null
        val total = toBytes(totalValue, sm.groupValues[2])
        val parts = ArrayList<String>()
        parts.add(fmtBytes(total * pct / 100.0) + " / " + fmtBytes(total))
        speedRe.find(line)?.let { m ->
            val v = m.groupValues[1].toDoubleOrNull()
            if (v != null) parts.add(fmtBytes(toBytes(v, m.groupValues[2])) + "/s")
        }
        etaRe.find(line)?.let { parts.add("ETA " + it.groupValues[1]) }
        return parts.joinToString("  •  ")
    }

    fun extractUrls(text: String): List<String> =
        Regex("https?://\\S+").findAll(text)
            .map { it.value.trimEnd(',', ';', ')') }
            .distinct().toList()

    /** للتوافق: فيديو/صوت بسيط */
    fun download(rawInput: String, audioOnly: Boolean, quality: Int) =
        download(rawInput, DlOptions(mode = if (audioOnly) 1 else 0, quality = quality))

    /** يضيف رابط أو أكتر للطابور بالخيارات المحددة */
    fun download(rawInput: String, opts: DlOptions) {
        val s = _state.value
        if (!s.ready) return
        if (engineUpdating) {
            _state.update {
                it.copy(message = Msg("استنى لحد ما يخلص تحديث المحرك", "Wait until the engine update finishes"), isError = true)
            }
            return
        }
        val urls = extractUrls(rawInput).take(20)
        if (urls.isEmpty()) {
            _state.update { it.copy(message = Msg("الرابط غير صحيح", "Invalid link"), isError = true) }
            return
        }
        if (_settings.value.wifiOnly && !onWifi()) {
            _state.update {
                it.copy(
                    message = Msg(
                        "التحميل على الواي فاي بس مفعّل — اتصل بواي فاي أو أوقف الإعداد من الإعدادات",
                        "Wi-Fi only is on — connect to Wi-Fi or turn it off in Settings"
                    ),
                    isError = true
                )
            }
            return
        }
        val items = synchronized(qLock) {
            val active = _queue.value.filter { it.status == ST_WAIT || it.status == ST_RUN }.map { it.url }.toSet()
            val fresh = urls.filter { it !in active }.map { QItem(nextId.getAndIncrement(), it, opts) }
            if (fresh.isNotEmpty()) {
                // نحتفظ بآخر 30 عنصر منتهي بس عشان القائمة ما تكبرش
                val keep = _queue.value.filter { it.status == ST_WAIT || it.status == ST_RUN }
                val done = _queue.value.filter { it.status >= ST_DONE }.takeLast(30)
                _queue.value = (done + keep + fresh).sortedBy { it.id }
            }
            fresh
        }
        if (items.isEmpty()) {
            _state.update {
                it.copy(message = Msg("الرابط ده موجود في الطابور بالفعل", "This link is already in the queue"), isError = true)
            }
            return
        }
        if (!_state.value.busy) {
            _state.update { it.copy(message = Msg("جاري التحميل...", "Downloading..."), isError = false) }
        }
        ensureWorker()
    }

    private fun ensureWorker() {
        synchronized(qLock) {
            if (workerActive) return
            workerActive = true
        }
        val ctx = getApplication<Application>()
        Notifier.ensureChannels(ctx)
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (e: Exception) {
        }
        AppScope.io.launch {
            try {
                while (true) {
                    val next = synchronized(qLock) {
                        val n = _queue.value.firstOrNull { it.status == ST_WAIT }
                        if (n == null) {
                            workerActive = false
                        } else {
                            _queue.value = _queue.value.map {
                                if (it.id == n.id) it.copy(status = ST_RUN, progress = 0f, detail = "", error = null) else it
                            }
                        }
                        n
                    } ?: break
                    _state.value = UiState(ready = true, busy = true, message = Msg("جاري التحميل...", "Downloading..."))
                    runOne(ctx, next)
                }
                try {
                    ctx.stopService(Intent(ctx, DownloadService::class.java))
                } catch (e: Exception) {
                }
            } catch (t: Throwable) {
                synchronized(qLock) { workerActive = false }
            }
        }
    }

    /** يكمل العناصر المنتظرة (بعد فتح التطبيق أو بعد ما تتصل بواي فاي) */
    fun resumeQueue() {
        if (!_state.value.ready || engineUpdating) return
        if (_queue.value.none { it.status == ST_WAIT }) return
        if (_settings.value.wifiOnly && !onWifi()) {
            _state.update {
                it.copy(
                    message = Msg(
                        "في تحميلات مستنية — اتصل بواي فاي وداس استكمال",
                        "Downloads are waiting — connect to Wi-Fi and tap Resume"
                    ),
                    isError = false
                )
            }
            return
        }
        _state.update {
            it.copy(message = Msg("جاري استكمال التحميلات المحفوظة...", "Resuming saved downloads..."), isError = false)
        }
        ensureWorker()
    }

    /** إلغاء عنصر: لو منتظر بيتشال، ولو شغال بنقتل عملية التحميل */
    fun cancelItem(id: Long) {
        var wasRunning = false
        synchronized(qLock) {
            _queue.value = _queue.value.map {
                if (it.id != id) it
                else when (it.status) {
                    ST_WAIT -> it.copy(status = ST_CANCEL)
                    ST_RUN -> { wasRunning = true; it }
                    else -> it
                }
            }
        }
        if (wasRunning) {
            cancelledIds.add(id)
            try {
                YoutubeDL.getInstance().destroyProcessById("q$id")
            } catch (e: Exception) {
            }
        }
    }

    fun cancelCurrent() {
        _queue.value.firstOrNull { it.status == ST_RUN }?.let { cancelItem(it.id) }
    }

    fun cancelAll() {
        _queue.value.filter { it.status == ST_WAIT || it.status == ST_RUN }.forEach { cancelItem(it.id) }
    }

    fun retryItem(id: Long) {
        if (!_state.value.ready || engineUpdating) return
        synchronized(qLock) {
            _queue.value = _queue.value.map {
                if (it.id == id && (it.status == ST_FAIL || it.status == ST_CANCEL))
                    it.copy(status = ST_WAIT, progress = 0f, detail = "", error = null)
                else it
            }
        }
        ensureWorker()
    }

    fun removeItem(id: Long) {
        synchronized(qLock) {
            _queue.value = _queue.value.filter { !(it.id == id && it.status >= ST_DONE) }
        }
    }

    fun clearFinished() {
        synchronized(qLock) {
            _queue.value = _queue.value.filter { it.status < ST_DONE }
        }
    }

    private suspend fun runOne(ctx: Application, item: QItem): Boolean {
            val url = item.url
            val opts = item.opts
            // مجلد مؤقت لكل عنصر ومبيتمسحش في البداية، عشان لو التطبيق اتقفل نكمل من الجزء المحمّل
            val tmp = File(ctx.cacheDir, "dl/${item.id}").apply { mkdirs() }
            val site = CookieStore.siteOfUrl(url)
            var lastPct = -1
            val tStart = System.currentTimeMillis()
            var tFirst = 0L
            try {
                val req = YoutubeDLRequest(url)
                val outName = if ("/stories/" in url) "%(uploader|story)s_%(id)s.%(ext)s" else "%(title).80s.%(ext)s"
                req.addOption("-o", "${tmp.absolutePath}/$outName")
                if ("/highlights/" !in url) req.addOption("--no-playlist")
                // تسريع: تحميل أجزاء الفيديو بالتوازي + إعادة المحاولة عند ضعف الشبكة
                req.addOption("-N", "4")
                req.addOption("--retries", "10")
                req.addOption("--fragment-retries", "10")
                req.addOption("--socket-timeout", "10")
                // يمنع التأخير (~20 ثانية) لما الـ IPv6 يعلّق قبل ما يرجع لـ IPv4
                req.addOption("--force-ipv4")
                // الملفات المباشرة: aria2c بـ 16 اتصال (التقسيم والتحميل المتوازي)
                val useAria = aria2Ready && _settings.value.fastEngine
                if (useAria) {
                    req.addOption("--downloader", "libaria2c.so")
                    req.addOption(
                        "--external-downloader-args",
                        "aria2c:--summary-interval=1 --file-allocation=none --http-accept-gzip=true " +
                            "--async-dns=false --disable-ipv6=true --connect-timeout=10 " +
                            "-x16 -j16 -s16 -k1M"
                    )
                }
                if (site != null && CookieStore.isLoggedIn(ctx, site)) {
                    req.addOption("--cookies", CookieStore.file(ctx, site).absolutePath)
                }
                when (opts.mode) {
                    1 -> {
                        req.addOption("-f", "bestaudio/best")
                        req.addOption("-x")
                        when (opts.audioFmt) {
                            "mp3-128" -> {
                                req.addOption("--audio-format", "mp3")
                                req.addOption("--audio-quality", "128K")
                            }
                            "m4a" -> req.addOption("--audio-format", "m4a")
                            "wav" -> req.addOption("--audio-format", "wav")
                            else -> {
                                req.addOption("--audio-format", "mp3")
                                req.addOption("--audio-quality", "320K")
                            }
                        }
                    }
                    2 -> {
                        req.addOption("--skip-download")
                        req.addOption("--write-thumbnail")
                        req.addOption("--convert-thumbnails", opts.imageFmt)
                    }
                    else -> {
                        val h = if (opts.quality > 0) "[height<=${opts.quality}]" else ""
                        // لو مفيش جودة أقل من أو تساوي المطلوبة، ناخد أقل جودة متاحة (مش أعلى واحدة)
                        val fallback = if (opts.quality > 0) "w" else "b"
                        req.addOption("-f", "bv*$h[ext=mp4]+ba[ext=m4a]/bv*$h+ba/b$h/$fallback")
                        req.addOption("--merge-output-format", "mp4")
                    }
                }
                val igDirect = site == "ig" && "/stories/" in url && CookieStore.isLoggedIn(ctx, "ig")
                if (igDirect) {
                    _state.update {
                        it.copy(message = Msg("جاري تحميل استوري إنستجرام...", "Fetching the Instagram story..."))
                    }
                    IgStory.download(ctx, url, tmp)
                } else {
                try {
                    val onProg: (Float, Long, String?) -> Unit = { progress, _, line ->
                        if (tFirst == 0L) tFirst = System.currentTimeMillis()
                        val a2 = aria2Progress(line)
                        val p = (a2?.first ?: progress).coerceIn(0f, 100f)
                        val detail = a2?.second ?: progressDetail(line, p)
                        _state.update { it.copy(progress = p / 100f, detail = detail ?: it.detail) }
                        updItem(item.id) { it.copy(progress = p / 100f, detail = detail ?: it.detail) }
                        val pct = p.toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            Notifier.progress(ctx, pct, detail ?: "")
                        }
                    }
                    try {
                        YoutubeDL.getInstance().execute(req, "q${item.id}", onProg)
                    } catch (e: Exception) {
                        // لو aria2c فشل لأي سبب نعيد المحاولة بالمحرك العادي
                        val m = e.message ?: ""
                        val aria2Problem = useAria && item.id !in cancelledIds && (m.contains("aria2", true) ||
                            m.contains("external downloader", true) || m.contains("exited with", true))
                        if (!aria2Problem) throw e
                        tmp.listFiles()?.forEach { it.delete() }
                        lastPct = -1
                        req.addOption("--downloader", "native")
                        YoutubeDL.getInstance().execute(req, "q${item.id}", onProg)
                    }
                } catch (e: Exception) {
                    val em = e.message ?: ""
                    if (site == "fb" && CookieStore.isLoggedIn(ctx, "fb") && em.contains("Unsupported URL", true)) {
                        val resolved = Regex("Unsupported URL: (\\S+)").find(em)?.groupValues?.get(1)
                        _state.update {
                            it.copy(message = Msg("جاري محاولة فيسبوك البديلة...", "Trying the Facebook fallback..."))
                        }
                        FbStory.download(ctx, listOfNotNull(resolved, url).distinct(), tmp)
                    } else if (site == "ig" && CookieStore.isLoggedIn(ctx, "ig") && "/stories/" in url &&
                        (em.contains("log in", true) || em.contains("login", true) ||
                            em.contains("unable to extract user info", true) ||
                            em.contains("empty media response", true))
                    ) {
                        _state.update {
                            it.copy(message = Msg("جاري محاولة إنستجرام البديلة...", "Trying the Instagram fallback..."))
                        }
                        IgStory.download(ctx, url, tmp)
                    } else if ("snapchat.com" in url.lowercase() && opts.mode != 1) {
                        _state.update {
                            it.copy(message = Msg("جاري محاولة سناب شات البديلة...", "Trying the Snapchat fallback..."))
                        }
                        val resolved = Regex("Unsupported URL: (\\S+)").find(em)?.groupValues?.get(1)
                        val cands = listOfNotNull(resolved, url).distinct()
                        try {
                            val spot = cands.firstOrNull { "/spotlight/" in it }
                            if (spot != null) {
                                try {
                                    SnapSpotlight.download(spot, tmp, opts.mode)
                                } catch (e3: Exception) {
                                    SnapStory.download(ctx, cands, tmp)
                                }
                            } else {
                                SnapStory.download(ctx, cands, tmp)
                            }
                        } catch (e2: Exception) {
                            throw IllegalStateException((e2.message ?: "Snapchat fallback failed") + "\n" + em.take(160))
                        }
                    } else {
                        throw e
                    }
                }
                }
                if (item.id in cancelledIds) throw IllegalStateException("cancelled")
                val files = tmp.listFiles()?.filter { it.isFile && it.length() > 0 }.orEmpty()
                if (files.isEmpty()) throw IllegalStateException("No output file")

                val label = when (opts.mode) {
                    1 -> when (opts.audioFmt) {
                        "mp3-128" -> "MP3 128kbps"
                        "m4a" -> "M4A"
                        "wav" -> "WAV"
                        else -> "MP3 320kbps"
                    }
                    2 -> opts.imageFmt.uppercase(Locale.US)
                    else -> if (opts.quality == 0) "BEST" else "${opts.quality}p"
                }
                var firstName = ""
                var firstUri = ""
                var firstMime = ""
                files.forEach { f ->
                    val (uri, mime) = saveToDownloads(ctx, f)
                    if (firstUri.isEmpty()) {
                        firstName = f.nameWithoutExtension
                        firstUri = uri
                        firstMime = mime
                    }
                    addHistory(
                        HistoryItem(
                            f.nameWithoutExtension, label,
                            SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date()),
                            uri, mime
                        )
                    )
                }
                updItem(item.id) { it.copy(status = ST_DONE, progress = 1f, detail = "", error = null) }
                // تشخيص السرعة: وقت التجهيز قبل أول بايت + وقت التحميل + المتوسط
                val tEnd = System.currentTimeMillis()
                val prep = if (tFirst > 0) (tFirst - tStart) / 1000.0 else 0.0
                val dl = ((tEnd - (if (tFirst > 0) tFirst else tStart)) / 1000.0).coerceAtLeast(0.1)
                val bytes = files.sumOf { it.length() }
                val avg = fmtBytes(bytes / dl) + "/s"
                val stats = if (tFirst > 0)
                    String.format(Locale.US, "%.0fs prep • %.0fs download • avg %s", prep, dl, avg)
                else String.format(Locale.US, "%.0fs total", (tEnd - tStart) / 1000.0)
                _state.value = UiState(
                    ready = true,
                    progress = 1f,
                    message = Msg(
                        "تم الحفظ في Downloads/MostafaDownloader\n$stats",
                        "Saved to Downloads/MostafaDownloader\n$stats"
                    )
                )
                Notifier.done(ctx, firstName, firstUri, firstMime)
                return true
            } catch (e: Exception) {
                if (item.id in cancelledIds) {
                    updItem(item.id) { it.copy(status = ST_CANCEL, detail = "") }
                    _state.value = UiState(ready = true, message = Msg("تم إلغاء التحميل", "Download cancelled"))
                    return false
                }
                val m = cleanError(e.message)
                val loggedIn = CookieStore.isLoggedIn(ctx, site)
                val loginish = m.contains("login", true) || m.contains("cookies", true) ||
                    m.contains("unable to extract user info", true) ||
                    m.contains("instagram:story", true) || m.contains("empty media response", true)
                val msg = when {
                    m.contains("HTTP 429") -> Msg(
                        "إنستجرام بيحدّ الطلبات مؤقتاً (429). استنى فترة وجرّب تاني.\n$m",
                        "Instagram is temporarily rate-limiting requests (429). Wait a while and try again.\n$m"
                    )
                    site != null && !loggedIn && loginish -> Msg(
                        "لازم تسجّل دخول الأول من تبويب الاستوريهات.",
                        "Please sign in first from the Stories tab."
                    )
                    site != null && loggedIn && loginish -> Msg(
                        "فشل التحميل رغم تسجيل الدخول. سجّل خروج ودخول تاني من تبويب الاستوريهات، أو حدّث محرك التحميل من الإعدادات.\n$m",
                        "Download failed even though you're signed in. Sign out and in again from the Stories tab, or update the engine in Settings.\n$m"
                    )
                    else -> Msg("فشل التحميل: $m", "Download failed: $m")
                }
                updItem(item.id) { it.copy(status = ST_FAIL, detail = "", error = msg) }
                _state.value = UiState(ready = true, message = msg, isError = true)
                Notifier.failed(ctx, msg)
                return false
            } finally {
                cancelledIds.remove(item.id)
                tmp.deleteRecursively()
                Notifier.cancelProgress(ctx)
            }
    }

    private fun cleanError(raw: String?): String {
        val m = raw ?: return ""
        val i = m.lastIndexOf("ERROR:")
        return (if (i >= 0) m.substring(i) else m).trim().take(600)
    }

    private fun addHistory(item: HistoryItem) {
        _history.value = (listOf(item) + _history.value).take(100)
        store.save(_history.value)
    }

    /** يحذف عنصر من السجل، ولو deleteFile = true يحذف الملف نفسه من التحميلات */
    fun deleteHistory(item: HistoryItem, deleteFile: Boolean) {
        if (deleteFile) {
            try {
                getApplication<Application>().contentResolver.delete(Uri.parse(item.uri), null, null)
            } catch (e: Exception) {
            }
        }
        _history.value = _history.value.filter { it.uri != item.uri || it.date != item.date }
        store.save(_history.value)
    }

    fun clearHistory() {
        _history.value = emptyList()
        store.save(emptyList())
    }

    fun updateEngine() {
        if (!_state.value.ready || _state.value.busy || engineUpdating) return
        engineUpdating = true
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true) }
            _engineMsg.value = Msg("جاري تحديث المحرك...", "Updating the engine...")
            try {
                YoutubeDL.getInstance().updateYoutubeDL(getApplication(), YoutubeDL.UpdateChannel.NIGHTLY)
                _engineMsg.value = Msg("تم تحديث المحرك", "Engine updated")
            } catch (e: Exception) {
                _engineMsg.value = Msg("فشل التحديث: ${e.message}", "Update failed: ${e.message}")
            }
            engineUpdating = false
            _state.update { it.copy(busy = false) }
        }
    }

    private suspend fun saveToDownloads(ctx: Context, file: File): Pair<String, String> {
        val mime = when (file.extension.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "wav" -> "audio/wav"
            "opus" -> "audio/ogg"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/MostafaDownloader"
                )
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            return uri.toString() to mime
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "MostafaDownloader"
            ).apply { mkdirs() }
            val dest = File(dir, file.name)
            file.copyTo(dest, overwrite = true)
            val uri = suspendCancellableCoroutine<String> { cont ->
                MediaScannerConnection.scanFile(
                    ctx, arrayOf(dest.absolutePath), arrayOf(mime)
                ) { _, u -> cont.resume(u?.toString() ?: "") }
            }
            return uri to mime
        }
    }

    // ---------- تحديث التطبيق ----------
    private val _update = MutableStateFlow(UpdateUi())
    val update: StateFlow<UpdateUi> = _update.asStateFlow()
    private var pendingApk: File? = null

    fun checkUpdate(manual: Boolean) {
        if (_update.value.checking) return
        viewModelScope.launch(Dispatchers.IO) {
            _update.update { it.copy(checking = true, message = null) }
            try {
                val r = Updater.fetchLatest()
                if (r != null && r.versionCode > BuildConfig.VERSION_CODE) {
                    if (_update.value.available?.versionCode != r.versionCode) pendingApk = null
                    _update.update { it.copy(checking = false, available = r) }
                } else {
                    _update.update {
                        it.copy(
                            checking = false,
                            available = null,
                            message = if (!manual) null else if (r == null)
                                Msg("لا توجد إصدارات منشورة بعد", "No published releases yet")
                            else Msg("أنت على آخر إصدار", "You are on the latest version")
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        checking = false,
                        message = if (manual) Msg("تعذر التحقق من التحديثات", "Couldn't check for updates") else null
                    )
                }
            }
        }
    }

    fun installUpdate() {
        val r = _update.value.available ?: return
        if (_update.value.downloading) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apk: File = pendingApk?.takeIf { it.exists() } ?: run {
                    _update.update {
                        it.copy(
                            downloading = true, progress = 0f,
                            message = Msg("جاري تجهيز التحديث...", "Preparing the update...")
                        )
                    }
                    Updater.prepare(
                        ctx, r,
                        { p -> _update.update { it.copy(progress = p) } },
                        { delta ->
                            _update.update {
                                it.copy(
                                    progress = 0f,
                                    message = if (delta) Msg(
                                        "جاري تنزيل التحديث (التغييرات فقط)...",
                                        "Downloading the update (changes only)..."
                                    ) else Msg(
                                        "جاري تنزيل التحديث الكامل...",
                                        "Downloading the full update..."
                                    )
                                )
                            }
                        }
                    )
                }
                pendingApk = apk
                _update.update { it.copy(downloading = false) }
                if (Updater.canInstall(ctx)) {
                    Updater.install(ctx, apk)
                    _update.update {
                        it.copy(message = Msg("اضغط \"تثبيت\" في الشاشة اللي ظهرت", "Tap \"Install\" on the screen that appeared"))
                    }
                } else {
                    Updater.openInstallSettings(ctx)
                    _update.update {
                        it.copy(
                            message = Msg(
                                "اسمح بالتثبيت من التطبيق ده، وارجع اضغط تحديث تاني",
                                "Allow installs from this app, come back and tap Update again"
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        downloading = false,
                        message = Msg("فشل تنزيل التحديث: ${e.message}", "Update download failed: ${e.message}")
                    )
                }
            }
        }
    }

    // ---------- حالات واتساب ----------
    private val _statuses = MutableStateFlow<List<StatusItem>>(emptyList())
    val statuses: StateFlow<List<StatusItem>> = _statuses.asStateFlow()
    private val _waLoading = MutableStateFlow(false)
    val waLoading: StateFlow<Boolean> = _waLoading.asStateFlow()
    private val _waError = MutableStateFlow<Msg?>(null)
    val waError: StateFlow<Msg?> = _waError.asStateFlow()

    fun loadStatuses(variant: Int) {
        val uri = if (variant == 0) _settings.value.waUri else _settings.value.wabUri
        if (uri.isBlank()) {
            _statuses.value = emptyList()
            _waError.value = null
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _waLoading.value = true
            try {
                val list = listStatuses(getApplication(), uri)
                _statuses.value = list
                _waError.value = if (list.isEmpty()) Msg(
                    "مفيش حالات هنا. افتح الحالة في واتساب الأول وبعدين اضغط تحديث.",
                    "No statuses found. View a status in WhatsApp first, then tap Refresh."
                ) else null
            } catch (e: Exception) {
                _statuses.value = emptyList()
                _waError.value = Msg(
                    "تعذر قراءة المجلد، اختار المجلد تاني.",
                    "Couldn't read the folder, please choose it again."
                )
            }
            _waLoading.value = false
        }
    }

    fun saveStatus(item: StatusItem, onDone: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = try {
                saveStatusToGallery(getApplication(), item)
            } catch (e: Exception) {
                false
            }
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    init {
        checkUpdate(false)
    }
}
