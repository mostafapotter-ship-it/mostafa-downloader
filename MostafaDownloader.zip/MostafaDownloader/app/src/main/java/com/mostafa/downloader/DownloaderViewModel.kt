package com.mostafa.downloader

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

data class UiState(
    val ready: Boolean = false,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val message: Msg = Msg("جاري تجهيز المحرك...", "Preparing the engine..."),
    val isError: Boolean = false
)

data class UpdateUi(
    val checking: Boolean = false,
    val available: Updater.Release? = null,
    val downloading: Boolean = false,
    val progress: Float = 0f,
    val message: Msg? = null
)

class DownloaderViewModel(app: Application) : AndroidViewModel(app) {

    // ---------- الإعدادات ----------
    private val settingsStore = SettingsStore(app)
    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun saveSettings(s: AppSettings) {
        _settings.value = s
        settingsStore.save(s)
    }

    fun setLang(lang: String) = saveSettings(_settings.value.copy(lang = lang))
    fun setTheme(theme: String) = saveSettings(_settings.value.copy(theme = theme))
    fun setWaUri(variant: Int, uri: String) {
        val s = _settings.value
        saveSettings(if (variant == 0) s.copy(waUri = uri) else s.copy(wabUri = uri))
    }

    // ---------- التحميل ----------
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val store = HistoryStore(app)
    private val _history = MutableStateFlow(store.load())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    private val _engineMsg = MutableStateFlow<Msg?>(null)
    val engineMsg: StateFlow<Msg?> = _engineMsg.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                _state.update {
                    it.copy(ready = true, message = Msg("جاهز — الصق الرابط وابدأ", "Ready — paste a link to start"))
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        message = Msg("فشل تجهيز المحرك: ${e.message}", "Engine setup failed: ${e.message}"),
                        isError = true
                    )
                }
            }
        }
    }

    fun extractUrl(text: String): String? = Regex("https?://\\S+").find(text)?.value

    /** quality: أقصى ارتفاع للفيديو (0 = الأفضل). يُتجاهل مع وضع الصوت. */
    fun download(rawInput: String, audioOnly: Boolean, quality: Int) {
        val s = _state.value
        if (!s.ready || s.busy) return
        val url = extractUrl(rawInput)
        if (url == null) {
            _state.update { it.copy(message = Msg("الرابط غير صحيح", "Invalid link"), isError = true) }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val tmp = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
            _state.value = UiState(ready = true, busy = true, message = Msg("جاري التحميل...", "Downloading..."))
            val site = CookieStore.siteOfUrl(url)
            try {
                val req = YoutubeDLRequest(url)
                val outName = if ("/stories/" in url) "%(uploader|story)s_%(id)s.%(ext)s" else "%(title).80s.%(ext)s"
                req.addOption("-o", "${tmp.absolutePath}/$outName")
                if ("/highlights/" !in url) req.addOption("--no-playlist")
                if (site != null && CookieStore.isLoggedIn(ctx, site)) {
                    req.addOption("--cookies", CookieStore.file(ctx, site).absolutePath)
                }
                if (audioOnly) {
                    req.addOption("-f", "bestaudio/best")
                    req.addOption("-x")
                    req.addOption("--audio-format", "mp3")
                    req.addOption("--audio-quality", "320K")
                } else {
                    val h = if (quality > 0) "[height<=$quality]" else ""
                    req.addOption("-f", "bv*$h[ext=mp4]+ba[ext=m4a]/bv*$h+ba/b$h/b")
                    req.addOption("--merge-output-format", "mp4")
                }
                YoutubeDL.getInstance().execute(req) { progress, _, _ ->
                    _state.update { it.copy(progress = progress.coerceIn(0f, 100f) / 100f) }
                }
                val files = tmp.listFiles()?.filter { it.isFile && it.length() > 0 }.orEmpty()
                if (files.isEmpty()) throw IllegalStateException("No output file")

                val label = when {
                    audioOnly -> "MP3 320kbps"
                    quality == 0 -> "BEST"
                    else -> "${quality}p"
                }
                files.forEach { f ->
                    val (uri, mime) = saveToDownloads(ctx, f)
                    addHistory(
                        HistoryItem(
                            f.nameWithoutExtension, label,
                            SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date()),
                            uri, mime
                        )
                    )
                }
                _state.value = UiState(
                    ready = true,
                    progress = 1f,
                    message = Msg(
                        "تم الحفظ في Downloads/MostafaDownloader",
                        "Saved to Downloads/MostafaDownloader"
                    )
                )
            } catch (e: Exception) {
                val m = e.message?.take(200) ?: ""
                val needsLogin = site != null && (m.contains("login", true) || m.contains("cookies", true))
                _state.value = UiState(
                    ready = true,
                    message = if (needsLogin) Msg(
                        "فشل التحميل: $m\nجرّب تسجيل الدخول من الإعدادات ← حسابات الاستوريهات",
                        "Download failed: $m\nTry signing in from Settings → Story accounts"
                    ) else Msg("فشل التحميل: $m", "Download failed: $m"),
                    isError = true
                )
            } finally {
                tmp.deleteRecursively()
            }
        }
    }

    private fun addHistory(item: HistoryItem) {
        _history.value = (listOf(item) + _history.value).take(100)
        store.save(_history.value)
    }

    fun clearHistory() {
        _history.value = emptyList()
        store.save(emptyList())
    }

    fun updateEngine() {
        if (!_state.value.ready || _state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true) }
            _engineMsg.value = Msg("جاري تحديث المحرك...", "Updating the engine...")
            try {
                YoutubeDL.getInstance().updateYoutubeDL(getApplication())
                _engineMsg.value = Msg("تم تحديث المحرك", "Engine updated")
            } catch (e: Exception) {
                _engineMsg.value = Msg("فشل التحديث: ${e.message}", "Update failed: ${e.message}")
            }
            _state.update { it.copy(busy = false) }
        }
    }

    private suspend fun saveToDownloads(ctx: Context, file: File): Pair<String, String> {
        val mime = when (file.extension.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/MostafaDownloader"
                )
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            return uri.toString() to mime
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "MostafaDownloader"
            ).apply { mkdirs() }
            val dest = File(dir, file.name)
            file.copyTo(dest, overwrite = true)
            val uri = suspendCancellableCoroutine<String> { cont ->
                MediaScannerConnection.scanFile(
                    ctx, arrayOf(dest.absolutePath), arrayOf(mime)
                ) { _, u -> cont.resume(u?.toString() ?: "") }
            }
            return uri to mime
        }
    }

    // ---------- تحديث التطبيق ----------
    private val _update = MutableStateFlow(UpdateUi())
    val update: StateFlow<UpdateUi> = _update.asStateFlow()
    private var pendingApk: File? = null

    fun checkUpdate(manual: Boolean) {
        if (_update.value.checking) return
        viewModelScope.launch(Dispatchers.IO) {
            _update.update { it.copy(checking = true, message = null) }
            try {
                val r = Updater.fetchLatest()
                if (r != null && r.versionCode > BuildConfig.VERSION_CODE) {
                    if (_update.value.available?.versionCode != r.versionCode) pendingApk = null
                    _update.update { it.copy(checking = false, available = r) }
                } else {
                    _update.update {
                        it.copy(
                            checking = false,
                            available = null,
                            message = if (!manual) null else if (r == null)
                                Msg("لا توجد إصدارات منشورة بعد", "No published releases yet")
                            else Msg("أنت على آخر إصدار", "You are on the latest version")
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        checking = false,
                        message = if (manual) Msg("تعذر التحقق من التحديثات", "Couldn't check for updates") else null
                    )
                }
            }
        }
    }

    fun installUpdate() {
        val r = _update.value.available ?: return
        if (_update.value.downloading) return
        val ctx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apk: File = pendingApk?.takeIf { it.exists() } ?: run {
                    _update.update {
                        it.copy(
                            downloading = true, progress = 0f,
                            message = Msg("جاري تجهيز التحديث...", "Preparing the update...")
                        )
                    }
                    Updater.prepare(
                        ctx, r,
                        { p -> _update.update { it.copy(progress = p) } },
                        { delta ->
                            _update.update {
                                it.copy(
                                    progress = 0f,
                                    message = if (delta) Msg(
                                        "جاري تنزيل التحديث (التغييرات فقط)...",
                                        "Downloading the update (changes only)..."
                                    ) else Msg(
                                        "جاري تنزيل التحديث الكامل...",
                                        "Downloading the full update..."
                                    )
                                )
                            }
                        }
                    )
                }
                pendingApk = apk
                _update.update { it.copy(downloading = false) }
                if (Updater.canInstall(ctx)) {
                    Updater.install(ctx, apk)
                    _update.update {
                        it.copy(message = Msg("اضغط \"تثبيت\" في الشاشة اللي ظهرت", "Tap \"Install\" on the screen that appeared"))
                    }
                } else {
                    Updater.openInstallSettings(ctx)
                    _update.update {
                        it.copy(
                            message = Msg(
                                "اسمح بالتثبيت من التطبيق ده، وارجع اضغط تحديث تاني",
                                "Allow installs from this app, come back and tap Update again"
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                _update.update {
                    it.copy(
                        downloading = false,
                        message = Msg("فشل تنزيل التحديث: ${e.message}", "Update download failed: ${e.message}")
                    )
                }
            }
        }
    }

    // ---------- حالات واتساب ----------
    private val _statuses = MutableStateFlow<List<StatusItem>>(emptyList())
    val statuses: StateFlow<List<StatusItem>> = _statuses.asStateFlow()
    private val _waLoading = MutableStateFlow(false)
    val waLoading: StateFlow<Boolean> = _waLoading.asStateFlow()
    private val _waError = MutableStateFlow<Msg?>(null)
    val waError: StateFlow<Msg?> = _waError.asStateFlow()

    fun loadStatuses(variant: Int) {
        val uri = if (variant == 0) _settings.value.waUri else _settings.value.wabUri
        if (uri.isBlank()) {
            _statuses.value = emptyList()
            _waError.value = null
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _waLoading.value = true
            try {
                val list = listStatuses(getApplication(), uri)
                _statuses.value = list
                _waError.value = if (list.isEmpty()) Msg(
                    "مفيش حالات هنا. افتح الحالة في واتساب الأول وبعدين اضغط تحديث.",
                    "No statuses found. View a status in WhatsApp first, then tap Refresh."
                ) else null
            } catch (e: Exception) {
                _statuses.value = emptyList()
                _waError.value = Msg(
                    "تعذر قراءة المجلد، اختار المجلد تاني.",
                    "Couldn't read the folder, please choose it again."
                )
            }
            _waLoading.value = false
        }
    }

    fun saveStatus(item: StatusItem, onDone: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = try {
                saveStatusToGallery(getApplication(), item)
            } catch (e: Exception) {
                false
            }
            withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    init {
        checkUpdate(false)
    }
}
