package com.mostafa.downloader

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

data class UiState(
    val ready: Boolean = false,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val message: String = "جاري تجهيز المحرك...",
    val isError: Boolean = false
)

class DownloaderViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val store = HistoryStore(app)
    private val _history = MutableStateFlow(store.load())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                _state.update { it.copy(ready = true, message = "جاهز ✅ الصق الرابط وابدأ") }
            } catch (e: Exception) {
                _state.update { it.copy(message = "فشل تجهيز المحرك: ${e.message}", isError = true) }
            }
        }
    }

    fun extractUrl(text: String): String? =
        Regex("https?://\\S+").find(text)?.value

    /** quality: أقصى ارتفاع للفيديو (0 = أفضل جودة). يُتجاهل مع وضع الصوت. */
    fun download(rawInput: String, audioOnly: Boolean, quality: Int) {
        val s = _state.value
        if (!s.ready || s.busy) return
        val url = extractUrl(rawInput)
        if (url == null) {
            _state.update { it.copy(message = "الرابط غير صحيح", isError = true) }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val tmp = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
            _state.value = UiState(ready = true, busy = true, message = "جاري التحميل...")
            try {
                val req = YoutubeDLRequest(url)
                req.addOption("-o", "${tmp.absolutePath}/%(title).80s.%(ext)s")
                req.addOption("--no-playlist")
                if (audioOnly) {
                    req.addOption("-f", "bestaudio/best")
                    req.addOption("-x")
                    req.addOption("--audio-format", "mp3")
                    req.addOption("--audio-quality", "320K")
                } else {
                    val h = if (quality > 0) "[height<=$quality]" else ""
                    req.addOption("-f", "bv*$h[ext=mp4]+ba[ext=m4a]/bv*$h+ba/b$h/b")
                    req.addOption("--merge-output-format", "mp4")
                }
                YoutubeDL.getInstance().execute(req) { progress, _, _ ->
                    _state.update { it.copy(progress = progress.coerceIn(0f, 100f) / 100f) }
                }
                val files = tmp.listFiles()?.filter { it.isFile && it.length() > 0 }.orEmpty()
                if (files.isEmpty()) throw IllegalStateException("لم يتم العثور على الملف بعد التحميل")

                val label = when {
                    audioOnly -> "MP3 320kbps"
                    quality == 0 -> "أفضل جودة"
                    else -> "${quality}p"
                }
                files.forEach { f ->
                    val (uri, mime) = saveToDownloads(ctx, f)
                    addHistory(
                        HistoryItem(
                            f.nameWithoutExtension, label,
                            SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date()),
                            uri, mime
                        )
                    )
                }
                _state.value = UiState(
                    ready = true,
                    progress = 1f,
                    message = "تم الحفظ في Downloads/MostafaDownloader ✅"
                )
            } catch (e: Exception) {
                _state.value = UiState(
                    ready = true,
                    message = "فشل التحميل: ${e.message?.take(200)}",
                    isError = true
                )
            } finally {
                tmp.deleteRecursively()
            }
        }
    }

    private fun addHistory(item: HistoryItem) {
        val list = listOf(item) + _history.value
        _history.value = list.take(100)
        store.save(_history.value)
    }

    fun clearHistory() {
        _history.value = emptyList()
        store.save(emptyList())
    }

    fun updateEngine() {
        if (!_state.value.ready || _state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(busy = true, isError = false, message = "جاري تحديث المحرك...") }
            try {
                YoutubeDL.getInstance().updateYoutubeDL(getApplication())
                _state.update { it.copy(busy = false, message = "تم تحديث المحرك ✅") }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, isError = true, message = "فشل التحديث: ${e.message}") }
            }
        }
    }

    /** يرجع (uri, mime) للملف المحفوظ */
    private suspend fun saveToDownloads(ctx: Context, file: File): Pair<String, String> {
        val mime = when (file.extension.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/MostafaDownloader"
                )
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("تعذر إنشاء الملف في Downloads")
            ctx.contentResolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            return uri.toString() to mime
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "MostafaDownloader"
            ).apply { mkdirs() }
            val dest = File(dir, file.name)
            file.copyTo(dest, overwrite = true)
            val uri = suspendCancellableCoroutine<String> { cont ->
                MediaScannerConnection.scanFile(
                    ctx, arrayOf(dest.absolutePath), arrayOf(mime)
                ) { _, u -> cont.resume(u?.toString() ?: "") }
            }
            return uri to mime
        }
    }
}
