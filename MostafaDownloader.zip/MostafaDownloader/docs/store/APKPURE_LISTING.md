# بيانات صفحة التطبيق على APKPure (انسخ والصق)

- **اسم التطبيق / App name:** SC Downloader
- **Package:** com.mostafa.downloader  (ما تغيّرهوش)
- **المطوّر / Developer:** Mostafa Mahmoud
- **التصنيف / Category:** Tools (أو Video Players & Editors)
- **الإيميل / Contact:** mostafa.potter@gmail.com
- **الأجهزة:** أندرويد 7.0 فأعلى (minSdk 24)
- **الإعلانات:** لا يوجد | **المشتريات داخل التطبيق:** لا يوجد | **تتبّع/تحليلات:** لا يوجد
- **سياسة الخصوصية:** ارفع `PRIVACY_POLICY.md` في الـ repo (أو GitHub Pages) وحط الرابط

## وصف قصير (Short description)
AR: حمّل الفيديوهات والصوتيات من أشهر المنصات بضغطة واحدة، وقص وترجمة ولخّص الفيديو.
EN: Download videos and audio from popular platforms in one tap, then trim, translate and summarize them.

## الوصف الكامل — عربي
SC Downloader تطبيق بسيط وسريع لتحميل الفيديو والصوت والصور من المنصات اللي بتستخدمها كل يوم.

• ألصق الرابط واختار الجودة أو الصيغة (فيديو / MP3 / صورة) وحمّل.
• يدعم يوتيوب، تيك توك، إنستجرام، فيسبوك، سناب شات، X (تويتر) وغيرها.
• تحميل قوائم التشغيل كاملة أو آخر عدد تحدده.
• حالات واتساب واستوريهات المنصات (بتسجيل دخول من صفحة المنصة الرسمية جوه التطبيق).
• قص الفيديو بمقبضين ومعاينة قبل الحفظ.
• ترجمة الفيديو وحرق الترجمة عليه، واستخراج النص والملخص (بمفتاح Groq المجاني بتاعك).
• ضغط الفيديو لتوفير المساحة.
• التحميل بيكمل في الخلفية، مع ودجت لصق الرابط من الشاشة الرئيسية.
• عربي وإنجليزي، ووضع داكن، من غير إعلانات.

ملاحظة: حمّل المحتوى اللي تملكه أو مسموح لك بتحميله فقط، والتزم بشروط كل منصة وحقوق أصحاب المحتوى.

## Full description — English
SC Downloader is a simple, fast app for saving videos, audio and images from the platforms you use every day.

• Paste a link, pick the quality or format (video / MP3 / image) and download.
• Works with YouTube, TikTok, Instagram, Facebook, Snapchat, X (Twitter) and more.
• Download whole playlists or the latest N items.
• WhatsApp statuses and platform stories (sign in on the platform's official page inside the app).
• Trim videos with a two-handle timeline and preview before saving.
• Translate videos and burn subtitles in, plus transcript and summary (using your own free Groq key).
• Compress videos to save space.
• Downloads keep running in the background; paste-and-download home screen widget.
• Arabic and English, dark theme, no ads.

Note: only download content you own or are allowed to download, and respect each platform's terms and creators' rights.

## What's new (الجديد في هذا الإصدار)
AR: تصميم جديد بالكامل، شاشة "المزيد" بالأدوات، قص الفيديو، نص وملخص الفيديو، تحسينات في تحميل فيسبوك وثبات التحميل.
EN: Brand-new design, a "More" tools screen, video trimming, transcript & summary, Facebook download fixes and better stability.

## Tags
video downloader, mp3, tiktok, instagram, facebook, youtube, status saver, trim video, translate video
